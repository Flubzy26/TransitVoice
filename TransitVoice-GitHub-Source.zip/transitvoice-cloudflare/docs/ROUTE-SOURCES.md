# Pune/PMPML route references

The site uses selected stop examples from publicly available route listings. It does not fetch live schedules or claim an official PMPML API connection.

- Route 2 — Swargate to Shivajinagar: https://moovitapp.com/index/en/public_transit-line-2-Pune-5884-1509110-158281336-0
- Route 4 — Swargate to Shivajinagar: https://moovitapp.com/index/en/public_transit-line-4-Pune-5884-1509110-158281334-0
- Route 5 — Swargate to Pune Station (Moledina Stand): https://moovitapp.com/index/en/public_transit-line-5-Pune-5884-1509110-223098198-0
- Route 24 — Katraj to MH Housing Board Samtanagar: https://moovitapp.com/index/en/public_transit-line-24-Pune-5884-1509110-49354330-1
- Route 43 — Katraj to Bhakti Shakti Terminal: https://moovitapp.com/index/en/public_transit-line-43-Pune-5884-1509110-117544305-0
- Route 115 — Pune Station Moledina Stand to Hinjawadi Maan Phase 3: https://moovitapp.com/index/en/public_transit-line-115-Pune-5884-1509110-52563557-0

Route services and stops can change. Users should check current PMPML information before travelling. PMPML contact information found in a public search result includes 020-24545454; the site does not display this as an emergency channel.
