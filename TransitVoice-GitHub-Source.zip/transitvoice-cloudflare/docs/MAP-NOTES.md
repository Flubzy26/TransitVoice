# Map implementation and boundaries

The planner uses Leaflet 1.9.4, standard OpenStreetMap raster tiles and the OSRM public demo routing service. No paid API key is used. This is an educational prototype, not a production navigation product.

- Leaflet documentation: https://leafletjs.com/reference
- OSM tile policy: https://operations.osmfoundation.org/policies/tiles/
- OSRM routing API: https://project-osrm.org/docs/v5.24.0/api/

Visible map attribution is preserved. Tiles use browser caching with no bulk download, offline tile pack or prefetch. Express sends `strict-origin-when-cross-origin` so map requests include a valid origin referrer. Production CSP allows only the required OSM image host and OSRM connection host in addition to the app's existing sources.

OSRM requests occur only on Preview road route. Abort controllers cancel obsolete requests, a 12-second timeout prevents indefinite waiting, and failed or invalid responses produce an explicitly labelled straight-line fallback. The geometry is a general driving route between two approximate landmarks, not a bus alignment. Duration excludes live traffic and bus stops. There are no transfer, fare or schedule calculations.

Coordinates in `src/lib/journeys.ts` are approximate hand-curated Pune-area landmarks. They must be verified and replaced with an authoritative stop dataset before operational use. Selected-stop matching references existing seed route IDs and only represented directions. See ROUTE-SOURCES.md for the bus example sources.

GPS uses one-shot `getCurrentPosition` after the user clicks Use my location. The point lives only in React memory and is not passed to the feedback API. Location-to-landmark matching runs locally. Although precise GPS is not sent to OSRM, OSM tile requests reveal the map area being viewed. This is explained in the passenger UI. GPS permission and accuracy depend on the device; HTTPS is normally required outside localhost.

External demo services have no availability guarantee. A larger public deployment needs an appropriate tile/routing provider or self-hosted infrastructure, provider-policy review, and accurate geographic data. The app never claims live bus tracking.
