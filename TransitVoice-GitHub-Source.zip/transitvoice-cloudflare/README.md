# Cloudflare free-hosting edition

**Start with [DEPLOY-CLOUDFLARE.md](DEPLOY-CLOUDFLARE.md).** This edition includes the original local Node application and a Cloudflare Worker backend. Cloudflare hosting uses persistent SQLite inside a Durable Object, not D1. The UI and API routes are retained. The original Node instructions below still apply to local use.

Cloudflare deployment is not performed by downloading this ZIP. You must publish to your own Cloudflare account. Do not use the dashboard static-file upload screen.

---

# TransitVoice

A transport-feedback pilot for colleges, employee shuttles and private operators, alongside the original Pune Community Engagement Project demo. Includes separate organisation workspaces, staff roles, anonymous passenger portals, private status tracking and report workflows. This is a working startup foundation, not a deployed or payment-enabled commercial service.

## Quick start (Windows, macOS, Linux)

Install **Node.js 24 LTS** (minimum supported: Node 22.16, required for the backup API). Then open a terminal in this folder:

```sh
npm ci
npm run setup
npm run dev
```

Open **http://localhost:5173**. The React frontend runs on port 5173 and proxies `/api` to the Express backend on port 3001.

`npm run setup` creates a private `.env`, initializes SQLite, and seeds 6 Pune PMPML route examples plus 84 demo reports. It is safe to rerun: it preserves existing credentials and feedback.

### Create your organisation account (new)

Open **http://localhost:5173/workspace?mode=register**. Enter your organisation, your name, email and a password of at least 12 characters. You become the workspace **owner**. This account is stored in SQLite with a salted scrypt password hash; it does not use the admin password in `.env`.

1. Add a route in **Routes & QR**.
2. Open **Passenger portal** and submit an anonymous test report.
3. Save the private tracking code/link shown on the receipt.
4. Return to **Report inbox**, open the report, set priority and assign it.
5. Create a single-use invitation in **Team**. Open it in another browser profile to join as a manager or agent. No email is sent; you share the link yourself.
6. Staff update the status and add internal notes. Agents can access assigned reports only; managers can coordinate all reports in their own workspace.
7. Revisit **Track report** using the private code to see status history, without internal notes or descriptions.
8. Check real workspace metrics, filter the inbox, or export matching reports to CSV.

Workspace **Settings** lets you change your password without editing Notepad. The current password is required and other sessions are revoked. Each account belongs to one workspace. Email verification and email delivery are not configured.

Pilot limits are 10 active routes and 10 active team members. Team/Enterprise plan preferences are stored locally only: they do not charge money, change access limits, or notify a sales team. The landing page marks commercial packages and integrations as future work.

### Original Pune demo admin login

Open `.env` in your editor after running setup:

- Email: the `ADMIN_EMAIL` value (initially `admin@transitvoice.local`).
- Password: the randomly generated `ADMIN_PASSWORD` value.

Visit **http://localhost:5173/admin**. Do not share or commit `.env`. To choose your own credentials, edit these values (password at least 12 characters), restart the server, and remove existing sessions if revoking prior access: stop the app and run `node --input-type=module -e "import {DatabaseSync} from 'node:sqlite'; const db=new DatabaseSync('./data/transitvoice.sqlite'); db.exec('DELETE FROM sessions'); db.close();"` using your actual database path.

SQLite is provided by Node itself, so no database server or API key is required. Some Node versions print an experimental SQLite warning; it does not indicate a failed operation.

## Pages

| Page           | Purpose                                                                           |
| -------------- | --------------------------------------------------------------------------------- |
| `/`            | Business landing page, product workflow, pilot offer and clearly labelled roadmap |
| `/workspace`   | Account signup/login and protected organisation dashboard                         |
| `/join#TOKEN`  | Single-use staff invitation, with secret kept in the URL fragment                 |
| `/p/:slug`     | Organisation passenger portal; optional `?route=ID` preselects a route            |
| `/track#TOKEN` | Private passenger status tracking; token submitted in POST body                   |
| `/community`   | Original Pune landing page and route explorer                                     |
| `/feedback`    | Anonymous passenger form, category, rating, optional description and location     |
| `/insights`    | Public aggregate metrics, charts, route comparison and filters                    |
| `/admin`       | Admin login, protected reports, search, filters, pagination and status updates    |
| `/journey`     | Interactive Pune map, start/destination selection, optional GPS and road preview  |

## Interactive journey planner

Choose **Plan a journey** in navigation. Select a start and destination from 12 approximate Pune-area landmarks. The map supports zoom, pan, labelled A/B pins, swapping endpoints and fitting the route. A dashed line is a **straight-line preview**, not directions.

Click **Preview road route** to request a road-following driving route from the public OSRM demo service. Distance and duration come from that response; they are not bus travel times, traffic-aware estimates, official PMPML paths, or fares. The two selected landmark coordinates are sent to OSRM. No API key is needed. Internet is required, and external services can be unavailable; the UI shows an explicit fallback without inventing directions.

**Use my location** requests GPS once, after a click, identifies the nearest example landmark locally, and displays an accuracy circle. It never watches the user's position, saves planner GPS to SQLite, or sends precise GPS to OSRM. OpenStreetMap receives map tile requests and can infer the viewed geographic area. Clear location removes the point; leaving the page also discards it. GPS normally requires HTTPS, except on localhost. Device permission/accuracy varies.

Bus matches are based only on selected stops in six seeded example routes and their example direction. Missing matches do not mean no actual service exists. Coordinates are approximate landmarks, not surveyed boarding stops. Always confirm real travel with PMPML. See `docs/MAP-NOTES.md`.

Warm route animations, entrance transitions and hover interactions respect **prefers-reduced-motion**. A moving route highlight is decorative, not a moving live bus.

## Demo walkthrough

1. Open Community insights and select **Community submissions only**. On a fresh database this has an empty state.
2. Share feedback for PMPML route 115, category Delay, rating 2, and a short description. Location can be omitted.
3. Save the confirmation reference.
4. Sign in at `/admin`, select Community only, and search for that reference.
5. Click Review and change the status to Under Review or Resolved. Save.
6. Check that dashboard totals and public insights reflect the change.
7. Restart the server and verify the report still exists.

Demo reports are marked `DEMO` on the admin table. Public and admin screens can include all reports, only demo data, or only community submissions. Ratings and statuses in this prototype are not official service performance indicators. No complaint is forwarded to an authority.

## Commands

```sh
npm run setup       # Create .env and initialize sample data, once
npm run db:init     # Initialize schema and seed data; safe to repeat
npm run dev         # Run backend and frontend with automatic reload
npm run typecheck   # TypeScript validation
npm test            # Integration and persistence tests
npm run test:browser # Browser smoke test (install Chromium with npx playwright install chromium first)
npm run test:workspace # Full organisation/passenger/staff browser workflow
npm run db:backup   # Create a consistent SQLite backup in backups/
npm run account:reset -- owner@example.com # Local operator resets a workspace password
npm run build       # Typecheck and create dist/
npm run preview     # Serve the built app locally at http://localhost:3001
npm start           # Run Express using your .env configuration
```

Run `npm run build` before `npm run preview`. Preview explicitly uses a local HTTP origin and development cookies. It is for local presentation only. Use `npm start` with the production configuration for hosting.

## Stack and structure

- React + TypeScript + Vite + React Router
- Tailwind CSS v4 plus custom responsive design tokens and components
- Express 5 JSON REST API
- Node's `node:sqlite` with persistent disk storage and prepared queries
- Recharts for accessible, database-backed charts
- QRCode for locally generated, downloadable route QR images and printable posters
- Zod input validation, Helmet security headers, express-rate-limit

```text
src/
  pages/          Business, Workspace, PassengerPortal, Home, Feedback, Insights, Admin, Journey
  components/     Shared UI, metrics, charts and route table
  lib/api.ts      API requests and abortable loading hook
  types.ts        Shared category, status and response types
  styles.css      Responsive visual design
server/
  app.ts          REST API, validation, authentication and filtering
  workspaces.ts   Organisation schema, accounts, scoped workflow APIs and private tracking
  db.ts           Schema, indexes and idempotent sample data
  index.ts        Environment validation and HTTP server
scripts/
  setup.ts        First-run configuration
  init-db.ts      Database initialization
  preview.ts      Local production-build preview
  browser-check.ts  Browser smoke test (optional)
tests/
  api.test.ts     Core integration, security and persistence tests
```

## API

| Method | Endpoint                 | Access                      |
| ------ | ------------------------ | --------------------------- |
| GET    | `/api/health`            | Public                      |
| GET    | `/api/routes`            | Public                      |
| POST   | `/api/feedback`          | Public, rate limited        |
| GET    | `/api/insights`          | Public, aggregate data only |
| POST   | `/api/admin/login`       | Public, rate limited        |
| GET    | `/api/admin/session`     | Admin                       |
| POST   | `/api/admin/logout`      | Admin                       |
| GET    | `/api/admin/stats`       | Admin                       |
| GET    | `/api/admin/reports`     | Admin                       |
| PATCH  | `/api/admin/reports/:id` | Admin                       |

Example feedback JSON:

```json
{
  "routeId": 101,
  "category": "Delay",
  "rating": 2,
  "busNumber": "TV-1042",
  "description": "The bus was late during the morning commute.",
  "location": { "latitude": 18.52, "longitude": 73.85 }
}
```

`busNumber`, `description`, and `location` are optional. Omit `location` completely if not supplied. The server rejects invalid routes, categories, ratings, coordinates and oversized descriptions.

Filters: `route` (numeric ID), `source` (`all`, `demo`, `community`), `from`/`to` (`YYYY-MM-DD`). Admin adds `category`, `status`, `q` (reference, bus number or description), and `page`. Pagination is 10 reports per page. Date filters use UTC; the 14-day trend ends on the selected end date or today. Public endpoints never return report descriptions, report references, bus numbers or coordinates.

## Workspace API and permissions

Organisation APIs live under `/api/ops`. Main resources are `register`, `login`, `join`, `me`, `logout`, `password`, `routes`, `team`, `invites`, `reports`, `stats`, `export` and `organization`. Public passenger endpoints are `GET public/:slug`, `POST public/:slug/reports` and `POST track`.

| Capability                                                     | Owner                 | Manager               | Agent            |
| -------------------------------------------------------------- | --------------------- | --------------------- | ---------------- |
| View workspace dashboard                                       | All workspace reports | All workspace reports | Assigned reports |
| Review/update report status and internal notes                 | All workspace reports | All workspace reports | Assigned reports |
| Set priority/assignment, export reports                        | Yes                   | Yes                   | No               |
| Add/archive routes                                             | Yes                   | Yes                   | No               |
| View route list and team directory                             | Yes                   | Yes                   | Yes              |
| Invite/deactivate users, change workspace name/plan preference | Yes                   | No                    | No               |
| Change own password                                            | Yes                   | Yes                   | Yes              |

Workspace queries are scoped to the authenticated user's organisation, with additional report assignment checks for agents. Cross-organisation route and assignment references are rejected. Inactive staff sessions are invalidated. Invitation links expire after 7 days and can only be accepted once. Sessions expire after 8 hours; only token hashes are stored. Passwords use individual random salts and scrypt. Public tracking and invite tokens use 24 random bytes, with only their SHA-256 hashes stored.

Report updates require the current version number to avoid silently overwriting another teammate's update. Status changes and internal notes create history entries. Internal response targets are 24 hours for High, 72 for Normal, 7 days for Low, measured from creation. Safety reports start High. Changing priority recalculates the target from creation. These are internal goals, not promised passenger SLAs; there are no automated notifications.

CSV export respects inbox filters, excludes internal notes/tracking secrets, escapes spreadsheet formulas and includes at most the newest 10,000 matches. Dates are filtered in UTC. Workspace trends display the last 14 UTC calendar dates and other metrics are all time. Ratings are feedback aggregates, not verified service-quality scores.

Workspace reports are in separate `ops_*` tables. The public Pune insight API and legacy admin do not expose them. The legacy `.env` admin cannot access organisation accounts through the HTTP API.

## Original Pune demo authentication and privacy

Admin credentials are read from `.env`, never embedded in the browser. Password verification uses scrypt with a per-process salt and a timing-safe comparison. Login creates an unpredictable opaque token; only its SHA-256 hash is saved in SQLite. Sessions expire after 8 hours. Cookies are HttpOnly and SameSite=Strict, with Secure enabled in production. Logout deletes the server session. Write requests check browser Origin and require JSON.

Feedback submissions are limited to 12 requests per IP per 15 minutes; unsuccessful admin logins are limited to 8 per 15 minutes. Limits use an in-memory store intended for a single Node process and reset on restart. Express does not trust forwarded IP headers by default.

Passengers do not need accounts or identity fields. GPS is invoked only after clicking **Use location**, once per click; it is never watched in the background. If permission is denied or a request times out, the form still works. Coordinates are optional and visible only to the admin. Users can remove them before submitting. Browsers require HTTPS or localhost for geolocation.

Do not enter personal or sensitive details into descriptions. Text is safely rendered as text by React. Database queries use bound parameters.

## Backups, upgrades and local account recovery

Keep the existing `.env` and `data/` folder when upgrading. Stop the old server, back up the database, replace the application source, run `npm ci`, then `npm run setup`. Workspace tables are additive migrations; existing Pune reports and demo admin settings are preserved. Never overwrite an existing database with an empty one from another project folder.

Run `npm run db:backup` to create a consistent SQLite backup in `backups/`. It uses SQLite's backup API, including committed WAL data. Backups contain private reports and password hashes: keep them off public hosting paths and out of source control. They are not encrypted. Store a copy on a secure separate disk/service and test your restoration procedure. To restore, stop the server and point `DATABASE_PATH` to a copy of the desired backup; keep the current database separately for recovery. Do not replace a database while a server is using it.

If a workspace owner loses their password, the trusted server operator can run:

```sh
npm run account:reset -- owner@example.com
```

This resets that active workspace account, revokes its sessions and prints a new random password locally. The operator must verify the person's identity before handing it over. This is a local administrative tool, not a public email-reset flow, and it does not change the legacy `.env` administrator.

## Hosting / production

This is a standalone Express application. Deploy to a Node-compatible host with a persistent disk; the SQLite database must survive restarts. A static-only host cannot run this backend. A live deployment is not included in this source package.

1. Install dependencies with `npm ci` and run `npm run build`.
2. Set strong `ADMIN_EMAIL`/`ADMIN_PASSWORD`, `PORT`, and a durable `DATABASE_PATH`.
3. Set `APP_ORIGIN` to the exact HTTPS site origin, e.g. `https://transitvoice.example` (no trailing slash).
4. Set `NODE_ENV=production`, initialize the database, and run `npm start` behind HTTPS.
5. If using a trusted reverse proxy, configure Express `trust proxy` for that specific topology. Do not blindly set it to true; it affects IP-based limits.
6. Back up the database using SQLite's backup mechanism. For multiple server instances, use a shared rate-limit store and a suitable managed database.

For a local presentation of the built app, use `npm run preview` instead of production settings. Local HTTP cannot use Secure production cookies.

## Known boundaries

- Routes are Pune/PMPML examples with selected stops. No live transit authority feed or GPS service is connected.
- Admin status changes are internal project records, not proof of action by an authority.
- The Pune demo has one environment-configured administrator. Organisation workspaces have self-registration, role-based accounts, in-app password changes and an operator-only local reset command. There is no email recovery or verification service.
- This is a college prototype, not an emergency reporting service.
- There are no external paid services, API keys, email notifications, uploads or background location tracking.
- Browser test location behavior is simulated; actual GPS accuracy depends on the passenger's device.
- Billing, subscription enforcement beyond pilot limits, automatic emails, attachments, SSO and live vehicle tracking are not implemented. No money is collected. Pricing/market demand has not been validated.
- Pilot accounts and reports require an operational retention/deletion policy before a real public launch. Self-service account/data deletion, moderation workflows and automated backup scheduling are not implemented.
- QR codes and invitation links use the current website origin. A localhost URL will not reach your laptop from a passenger's phone. Use a reachable HTTPS deployment before distributing them. Physical QR scanning/printing has not been tested on a phone/printer.

## Verification

`npm test` creates temporary isolated databases and verifies the submit/review/resolve/logout flow, public data privacy, login requirements, validation, origin protection, rate limiting, date filters, and persistence after reopening SQLite. It does not touch your project database.

Optional browser smoke test:

```sh
npm run build
npx playwright install chromium
node --import tsx scripts/browser-check.ts
```

The browser test starts its own local server using the compiled frontend and a temporary SQLite database. It generates temporary admin credentials, checks desktop and mobile views and the full submit/review/resolve flow, then closes the server and removes its database. Your project database and `.env` are not used. Screenshots are written to `test-results/`.

Screenshots from verification are also included in `docs/screenshots/`. They show seeded demo data plus a temporary browser-test submission.
