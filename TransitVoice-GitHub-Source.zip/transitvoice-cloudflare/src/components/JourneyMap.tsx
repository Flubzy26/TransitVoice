import { useEffect, useRef, useState } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import type { Place } from "../lib/journeys";

export default function JourneyMap({
  from,
  to,
  geometry,
  location,
  focus,
}: {
  from: Place;
  to: Place;
  geometry: [number, number][] | null;
  location: { lat: number; lng: number; accuracy: number } | null;
  focus: number;
}) {
  const element = useRef<HTMLDivElement>(null);
  const map = useRef<L.Map | null>(null);
  const layers = useRef<L.LayerGroup | null>(null);
  const [tilesUnavailable, setTilesUnavailable] = useState(false);
  useEffect(() => {
    if (!element.current) return;
    const instance = L.map(element.current, { scrollWheelZoom: false }).setView(
      [18.54, 73.82],
      12,
    );
    map.current = instance;
    const tiles = L.tileLayer(
      "https://tile.openstreetmap.org/{z}/{x}/{y}.png",
      {
        maxZoom: 19,
        attribution:
          '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap contributors</a>',
      },
    ).addTo(instance);
    tiles.on("tileerror", () => setTilesUnavailable(true));
    tiles.on("tileload", () => setTilesUnavailable(false));
    layers.current = L.layerGroup().addTo(instance);
    const observer = new ResizeObserver(() => instance.invalidateSize());
    observer.observe(element.current);
    return () => {
      observer.disconnect();
      instance.remove();
      map.current = null;
      layers.current = null;
    };
  }, []);
  useEffect(() => {
    const instance = map.current;
    const group = layers.current;
    if (!instance || !group) return;
    group.clearLayers();
    const pin = (place: Place, label: string, color: string) => {
      const icon = L.divIcon({
        className: "journey-pin-wrapper",
        html: `<span class="journey-pin" style="background:${color}">${label}</span>`,
        iconSize: [36, 36],
        iconAnchor: [18, 36],
      });
      const popup = document.createElement("span");
      popup.textContent = `${label === "A" ? "Start" : "Destination"}: ${place.name}`;
      L.marker([place.lat, place.lng], { icon, title: place.name })
        .bindPopup(popup)
        .addTo(group);
    };
    pin(from, "A", "#c7460b");
    pin(to, "B", "#b9232e");
    const points: [number, number][] = geometry || [
      [from.lat, from.lng],
      [to.lat, to.lng],
    ];
    if (from.id !== to.id) {
      L.polyline(points, { color: "white", weight: 10, opacity: 0.9 }).addTo(
        group,
      );
      L.polyline(points, {
        color: "#c7460b",
        weight: 5,
        dashArray: geometry ? undefined : "8 10",
        className: geometry ? "route-road" : "route-schematic",
      }).addTo(group);
    }
    if (location) {
      L.circle([location.lat, location.lng], {
        radius: location.accuracy,
        color: "#986500",
        weight: 1,
        fillOpacity: 0.1,
      }).addTo(group);
      L.circleMarker([location.lat, location.lng], {
        radius: 8,
        color: "white",
        weight: 3,
        fillColor: "#986500",
        fillOpacity: 1,
      })
        .bindTooltip("Your location (this session only)")
        .addTo(group);
    }
    instance.fitBounds(L.latLngBounds(points), {
      padding: [45, 45],
      maxZoom: 15,
      animate: !window.matchMedia("(prefers-reduced-motion: reduce)").matches,
    });
  }, [from, to, geometry, location, focus]);
  return (
    <div className="journey-map-frame">
      <div
        ref={element}
        className="journey-map"
        role="region"
        aria-label="Interactive Pune journey map"
      />
      {tilesUnavailable && (
        <div className="map-warning" role="status">
          Map tiles unavailable. Pins still show approximate locations; check
          your internet connection.
        </div>
      )}
      <div className="map-key">
        <span className="map-dot" />{" "}
        {geometry
          ? "General road preview · not a bus path"
          : "Dashed line = straight-line preview, not a road"}
      </div>
    </div>
  );
}
