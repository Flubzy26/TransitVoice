import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
  BarChart,
  Bar,
  Cell,
} from "recharts";
import type { Stats } from "../types";
import { Empty } from "./ui";
const colors = [
  "#c7460b",
  "#b9232e",
  "#a57200",
  "#ed791d",
  "#91272b",
  "#d8a717",
  "#725448",
];
export function Charts({ stats }: { stats: Stats }) {
  if (!stats.total)
    return (
      <div className="panel">
        <Empty title="No feedback matches these filters" />
      </div>
    );
  return (
    <div className="chart-grid">
      <section className="panel chart-panel">
        <div className="panel-heading">
          <div>
            <h3>What passengers are saying</h3>
            <p>Reports by issue category</p>
          </div>
          <span className="small-chip">{stats.total} reports</span>
        </div>
        <div
          className="chart"
          role="img"
          aria-label={stats.byCategory
            .map((c) => `${c.name}: ${c.count}`)
            .join(", ")}
        >
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={stats.byCategory}
              layout="vertical"
              margin={{ left: 0, right: 25, top: 8, bottom: 8 }}
              accessibilityLayer
            >
              <CartesianGrid horizontal={false} stroke="#f5f0ee" />
              <XAxis
                type="number"
                allowDecimals={false}
                tick={{ fontSize: 12, fill: "#897165" }}
                axisLine={false}
                tickLine={false}
              />
              <YAxis
                dataKey="name"
                type="category"
                width={112}
                tick={{ fontSize: 12, fill: "#654d41" }}
                axisLine={false}
                tickLine={false}
              />
              <Tooltip
                cursor={{ fill: "#fbf6f3" }}
                contentStyle={{ borderRadius: 12, border: "1px solid #f2eae6" }}
              />
              <Bar
                isAnimationActive={false}
                dataKey="count"
                name="Reports"
                radius={[0, 5, 5, 0]}
                barSize={15}
              >
                {stats.byCategory.map((c, i) => (
                  <Cell key={c.name} fill={colors[i]} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </section>
      <section className="panel chart-panel">
        <div className="panel-heading">
          <div>
            <h3>The feedback pulse</h3>
            <p>
              Daily submissions · 14 days ending{" "}
              {new Date(
                stats.trend.at(-1)!.date + "T00:00:00Z",
              ).toLocaleDateString("en-IN", {
                month: "short",
                day: "numeric",
                timeZone: "UTC",
              })}
            </p>
          </div>
          <span className="chart-legend">
            <i />
            Reports
          </span>
        </div>
        <div
          className="chart"
          role="img"
          aria-label="Daily feedback submissions over the displayed 14-day period"
        >
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart
              data={stats.trend}
              margin={{ top: 20, right: 15, left: -22, bottom: 0 }}
              accessibilityLayer
            >
              <defs>
                <linearGradient id="sunsetFill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#c7460b" stopOpacity={0.2} />
                  <stop offset="100%" stopColor="#c7460b" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid vertical={false} stroke="#f5f0ee" />
              <XAxis
                dataKey="date"
                axisLine={false}
                tickLine={false}
                minTickGap={24}
                tick={{ fontSize: 12, fill: "#897165" }}
                tickFormatter={(v) =>
                  new Date(v + "T00:00:00Z").toLocaleDateString("en-IN", {
                    month: "short",
                    day: "numeric",
                    timeZone: "UTC",
                  })
                }
              />
              <YAxis
                allowDecimals={false}
                axisLine={false}
                tickLine={false}
                tick={{ fontSize: 12, fill: "#897165" }}
              />
              <Tooltip
                contentStyle={{ borderRadius: 12, border: "1px solid #f2eae6" }}
              />
              <Area
                isAnimationActive={false}
                type="monotone"
                dataKey="count"
                name="Reports"
                stroke="#c7460b"
                strokeWidth={3}
                fill="url(#sunsetFill)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </section>
    </div>
  );
}
export function RouteTable({ stats }: { stats: Stats }) {
  return (
    <section className="panel">
      <div className="panel-heading">
        <div>
          <h3>A closer look at each route</h3>
          <p>Where feedback is coming from</p>
        </div>
        <span className="small-chip">PMPML route examples</span>
      </div>
      {!stats.byRoute.length ? (
        <Empty title="No route data yet" />
      ) : (
        <div className="table-scroll">
          <table>
            <thead>
              <tr>
                <th>Route</th>
                <th>Corridor</th>
                <th>Reports</th>
                <th>Avg. rating</th>
                <th>Share of feedback</th>
              </tr>
            </thead>
            <tbody>
              {stats.byRoute.map((r) => (
                <tr key={r.id}>
                  <td>
                    <span
                      className="route-pill"
                      style={{ color: r.color, background: r.color + "12" }}
                    >
                      {r.code}
                    </span>
                  </td>
                  <td className="route-name">
                    {r.origin}
                    <span className="route-separator">/</span>
                    {r.destination}
                  </td>
                  <td>{r.count}</td>
                  <td>
                    <span className="rating-number">
                      ★ {r.average.toFixed(1)}
                    </span>
                    <span className="muted"> / 5</span>
                  </td>
                  <td>
                    <div className="share-cell">
                      <div className="progress-track">
                        <div
                          style={{
                            width: `${(r.count / stats.total) * 100}%`,
                            background: r.color,
                          }}
                        />
                      </div>
                      <span>{Math.round((r.count / stats.total) * 100)}%</span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}
