import {
  useEffect,
  useRef,
  useState,
  type FormEvent,
  type ReactNode,
} from "react";
import { Link } from "react-router-dom";
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import QRCode from "qrcode";
import {
  ArrowRight,
  Download,
  Plus,
  QrCode,
  X,
  Copy,
  Check,
  Clock3,
  MessageSquareText,
  Star,
  CircleCheck,
  Users,
  Route as RouteIcon,
  ExternalLink,
} from "lucide-react";
import { api, useApi } from "../lib/api";
import {
  publicUrl,
  timeLabel,
  type Identity,
  type OpsRoute,
  type Ticket,
  type TicketDetail,
  type Member,
  type OpsStats,
} from "../lib/ops";
import { CATEGORIES, STATUSES } from "../types";
import { Badge, Empty, ErrorBox } from "./ui";

function Heading({
  title,
  body,
  children,
}: {
  title: string;
  body: string;
  children?: ReactNode;
}) {
  return (
    <div className="ops-heading">
      <div>
        <h1>{title}</h1>
        <p>{body}</p>
      </div>
      {children}
    </div>
  );
}
function Loading() {
  return (
    <div className="ops-loading" role="status">
      Loading workspace data…
    </div>
  );
}
export function CopyButton({
  value,
  label = "Copy link",
}: {
  value: string;
  label?: string;
}) {
  const [message, setMessage] = useState("");
  async function copy() {
    try {
      await navigator.clipboard.writeText(value);
      setMessage("Copied");
    } catch {
      setMessage("Copy the displayed link manually.");
    }
  }
  return (
    <span className="ops-copy">
      <button type="button" className="text-button" onClick={copy}>
        {message === "Copied" ? <Check size={15} /> : <Copy size={15} />}{" "}
        {message === "Copied" ? message : label}
      </button>
      {message && message !== "Copied" && (
        <small role="status">{message}</small>
      )}
    </span>
  );
}
export function OpsOverview({
  me,
  openInbox,
}: {
  me: Identity;
  openInbox: () => void;
}) {
  const stats = useApi<OpsStats>("/api/ops/stats"),
    routes = useApi<OpsRoute[]>("/api/ops/routes");
  if (stats.error)
    return <ErrorBox message={stats.error} retry={stats.refresh} />;
  if (!stats.data) return <Loading />;
  const s = stats.data;
  return (
    <>
      <Heading
        title={`A clearer picture, ${me.name.split(" ")[0]}.`}
        body={
          me.role === "agent"
            ? "Your assigned reports. Every update helps close the loop."
            : "Your workspace data, without demo reports mixed in."
        }
      >
        <Link className="button small" to={`/p/${me.slug}`}>
          <ExternalLink size={16} /> Passenger portal
        </Link>
      </Heading>
      <div className="ops-kpis">
        {[
          [MessageSquareText, "Reports received", s.total, "All time"],
          [
            Star,
            "Journey rating",
            s.total ? s.average.toFixed(1) : "—",
            "Out of 5",
          ],
          [Clock3, "Needs attention", s.open, `${s.overdue} past target`],
          [
            CircleCheck,
            "Resolved",
            s.resolved,
            s.total
              ? `${Math.round((s.resolved / s.total) * 100)}% of reports`
              : "No reports yet",
          ],
        ].map(([Icon, label, value, sub]) => {
          const I = Icon as typeof Star;
          return (
            <article key={String(label)}>
              <div>
                <span>{String(label)}</span>
                <I size={18} />
              </div>
              <strong>{String(value)}</strong>
              <small>{String(sub)}</small>
            </article>
          );
        })}
      </div>
      {s.total === 0 && (
        <div className="ops-onboarding">
          <div>
            <span className="preview-pill">YOUR NEXT STEP</span>
            <h2>
              {routes.data?.length
                ? "Share a route. Hear from a passenger."
                : "Make this workspace yours."}
            </h2>
            <p>
              {me.role === "agent"
                ? "Assigned reports will appear here when a manager adds you to a report."
                : "Add a route, share its QR code, and submit your first report to try the entire workflow."}
            </p>
          </div>
          {me.role !== "agent" && (
            <Link to="/workspace?tab=routes" className="button secondary">
              Set up routes <ArrowRight size={17} />
            </Link>
          )}
        </div>
      )}
      <div className="ops-two-columns">
        <section className="ops-panel">
          <div className="ops-panel-heading">
            <h2>Passenger voices over time</h2>
            <span>Last 14 days · UTC</span>
          </div>
          <div className="ops-chart">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart
                data={s.trend}
                margin={{ left: -20, right: 15, top: 15, bottom: 0 }}
              >
                <defs>
                  <linearGradient id="opsFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#e56a28" stopOpacity={0.3} />
                    <stop offset="100%" stopColor="#e56a28" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid vertical={false} stroke="#f0e5dd" />
                <XAxis
                  dataKey="date"
                  tickFormatter={(v) => String(v).slice(5)}
                  tick={{ fontSize: 11 }}
                  minTickGap={30}
                />
                <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
                <Tooltip />
                <Area
                  type="monotone"
                  dataKey="count"
                  name="Reports"
                  stroke="#c7460b"
                  strokeWidth={3}
                  fill="url(#opsFill)"
                  isAnimationActive={false}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </section>
        <section className="ops-panel">
          <div className="ops-panel-heading">
            <h2>What passengers mention</h2>
            <span>All time</span>
          </div>
          {s.categories.length ? (
            s.categories.map((c) => (
              <div className="ops-category-row" key={c.name}>
                <div>
                  <span>{c.name}</span>
                  <strong>{c.count}</strong>
                </div>
                <div className="ops-meter">
                  <span style={{ width: `${(c.count / s.total) * 100}%` }} />
                </div>
              </div>
            ))
          ) : (
            <Empty title="No categories yet">
              Your first report will start this view.
            </Empty>
          )}
        </section>
      </div>
      <div className="ops-two-columns">
        <section className="ops-panel">
          <div className="ops-panel-heading">
            <h2>Route review</h2>
            <span>Most reported · all time</span>
          </div>
          {s.routes.length ? (
            <div className="ops-route-stats">
              {s.routes.map((r) => (
                <div key={r.code}>
                  <span className="ops-code">{r.code}</span>
                  <span>{r.count} reports</span>
                  <strong>
                    <Star size={14} />
                    {r.average} / 5
                  </strong>
                </div>
              ))}
            </div>
          ) : (
            <p className="ops-muted">
              Route ratings appear after feedback arrives.
            </p>
          )}
          <p className="ops-footnote">
            Report counts depend on participation and are not an objective
            ranking of route quality.
          </p>
        </section>
        <section className="ops-panel ops-action-panel">
          <span className="ops-icon">
            <Clock3 />
          </span>
          <h2>Keep the response moving.</h2>
          <p>
            {s.unassigned} open reports are unassigned. {s.overdue} open reports
            are past their internal response target.
          </p>
          <button className="button secondary" onClick={openInbox}>
            Open report inbox <ArrowRight size={17} />
          </button>
          <small>
            Targets: High 24h · Normal 72h · Low 7 days. Internal goals, not a
            passenger service guarantee.
          </small>
        </section>
      </div>
    </>
  );
}
export function OpsInbox({ me }: { me: Identity }) {
  const [filters, setFilters] = useState({
      q: "",
      status: "",
      priority: "",
      route: "",
      category: "",
      from: "",
      to: "",
      overdue: "",
    }),
    [page, setPage] = useState(1),
    [selected, setSelected] = useState<string | null>(null),
    [error, setError] = useState("");
  const params = new URLSearchParams({
    ...filters,
    page: String(page),
  }).toString();
  const reports = useApi<{
      reports: Ticket[];
      total: number;
      page: number;
      pageSize: number;
    }>("/api/ops/reports?" + params),
    routes = useApi<OpsRoute[]>("/api/ops/routes");
  function filter(key: keyof typeof filters, value: string) {
    setFilters((v) => ({ ...v, [key]: value }));
    setPage(1);
  }
  async function download() {
    setError("");
    try {
      const response = await fetch("/api/ops/export?" + params);
      if (!response.ok)
        throw new Error("Export failed. Check your session and filters.");
      const url = URL.createObjectURL(await response.blob());
      const a = document.createElement("a");
      a.href = url;
      a.download = "transitvoice-reports.csv";
      a.click();
      window.setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch (e) {
      setError((e as Error).message);
    }
  }
  return (
    <>
      <Heading
        title="Every report. A next step."
        body={
          me.role === "agent"
            ? "You can view and update reports assigned to you."
            : "Search, prioritise and assign your team's passenger reports."
        }
      >
        {me.role !== "agent" && (
          <button className="button secondary small" onClick={download}>
            <Download size={16} /> Export CSV
          </button>
        )}
      </Heading>
      <section className="ops-filter-panel">
        <label className="ops-search">
          Search reports
          <input
            value={filters.q}
            maxLength={100}
            placeholder="Reference or description…"
            onChange={(e) => filter("q", e.target.value)}
          />
        </label>
        <label>
          Status
          <select
            aria-label="Status"
            value={filters.status}
            onChange={(e) => filter("status", e.target.value)}
          >
            <option value="">All statuses</option>
            {STATUSES.map((v) => (
              <option key={v}>{v}</option>
            ))}
          </select>
        </label>
        <label>
          Priority
          <select
            value={filters.priority}
            onChange={(e) => filter("priority", e.target.value)}
          >
            <option value="">All priorities</option>
            {["High", "Normal", "Low"].map((v) => (
              <option key={v}>{v}</option>
            ))}
          </select>
        </label>
        <label>
          Route
          <select
            value={filters.route}
            onChange={(e) => filter("route", e.target.value)}
          >
            <option value="">All routes</option>
            {routes.data?.map((r) => (
              <option key={r.id} value={r.id}>
                {r.code}
                {r.active ? "" : " (archived)"}
              </option>
            ))}
          </select>
        </label>
        <label>
          Category
          <select
            value={filters.category}
            onChange={(e) => filter("category", e.target.value)}
          >
            <option value="">All categories</option>
            {CATEGORIES.map((c) => (
              <option key={c}>{c}</option>
            ))}
          </select>
        </label>
        <label>
          From (UTC)
          <input
            type="date"
            value={filters.from}
            onChange={(e) => filter("from", e.target.value)}
          />
        </label>
        <label>
          To (UTC)
          <input
            type="date"
            value={filters.to}
            onChange={(e) => filter("to", e.target.value)}
          />
        </label>
        <div className="ops-filter-actions">
          <label className="ops-checkbox">
            <input
              type="checkbox"
              checked={!!filters.overdue}
              onChange={(e) => filter("overdue", e.target.checked ? "1" : "")}
            />{" "}
            Past target only
          </label>
          <button
            className="text-button"
            onClick={() => {
              setFilters({
                q: "",
                status: "",
                priority: "",
                route: "",
                category: "",
                from: "",
                to: "",
                overdue: "",
              });
              setPage(1);
            }}
          >
            Reset filters
          </button>
        </div>
      </section>
      {(error || reports.error) && (
        <ErrorBox message={error || reports.error} />
      )}
      {reports.loading ? (
        <Loading />
      ) : reports.data?.reports.length ? (
        <>
          <div className="ops-report-list">
            {reports.data.reports.map((r) => (
              <button
                key={r.id}
                className="ops-report-row"
                onClick={() => setSelected(r.id)}
                aria-label={`Open report ${r.id}`}
              >
                <div className="ops-report-icon">
                  <MessageSquareText size={20} />
                </div>
                <div className="ops-report-summary">
                  <div>
                    <strong>{r.category}</strong>
                    <span className="ops-code">{r.code}</span>
                    <span
                      className={`ops-priority ${r.priority.toLowerCase()}`}
                    >
                      {r.priority}
                    </span>
                  </div>
                  <p>{r.description || "No written description provided."}</p>
                  <small>
                    {r.id} · {timeLabel(r.created_at)}
                  </small>
                </div>
                <div className="ops-report-meta">
                  <Badge status={r.status} />
                  <small>{r.assignee || "Unassigned"}</small>
                  {r.status !== "Resolved" &&
                    new Date(r.due_at).getTime() < Date.now() && (
                      <span className="ops-overdue">Past target</span>
                    )}
                </div>
                <ArrowRight size={16} />
              </button>
            ))}
          </div>
          <div className="ops-pagination">
            <span>
              {reports.data.total} reports · Page {page} of{" "}
              {Math.max(1, Math.ceil(reports.data.total / 20))}
            </span>
            <button
              className="button secondary small"
              disabled={page === 1}
              onClick={() => setPage((p) => p - 1)}
            >
              Previous
            </button>
            <button
              className="button secondary small"
              disabled={page * 20 >= reports.data.total}
              onClick={() => setPage((p) => p + 1)}
            >
              Next
            </button>
          </div>
        </>
      ) : (
        <Empty title="No reports match">
          Try another filter or share your passenger portal to collect feedback.
        </Empty>
      )}
      <p className="ops-footnote">
        CSV exports include at most the newest 10,000 matching reports. Internal
        notes and tracking secrets are excluded.
      </p>
      {selected && (
        <ReportDialog
          id={selected}
          me={me}
          close={() => setSelected(null)}
          saved={() => {
            setSelected(null);
            reports.refresh();
          }}
        />
      )}
    </>
  );
}
function Modal({
  title,
  close,
  children,
  className = "",
}: {
  title: string;
  close: () => void;
  children: ReactNode;
  className?: string;
}) {
  const ref = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    ref.current?.showModal();
  }, []);
  return (
    <dialog
      ref={ref}
      className={`ops-dialog ${className}`}
      onCancel={close}
      aria-label={title}
    >
      <div className="ops-dialog-heading">
        <h2>{title}</h2>
        <button className="ops-close" onClick={close} aria-label="Close dialog">
          <X size={20} />
        </button>
      </div>
      {children}
    </dialog>
  );
}
function ReportDialog({
  id,
  me,
  close,
  saved,
}: {
  id: string;
  me: Identity;
  close: () => void;
  saved: () => void;
}) {
  const report = useApi<TicketDetail>("/api/ops/reports/" + id),
    team = useApi<Member[]>("/api/ops/team");
  const [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!report.data) return;
    const f = new FormData(e.currentTarget);
    setBusy(true);
    setError("");
    try {
      await api("/api/ops/reports/" + id, {
        method: "PATCH",
        body: JSON.stringify({
          status: f.get("status"),
          priority:
            me.role === "agent" ? report.data.priority : f.get("priority"),
          assigneeId:
            me.role === "agent"
              ? report.data.assignee_id
              : f.get("assigneeId") || null,
          note: f.get("note"),
          version: report.data.version,
        }),
      });
      saved();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  }
  const r = report.data;
  return (
    <Modal title="Report workspace" close={close}>
      {report.error ? (
        <ErrorBox message={report.error} />
      ) : !r ? (
        <Loading />
      ) : (
        <>
          <div className="ops-ticket-header">
            <span className="ops-code">{r.code}</span>
            <strong>{r.category}</strong>
            <Badge status={r.status} />
          </div>
          <p className="ops-muted">
            {r.origin} → {r.destination} · Rating {r.rating}/5
          </p>
          <blockquote className="ops-description">
            {r.description || "No written description."}
          </blockquote>
          <p className="ops-footnote">
            {r.id} · Internal target: {timeLabel(r.due_at)}
          </p>
          <form className="ops-form" onSubmit={submit}>
            <div className="ops-form-grid">
              <label>
                Report status
                <select
                  name="status"
                  aria-label="Report status"
                  defaultValue={r.status}
                >
                  {STATUSES.map((s) => (
                    <option key={s}>{s}</option>
                  ))}
                </select>
              </label>
              <label>
                Priority
                <select
                  name="priority"
                  aria-label="Report priority"
                  defaultValue={r.priority}
                  disabled={me.role === "agent"}
                >
                  {["High", "Normal", "Low"].map((s) => (
                    <option key={s}>{s}</option>
                  ))}
                </select>
              </label>
              <label>
                Assigned to
                <select
                  name="assigneeId"
                  aria-label="Assigned to"
                  defaultValue={r.assignee_id || ""}
                  disabled={me.role === "agent"}
                >
                  <option value="">Unassigned</option>
                  {team.data
                    ?.filter((m) => m.active || m.id === r.assignee_id)
                    .map((m) => (
                      <option key={m.id} value={m.id}>
                        {m.name}
                        {m.active ? "" : " (inactive—reassign)"}
                      </option>
                    ))}
                </select>
              </label>
            </div>
            <label>
              Internal note
              <textarea
                name="note"
                rows={3}
                maxLength={2000}
                placeholder="Record your investigation or follow-up. Passengers cannot see internal notes."
              />
            </label>
            {error && <ErrorBox message={error} />}
            <button className="button" disabled={busy || team.loading}>
              {busy ? "Saving…" : "Save report update"}
            </button>
          </form>
          <h3 className="ops-timeline-title">Activity history</h3>
          <ol className="ops-timeline">
            {r.events.map((event) => (
              <li key={event.id}>
                <span />
                <div>
                  <strong>{event.action}</strong>
                  <small>
                    {event.actor_name} · {timeLabel(event.created_at)}
                  </small>
                  {event.note && <p>{event.note}</p>}
                </div>
              </li>
            ))}
          </ol>
        </>
      )}
    </Modal>
  );
}
export function OpsRoutes({ me }: { me: Identity }) {
  const routes = useApi<OpsRoute[]>("/api/ops/routes"),
    [creating, setCreating] = useState(false),
    [selected, setSelected] = useState<OpsRoute | null>(null),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  async function create(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      await api("/api/ops/routes", {
        method: "POST",
        body: JSON.stringify(Object.fromEntries(new FormData(e.currentTarget))),
      });
      setCreating(false);
      routes.refresh();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function toggle(route: OpsRoute) {
    setError("");
    setBusy(true);
    try {
      await api("/api/ops/routes/" + route.id, {
        method: "PATCH",
        body: JSON.stringify({ active: !route.active }),
      });
      routes.refresh();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <Heading
        title="Your routes. Their voices."
        body="Create routes and put feedback within reach of every passenger."
      >
        {me.role !== "agent" && (
          <button
            className="button small"
            onClick={() => {
              setError("");
              setCreating(true);
            }}
          >
            <Plus size={17} /> Add route
          </button>
        )}
      </Heading>
      <div className="ops-share-panel">
        <div>
          <strong>Your passenger portal</strong>
          <code>{publicUrl(me.slug)}</code>
        </div>
        <CopyButton value={publicUrl(me.slug)} />
      </div>
      {location.hostname === "localhost" ||
      location.hostname === "127.0.0.1" ? (
        <p className="ops-local-note">
          You are running locally. These links and QR codes need a publicly
          reachable HTTPS deployment before sharing with passengers on other
          devices.
        </p>
      ) : null}
      {(error || routes.error) && !creating && (
        <ErrorBox message={error || routes.error} />
      )}
      <div className="ops-route-grid">
        {routes.data?.map((r) => (
          <article
            className={`ops-route-card ${r.active ? "" : "archived"}`}
            key={r.id}
          >
            <div>
              <span className="ops-code large">{r.code}</span>
              <span className="ops-route-state">
                {r.active ? "Accepting feedback" : "Archived"}
              </span>
            </div>
            <h2>
              {r.origin}
              <ArrowRight size={17} />
              {r.destination}
            </h2>
            <p>{r.reports} reports · feedback history retained</p>
            <div className="ops-route-buttons">
              {r.active && (
                <button
                  className="button secondary small"
                  onClick={() => setSelected(r)}
                >
                  <QrCode size={17} /> QR poster
                </button>
              )}
              {me.role !== "agent" && (
                <button
                  disabled={busy}
                  className="text-button"
                  onClick={() => toggle(r)}
                >
                  {r.active ? "Archive" : "Reactivate"}
                </button>
              )}
            </div>
          </article>
        ))}
      </div>
      {routes.loading ? (
        <Loading />
      ) : (
        !routes.data?.length && (
          <Empty title="Your first route starts here">
            Add a shuttle route to create its passenger feedback link and QR
            code.
          </Empty>
        )
      )}
      <p className="ops-footnote">
        Pilot limit: 10 active routes. Archiving stops new submissions while
        preserving reports.
      </p>
      {creating && (
        <Modal title="Add a route" close={() => setCreating(false)}>
          <form className="ops-form" onSubmit={create}>
            <label>
              Route code
              <input
                name="code"
                placeholder="CAMPUS-01"
                required
                maxLength={20}
              />
            </label>
            <label>
              Starting point
              <input
                name="origin"
                placeholder="Main campus"
                required
                minLength={2}
                maxLength={100}
              />
            </label>
            <label>
              Destination
              <input
                name="destination"
                placeholder="City centre"
                required
                minLength={2}
                maxLength={100}
              />
            </label>
            {error && <ErrorBox message={error} />}
            <button className="button" disabled={busy}>
              {busy ? "Creating…" : "Create route"}
            </button>
          </form>
        </Modal>
      )}
      {selected && (
        <QRPoster route={selected} me={me} close={() => setSelected(null)} />
      )}
    </>
  );
}
function QRPoster({
  route,
  me,
  close,
}: {
  route: OpsRoute;
  me: Identity;
  close: () => void;
}) {
  const [image, setImage] = useState(""),
    [error, setError] = useState("");
  const url = publicUrl(me.slug, route.id);
  useEffect(() => {
    let active = true;
    QRCode.toDataURL(url, {
      width: 640,
      margin: 4,
      errorCorrectionLevel: "M",
      color: { dark: "#35251f", light: "#ffffff" },
    })
      .then((v) => {
        if (active) setImage(v);
      })
      .catch(() => {
        if (active)
          setError(
            "Could not generate the QR code. Use the passenger link instead.",
          );
      });
    return () => {
      active = false;
    };
  }, [url]);
  return (
    <Modal title="Route feedback poster" close={close} className="qr-dialog">
      <div className="ops-poster">
        <span className="eyebrow">{me.org_name}</span>
        <h2>Your journey matters.</h2>
        <p>Scan to share anonymous feedback.</p>
        <span className="ops-code large">{route.code}</span>
        <strong>
          {route.origin} → {route.destination}
        </strong>
        {image && (
          <img
            src={image}
            alt={`Feedback QR code for route ${route.code}`}
            width={260}
            height={260}
          />
        )}
        <p>
          No passenger account needed.
          <br />
          Save your private receipt to track updates.
        </p>
        <code>{url}</code>
      </div>
      {error && <ErrorBox message={error} />}
      <div className="ops-poster-actions">
        {image && (
          <a
            className="button"
            href={image}
            download={`route-${route.code.replace(/[^a-z0-9-]/gi, "-")}-qr.png`}
          >
            <Download size={16} /> Download QR
          </a>
        )}
        <button
          className="button secondary"
          disabled={!image}
          onClick={() => window.print()}
        >
          Print poster
        </button>
        <CopyButton value={url} />
      </div>
    </Modal>
  );
}
export function OpsTeam({ me }: { me: Identity }) {
  const team = useApi<Member[]>("/api/ops/team"),
    invites = useApi<{ id: string; role: string; expires_at: number }[]>(
      me.role === "owner" ? "/api/ops/invites" : null,
    );
  const [role, setRole] = useState("agent"),
    [invite, setInvite] = useState(""),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  async function generate() {
    setBusy(true);
    setError("");
    try {
      const r = await api<{ token: string }>("/api/ops/invites", {
        method: "POST",
        body: JSON.stringify({ role }),
      });
      setInvite(`${location.origin}/join#${r.token}`);
      invites.refresh();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function toggle(m: Member) {
    setBusy(true);
    setError("");
    try {
      await api("/api/ops/team/" + m.id, {
        method: "PATCH",
        body: JSON.stringify({ active: !m.active }),
      });
      team.refresh();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function revoke(id: string) {
    setError("");
    try {
      await api("/api/ops/invites/" + id, { method: "DELETE" });
      invites.refresh();
      setInvite("");
    } catch (e) {
      setError((e as Error).message);
    }
  }
  return (
    <>
      <Heading
        title="A team behind every response."
        body="Owners manage access. Managers coordinate routes and reports. Agents work on their assignments."
      />
      {me.role === "owner" && (
        <section className="ops-panel">
          <h2>Invite a teammate</h2>
          <p className="ops-muted">
            Create a single-use link, valid for 7 days. Share it privately
            yourself; no email is sent.
          </p>
          <div className="ops-invite-form">
            <label>
              Invitation role
              <select value={role} onChange={(e) => setRole(e.target.value)}>
                <option value="agent">Agent — assigned reports only</option>
                <option value="manager">
                  Manager — routes and all reports
                </option>
              </select>
            </label>
            <button className="button" disabled={busy} onClick={generate}>
              <Plus size={17} /> Create invitation
            </button>
          </div>
          {invite && (
            <div className="ops-share-panel">
              <code>{invite}</code>
              <CopyButton value={invite} />
            </div>
          )}
          <small className="ops-muted">
            Anyone holding this link can join with the chosen role. Keep it
            private. Pilot: 10 active members.
          </small>
        </section>
      )}
      {(error || team.error || invites.error) && (
        <ErrorBox message={error || team.error || invites.error} />
      )}
      <div className="ops-team-list">
        {team.data?.map((m) => (
          <article key={m.id}>
            <span className="ops-avatar">{m.name.slice(0, 1)}</span>
            <div>
              <strong>{m.name}</strong>
              <small>{m.email}</small>
            </div>
            <span className="ops-role">
              {m.role}
              {m.active ? "" : " · inactive"}
            </span>
            {me.role === "owner" && m.role !== "owner" && (
              <button
                className="text-button"
                disabled={busy}
                onClick={() => toggle(m)}
              >
                {m.active ? "Deactivate" : "Reactivate"}
              </button>
            )}
          </article>
        ))}
      </div>
      {!!invites.data?.length && (
        <section className="ops-panel">
          <h2>Pending invitations</h2>
          {invites.data.map((i) => (
            <div className="ops-pending" key={i.id}>
              <span>
                {i.role} · expires{" "}
                {timeLabel(new Date(i.expires_at).toISOString())}
              </span>
              <button className="text-button" onClick={() => revoke(i.id)}>
                Revoke
              </button>
            </div>
          ))}
        </section>
      )}
      <p className="ops-footnote">
        Deactivation revokes sessions immediately. Existing report assignments
        remain visible to managers so they can be reassigned.
      </p>
    </>
  );
}
export function OpsSettings({
  me,
  refresh,
}: {
  me: Identity;
  refresh: () => void;
}) {
  const [error, setError] = useState(""),
    [notice, setNotice] = useState(""),
    [busy, setBusy] = useState(false);
  async function save(e: FormEvent<HTMLFormElement>, path: string) {
    e.preventDefault();
    setError("");
    setNotice("");
    setBusy(true);
    const form = e.currentTarget;
    try {
      await api(path, {
        method: path.endsWith("password") ? "POST" : "PATCH",
        body: JSON.stringify(Object.fromEntries(new FormData(form))),
      });
      setNotice(
        path.endsWith("password")
          ? "Password changed. Other sessions have been signed out."
          : "Workspace settings saved. Plan interest is recorded locally; no payment or sales request was sent.",
      );
      if (path.endsWith("password")) form.reset();
      else refresh();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <Heading
        title="Built around your operation."
        body="Manage your workspace identity and account security."
      />
      {error && <ErrorBox message={error} />}
      <div role="status" className={notice ? "ops-success" : ""}>
        {notice}
      </div>
      <div className="ops-two-columns">
        {me.role === "owner" && (
          <form
            className="ops-panel ops-form"
            onSubmit={(e) => save(e, "/api/ops/organization")}
          >
            <h2>Workspace details</h2>
            <label>
              Organisation name
              <input
                name="name"
                defaultValue={me.org_name}
                required
                minLength={2}
                maxLength={100}
              />
            </label>
            <label>
              Future plan interest
              <select name="planInterest" defaultValue={me.plan_interest}>
                <option>Pilot</option>
                <option>Team</option>
                <option>Enterprise</option>
              </select>
            </label>
            <p className="ops-muted">
              All workspaces use the same pilot limits. This records a
              preference only. Paid subscriptions and commercial terms are not
              configured.
            </p>
            <button className="button" disabled={busy}>
              Save workspace
            </button>
          </form>
        )}
        <form
          className="ops-panel ops-form"
          onSubmit={(e) => save(e, "/api/ops/password")}
        >
          <h2>Change your password</h2>
          <label>
            Current password
            <input
              type="password"
              name="current"
              required
              maxLength={128}
              autoComplete="current-password"
            />
          </label>
          <label>
            New password
            <input
              type="password"
              name="next"
              required
              minLength={12}
              maxLength={128}
              autoComplete="new-password"
            />
          </label>
          <p className="ops-muted">
            At least 12 characters. Changing your password revokes all other
            workspace sessions.
          </p>
          <button className="button secondary" disabled={busy}>
            Update password
          </button>
        </form>
      </div>
      <section className="ops-panel ops-boundaries">
        <h2>Pilot boundaries</h2>
        <p>
          Workspace feedback is stored in this deployment's SQLite database. It
          is separate from the public Pune demo. No report is forwarded to a
          transport authority. Invite emails, verified email recovery, paid
          billing and live vehicle feeds are not connected.
        </p>
        <p>
          Before a public launch, configure HTTPS, backups, an appropriate
          privacy notice, retention rules and an operational support process.
          The README includes setup and a database backup command.
        </p>
      </section>
    </>
  );
}
