import {
  AlertCircle,
  ArrowUpRight,
  Check,
  LoaderCircle,
  MessageSquare,
  Star,
} from "lucide-react";
import { Link } from "react-router-dom";
import type { ReactNode } from "react";
import type { Stats, Status } from "../types";
export function Logo() {
  return (
    <Link to="/" className="brand" aria-label="TransitVoice home">
      <span className="brand-mark">
        <span>T</span>
        <i />
      </span>
      <span>
        transit<span className="brand-light">voice</span>
      </span>
    </Link>
  );
}
export function SectionLabel({ children }: { children: ReactNode }) {
  return (
    <div className="eyebrow">
      <span className="line-mark" />
      {children}
    </div>
  );
}
export function ErrorBox({
  message,
  retry,
}: {
  message: string;
  retry?: () => void;
}) {
  return (
    <div className="notice error" role="alert">
      <AlertCircle size={19} />
      <span>{message}</span>
      {retry && (
        <button onClick={retry} className="text-button">
          Try again
        </button>
      )}
    </div>
  );
}
export function Loading() {
  return (
    <div className="loading" role="status">
      <LoaderCircle className="spin" size={24} />
      Loading the latest feedback…
    </div>
  );
}
export function Empty({
  title = "Nothing here yet",
  children,
}: {
  title?: string;
  children?: ReactNode;
}) {
  return (
    <div className="empty">
      <span className="empty-icon">
        <MessageSquare size={27} />
      </span>
      <h3>{title}</h3>
      <p>
        {children ||
          "Try changing your filters or be the first to share a journey."}
      </p>
    </div>
  );
}
export function Badge({ status }: { status: Status }) {
  return (
    <span
      className={`badge ${status === "Resolved" ? "resolved" : status === "Under Review" ? "review" : "received"}`}
    >
      <i />
      {status}
    </span>
  );
}
export function Stars({ rating }: { rating: number }) {
  return (
    <span className="stars" aria-label={`${rating} out of 5 stars`}>
      {Array.from({ length: 5 }, (_, i) => (
        <Star
          key={i}
          size={13}
          fill={i < Math.round(rating) ? "currentColor" : "none"}
          className={i < Math.round(rating) ? "" : "star-empty"}
        />
      ))}
    </span>
  );
}
export function StatsCards({ stats }: { stats: Stats }) {
  return (
    <div className="stats-grid">
      <div className="stat-card">
        <span>
          Feedback received
          <MessageSquare size={18} />
        </span>
        <strong>{stats.total.toLocaleString()}</strong>
        <small>
          {stats.demoCount} demo · {stats.total - stats.demoCount} community
        </small>
      </div>
      <div className="stat-card">
        <span>
          Average journey rating
          <Star size={18} />
        </span>
        <strong>
          {stats.total ? stats.average.toFixed(1) : "—"}
          <em>/ 5</em>
        </strong>
        <small>Based on the selected reports</small>
      </div>
      <div className="stat-card">
        <span>
          Awaiting resolution
          <ArrowUpRight size={18} />
        </span>
        <strong>{stats.open}</strong>
        <small>Received and under review</small>
      </div>
      <div className="stat-card">
        <span>
          Marked resolved
          <Check size={18} />
        </span>
        <strong>{stats.resolved}</strong>
        <small>
          {stats.total ? Math.round((stats.resolved / stats.total) * 100) : 0}%
          of selected reports
        </small>
      </div>
    </div>
  );
}
