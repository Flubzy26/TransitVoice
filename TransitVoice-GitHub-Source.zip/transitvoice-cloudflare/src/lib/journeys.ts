// Approximate landmark coordinates for a student prototype, not surveyed bus stops.
export const PLACES = [
  { id: "swargate", name: "Swargate", lat: 18.5018, lng: 73.8636 },
  { id: "katraj", name: "Katraj", lat: 18.4529, lng: 73.8589 },
  { id: "deccan", name: "Deccan Gymkhana", lat: 18.5167, lng: 73.8414 },
  { id: "shivajinagar", name: "Shivajinagar", lat: 18.5314, lng: 73.8499 },
  { id: "shaniwarwada", name: "Shaniwarwada", lat: 18.5195, lng: 73.8553 },
  { id: "station", name: "Pune Station", lat: 18.5285, lng: 73.8743 },
  { id: "university", name: "Pune Vidyapeeth", lat: 18.5523, lng: 73.8246 },
  { id: "dange", name: "Dange Chowk", lat: 18.6008, lng: 73.7643 },
  {
    id: "hinjawadi",
    name: "Hinjawadi Maan Phase 3",
    lat: 18.5846,
    lng: 73.6885,
  },
  { id: "warje", name: "Warje", lat: 18.4839, lng: 73.8003 },
  { id: "chandani", name: "Chandani Chowk", lat: 18.5079, lng: 73.782 },
  { id: "bhakti", name: "Bhakti Shakti", lat: 18.6664, lng: 73.7708 },
];
export type Place = (typeof PLACES)[number];
export const JOURNEYS = [
  { id: 101, code: "2", stops: ["swargate", "shaniwarwada", "shivajinagar"] },
  { id: 102, code: "4", stops: ["swargate", "deccan", "shivajinagar"] },
  { id: 103, code: "5", stops: ["swargate", "station"] },
  { id: 104, code: "24", stops: ["katraj", "swargate", "station"] },
  { id: 105, code: "43", stops: ["katraj", "warje", "chandani", "bhakti"] },
  {
    id: 106,
    code: "115",
    stops: ["station", "university", "dange", "hinjawadi"],
  },
];
export function matchingJourneys(from: string, to: string) {
  if (from === to) return [];
  // Only the seeded example direction is represented; do not invent reverse service.
  return JOURNEYS.filter(
    (r) =>
      r.stops.includes(from) && r.stops.indexOf(to) > r.stops.indexOf(from),
  );
}
export function distanceKm(
  a: Pick<Place, "lat" | "lng">,
  b: Pick<Place, "lat" | "lng">,
) {
  const rad = (v: number) => (v * Math.PI) / 180;
  const d =
    Math.sin(rad(b.lat - a.lat) / 2) ** 2 +
    Math.cos(rad(a.lat)) *
      Math.cos(rad(b.lat)) *
      Math.sin(rad(b.lng - a.lng) / 2) ** 2;
  return 6371 * 2 * Math.atan2(Math.sqrt(d), Math.sqrt(1 - d));
}
export function nearestPlace(location: { lat: number; lng: number }) {
  return PLACES.reduce((best, place) =>
    distanceKm(location, place) < distanceKm(location, best) ? place : best,
  );
}
