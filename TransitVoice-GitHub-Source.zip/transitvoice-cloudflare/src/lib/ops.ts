export type Member = {
  id: string;
  name: string;
  email: string;
  role: "owner" | "manager" | "agent";
  active: number;
};
export type Identity = Member & {
  org_id: string;
  org_name: string;
  slug: string;
  kind: string;
  plan_interest: string;
};
export type OpsRoute = {
  id: string;
  code: string;
  origin: string;
  destination: string;
  active: number;
  reports: number;
};
export type Ticket = {
  id: string;
  route_id: string;
  code: string;
  origin: string;
  destination: string;
  category: string;
  rating: number;
  description: string;
  status: "Received" | "Under Review" | "Resolved";
  priority: "High" | "Normal" | "Low";
  assignee_id: string | null;
  assignee: string | null;
  due_at: string;
  created_at: string;
  updated_at: string;
  version: number;
};
export type TicketDetail = Ticket & {
  events: {
    id: number;
    actor_name: string;
    action: string;
    note: string;
    created_at: string;
  }[];
};
export type OpsStats = {
  total: number;
  average: number;
  resolved: number;
  open: number;
  overdue: number;
  unassigned: number;
  categories: { name: string; count: number }[];
  routes: { code: string; count: number; average: number }[];
  trend: { date: string; count: number }[];
};
export const timeLabel = (value: string) =>
  new Date(value).toLocaleString("en-IN", {
    day: "numeric",
    month: "short",
    hour: "numeric",
    minute: "2-digit",
  });
export const publicUrl = (slug: string, route?: string) =>
  `${window.location.origin}/p/${slug}${route ? "?route=" + route : ""}`;
