import {
  BrowserRouter,
  NavLink,
  Route,
  Routes,
  useLocation,
  Link,
} from "react-router-dom";
import { useEffect, useState, lazy, Suspense } from "react";
import { Menu, X, ShieldCheck } from "lucide-react";
import { Logo, Loading } from "./components/ui";
import Home from "./pages/Home";
const Business = lazy(() => import("./pages/Business"));
const Workspace = lazy(() => import("./pages/Workspace"));
const PassengerPortal = lazy(() => import("./pages/PassengerPortal"));
const TrackReport = lazy(() =>
  import("./pages/PassengerPortal").then((m) => ({ default: m.TrackReport })),
);
const Feedback = lazy(() => import("./pages/Feedback"));
const Insights = lazy(() => import("./pages/Insights"));
const Admin = lazy(() => import("./pages/Admin"));
const Journey = lazy(() => import("./pages/Journey"));
function Shell() {
  const [menu, setMenu] = useState(false);
  const { pathname } = useLocation();
  useEffect(() => {
    setMenu(false);
    window.scrollTo(0, 0);
    const names: Record<string, string> = {
      "/": "Transport feedback, with follow-through",
      "/community": "Pune passenger demo",
      "/workspace": "Transport workspace",
      "/join": "Join your transport team",
      "/track": "Track your report",
      "/feedback": "Share your journey",
      "/insights": "Community insights",
      "/admin": "Admin workspace",
      "/journey": "Plan your Pune journey",
    };
    document.title = `TransitVoice — ${names[pathname] || (pathname.startsWith("/p/") ? "Passenger portal" : "Page not found")}`;
  }, [pathname]);
  return (
    <>
      <a className="skip-link" href="#main">
        Skip to content
      </a>
      <header className="site-header">
        <div className="header-inner">
          <Logo />
          <button
            className="mobile-menu"
            onClick={() => setMenu(!menu)}
            aria-label={menu ? "Close navigation" : "Open navigation"}
            aria-expanded={menu}
          >
            {menu ? <X /> : <Menu />}
          </button>
          <nav
            className={menu ? "nav open" : "nav"}
            aria-label="Main navigation"
          >
            <NavLink to="/" end>
              For teams
            </NavLink>
            <NavLink to="/insights">Community insights</NavLink>
            <NavLink to="/journey">Plan a journey</NavLink>
            <NavLink to="/community">Pune demo</NavLink>
            <NavLink to="/workspace" className="button small">
              Workspace <ShieldCheck size={15} />
            </NavLink>
          </nav>
        </div>
      </header>
      <main id="main">
        <Suspense fallback={<Loading />}>
          <Routes>
            <Route path="/" element={<Business />} />
            <Route path="/community" element={<Home />} />
            <Route path="/workspace" element={<Workspace />} />
            <Route path="/join" element={<Workspace join />} />
            <Route path="/p/:slug" element={<PassengerPortal />} />
            <Route path="/track" element={<TrackReport />} />
            <Route path="/feedback" element={<Feedback />} />
            <Route path="/insights" element={<Insights />} />
            <Route path="/admin" element={<Admin />} />
            <Route path="/journey" element={<Journey />} />
            <Route
              path="*"
              element={
                <div className="container page-intro">
                  <h1>This stop doesn't exist.</h1>
                  <p>Let's get you back on the route.</p>
                  <Link className="button" to="/">
                    Back to home
                  </Link>
                </div>
              }
            />
          </Routes>
        </Suspense>
      </main>
      <footer className="footer">
        <div className="container footer-inner">
          <Logo />
          <p>Pune rides. Pune speaks.</p>
          <span>
            Independent pilot · <Link to="/admin">Pune demo admin</Link>
          </span>
        </div>
        <div className="container footer-note">
          Independent student project, not affiliated with PMPML. Pune route
          examples; all seeded feedback is fictional. Live tracking and official
          integration are future enhancements.
        </div>
      </footer>
    </>
  );
}
export default function App() {
  return (
    <BrowserRouter>
      <Shell />
    </BrowserRouter>
  );
}
