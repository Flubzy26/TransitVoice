import { Link } from "react-router-dom";
import {
  BusFront,
  MessageSquareText,
  ChartNoAxesCombined,
  ShieldCheck,
  Clock3,
  Accessibility,
  Users,
  Check,
  MapPin,
} from "lucide-react";
import { useState } from "react";
import { useApi } from "../lib/api";
import type { Route, Stats } from "../types";
import { SectionLabel, ErrorBox } from "../components/ui";
export default function Home() {
  const routes = useApi<Route[]>("/api/routes");
  const stats = useApi<Stats>("/api/insights");
  const [selected, setSelected] = useState("115");
  const route =
    routes.data?.find((r) => r.code === selected) || routes.data?.[0];
  return (
    <>
      <section className="hero container">
        <div className="hero-copy">
          <SectionLabel>Pune · PMPML passenger voices</SectionLabel>
          <h1>
            Your journey.
            <br />
            Your voice.
            <br />
            <span>Pune moves.</span>
          </h1>
          <p>
            From the college rush at Deccan to the office commute in Hinjawadi —
            make your everyday PMPML ride part of a better Pune.
          </p>
          <p className="marathi-line" lang="mr">
            आपला प्रवास. आपला आवाज.
          </p>
          <div className="hero-actions">
            <Link to="/feedback" className="button">
              <MessageSquareText size={19} />
              Share your journey
            </Link>
            <Link to="/journey" className="button secondary">
              <MapPin size={18} /> Plan a journey
            </Link>
          </div>
          <div className="hero-reassurance">
            <span>
              <ShieldCheck size={16} />
              Anonymous by default
            </span>
            <span>
              <Check size={16} />
              No passenger account needed
            </span>
          </div>
        </div>
        <div className="network-card">
          <div className="network-card-top">
            <span>
              <BusFront size={20} />
              PUNE ROUTE EXPLORER
            </span>
            <span className="demo-label">PMPML examples</span>
          </div>
          <div className="network-card-body">
            <div className="network-title">
              <div>
                <span className="overline">Choose a route. Make it heard.</span>
                <h2>
                  Across Pune.
                  <br />
                  Together.
                </h2>
              </div>
              <span className="route-number">{route?.code || "—"}</span>
            </div>
            <p className="route-caption">
              {route?.origin} / {route?.destination}
            </p>
            <div className="route-diagram" key={route?.id}>
              {route?.stops.map((stop, i) => (
                <div
                  key={stop}
                  className={
                    "stop " + (i === route.stops.length - 1 ? "last" : "")
                  }
                >
                  <span className="stop-node">
                    {i === route.stops.length - 1 ? <MapPin size={15} /> : null}
                  </span>
                  <div>
                    <strong>{stop}</strong>
                    <small>
                      {i === 0
                        ? "Route starts here"
                        : i === route.stops.length - 1
                          ? "Destination"
                          : "Selected stop"}
                    </small>
                  </div>
                </div>
              )) || <p className="muted">Loading Pune route examples…</p>}
            </div>
            <div
              className="route-selector"
              aria-label="Explore Pune route examples"
            >
              {routes.data?.map((r) => (
                <button
                  key={r.id}
                  className={selected === r.code ? "selected" : ""}
                  onClick={() => setSelected(r.code)}
                  aria-pressed={selected === r.code}
                >
                  {r.code}
                </button>
              ))}
            </div>
            <div className="route-context">
              <span>Selected stops · example direction</span>
              {route && (
                <Link
                  to={`/feedback?route=${route.id}`}
                  className="text-button"
                >
                  Review this route
                </Link>
              )}
            </div>
          </div>
          <div className="network-card-bottom">
            <MessageSquareText size={20} />
            <div>
              <strong>One report can reveal a bigger pattern.</strong>
              <span>Your experience belongs in the conversation.</span>
            </div>
          </div>
        </div>
      </section>
      {routes.error && (
        <div className="container">
          <ErrorBox message={routes.error} retry={routes.refresh} />
        </div>
      )}
      <section className="numbers-strip">
        <div className="container numbers-inner">
          <div className="numbers-intro">
            <span className="overline">The conversation so far</span>
            <p>
              Community feedback,
              <br />
              made visible.
            </p>
          </div>
          <div>
            <strong>{stats.data?.total ?? "—"}</strong>
            <span>journeys shared</span>
          </div>
          <div>
            <strong>{routes.data?.length ?? "—"}</strong>
            <span>Pune route examples</span>
          </div>
          <div>
            <strong>{stats.data?.resolved ?? "—"}</strong>
            <span>reports marked resolved</span>
          </div>
          <p className="numbers-note">
            {stats.data
              ? `${stats.data.demoCount} demo reports included.`
              : "Loading saved reports."}
            <br />
            Explore insights to filter them.
          </p>
        </div>
      </section>
      <section className="container pune-routes-section">
        <div className="section-head">
          <div>
            <SectionLabel>Familiar routes. Fresh perspectives.</SectionLabel>
            <h2>Your city. Your daily route.</h2>
          </div>
          <p>Pick your commute and tell us how it went.</p>
        </div>
        <div className="pune-route-grid">
          {routes.data?.map((r) => (
            <Link
              className="pune-route-card"
              to={`/feedback?route=${r.id}`}
              key={r.id}
              style={{ borderTopColor: r.color }}
            >
              <div className="route-card-top">
                <span
                  className="route-pill"
                  style={{ background: r.color, color: "white" }}
                >
                  {r.code}
                </span>
                <span>PMPML · Pune</span>
                <BusFront size={21} />
              </div>
              <h3>
                {r.origin}
                <span>{r.destination}</span>
              </h3>
              <p>Via {r.stops.slice(1, -1).join(" · ")}</p>
              <span className="route-card-action">
                Share a journey <MessageSquareText size={16} />
              </span>
            </Link>
          ))}
        </div>
        <p className="data-footnote">
          Route examples with selected stops, not full timetables. Please check
          current services with PMPML before travelling.
        </p>
        <div className="quick-start">
          <strong>What stood out on your ride?</strong>
          <div>
            {[
              { name: "Delay", label: "A long wait", Icon: Clock3 },
              { name: "Overcrowding", label: "A packed bus", Icon: Users },
              {
                name: "Accessibility",
                label: "Access barriers",
                Icon: Accessibility,
              },
            ].map(({ name, label, Icon }) => (
              <Link
                key={name}
                to={`/feedback?category=${encodeURIComponent(name)}`}
              >
                <Icon size={18} />
                {label}
              </Link>
            ))}
          </div>
        </div>
      </section>
      <section className="container how-section">
        <div className="section-head">
          <div>
            <SectionLabel>From experience to understanding</SectionLabel>
            <h2>
              A little feedback.
              <br />A clearer picture.
            </h2>
          </div>
          <p>
            Make the everyday commute part of
            <br className="desktop-break" /> a bigger conversation.
          </p>
        </div>
        <div className="steps-grid">
          <article>
            <span className="step-icon">
              <BusFront />
            </span>
            <span className="step-number">01</span>
            <h3>Tell us about your route</h3>
            <p>Choose your bus route and the issue that shaped your journey.</p>
          </article>
          <article>
            <span className="step-icon">
              <MessageSquareText />
            </span>
            <span className="step-number">02</span>
            <h3>Share what matters</h3>
            <p>
              Rate the ride, add a little context, and share your location only
              if you want to.
            </p>
          </article>
          <article>
            <span className="step-icon">
              <ChartNoAxesCombined />
            </span>
            <span className="step-number">03</span>
            <h3>See the bigger picture</h3>
            <p>
              Explore patterns across routes as administrators review and update
              reports.
            </p>
          </article>
        </div>
      </section>
      <section className="container bottom-callout">
        <div>
          <SectionLabel>Every passenger counts</SectionLabel>
          <h2>
            What could make
            <br />
            your next ride better?
          </h2>
          <div className="issue-tags">
            <span>
              <Clock3 size={16} />
              On-time journeys
            </span>
            <span>
              <Users size={16} />
              Room to travel
            </span>
            <span>
              <Accessibility size={16} />
              Access for everyone
            </span>
          </div>
        </div>
        <Link to="/feedback" className="button light">
          Share your feedback
        </Link>
      </section>
    </>
  );
}
