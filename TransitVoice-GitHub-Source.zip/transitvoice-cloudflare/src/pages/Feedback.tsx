import { useState, type FormEvent } from "react";
import { Link, useSearchParams } from "react-router-dom";
import {
  Clock3,
  Users,
  Accessibility,
  Sparkles,
  Shield,
  MessagesSquare,
  Ellipsis,
  Star,
  MapPin,
  X,
  Check,
  ShieldCheck,
  LoaderCircle,
  Copy,
  BusFront,
} from "lucide-react";
import { CATEGORIES, type Category, type Route } from "../types";
import { api, useApi } from "../lib/api";
import { ErrorBox, SectionLabel } from "../components/ui";
const icons = [
  Clock3,
  Users,
  Accessibility,
  Sparkles,
  Shield,
  MessagesSquare,
  Ellipsis,
];
export default function Feedback() {
  const [params] = useSearchParams();
  const routes = useApi<Route[]>("/api/routes");
  const [routeId, setRouteId] = useState(params.get("route") || "");
  const [bus, setBus] = useState("");
  const [category, setCategory] = useState<Category | "">(
    CATEGORIES.includes(params.get("category") as Category)
      ? (params.get("category") as Category)
      : "",
  );
  const [rating, setRating] = useState(0);
  const [description, setDescription] = useState("");
  const [location, setLocation] = useState<{
    latitude: number;
    longitude: number;
  } | null>(null);
  const [locating, setLocating] = useState(false);
  const [locationError, setLocationError] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const [receipt, setReceipt] = useState("");
  const [copied, setCopied] = useState(false);
  function clearFieldError(key: string) {
    setErrors((previous) => {
      const next = { ...previous };
      delete next[key];
      return next;
    });
  }
  function locate() {
    setLocationError("");
    if (!navigator.geolocation) {
      setLocationError(
        "Location is unavailable in this browser. You can still submit your feedback.",
      );
      return;
    }
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (p) => {
        setLocation({
          latitude: p.coords.latitude,
          longitude: p.coords.longitude,
        });
        setLocating(false);
      },
      (e) => {
        setLocationError(
          e.code === 1
            ? "Location permission was declined. You can submit without it."
            : "Could not find your location. Try again or submit without it.",
        );
        setLocating(false);
      },
      { enableHighAccuracy: false, timeout: 10000, maximumAge: 0 },
    );
  }
  async function submit(e: FormEvent) {
    e.preventDefault();
    const next: Record<string, string> = {};
    if (!routes.data?.some((r) => r.id === Number(routeId)))
      next.route = "Choose a route.";
    if (!category)
      next.category = "Choose the issue that best describes your journey.";
    if (!rating) next.rating = "Rate your overall journey.";
    setErrors(next);
    if (Object.keys(next).length) {
      document.getElementById("form-errors")?.focus();
      return;
    }
    setSaving(true);
    setError("");
    try {
      const data = await api<{ id: string }>("/api/feedback", {
        method: "POST",
        body: JSON.stringify({
          routeId: Number(routeId),
          busNumber: bus,
          category,
          rating,
          description,
          ...(location ? { location } : {}),
        }),
      });
      setReceipt(data.id);
      window.scrollTo(0, 0);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setSaving(false);
    }
  }
  if (receipt)
    return (
      <div className="container receipt-page">
        <div className="receipt-card">
          <span className="success-icon">
            <Check size={34} />
          </span>
          <SectionLabel>Feedback received</SectionLabel>
          <h1>
            Your voice is
            <br />
            on the route.
          </h1>
          <p>
            Thank you for sharing your journey. Your report is saved and ready
            for review in the project dashboard.
          </p>
          <div className="receipt-id">
            <span>YOUR REPORT REFERENCE</span>
            <strong>{receipt}</strong>
            <button
              className="text-button"
              onClick={async () => {
                try {
                  await navigator.clipboard.writeText(receipt);
                  setCopied(true);
                } catch {
                  setCopied(false);
                }
              }}
            >
              <Copy size={15} />
              {copied ? "Copied" : "Copy reference"}
            </button>
          </div>
          <div className="receipt-status">
            <span className="badge received">
              <i />
              Received
            </span>
            <span>Submitted anonymously</span>
          </div>
          <div className="receipt-actions">
            <Link className="button" to="/insights">
              View community insights
            </Link>
            <button
              className="button secondary"
              onClick={() => {
                setReceipt("");
                setCategory("");
                setRating(0);
                setDescription("");
                setLocation(null);
                setBus("");
              }}
            >
              Share another journey
            </button>
          </div>
          <small>
            This student prototype records feedback. It does not send reports to
            a transport authority.
          </small>
        </div>
      </div>
    );
  return (
    <div className="container">
      <div className="page-intro">
        <SectionLabel>The passenger's perspective</SectionLabel>
        <h1>How was your Pune journey?</h1>
        <p>From Katraj to Hinjawadi, every passenger experience matters.</p>
      </div>
      <div className="form-progress" aria-label="Required fields completed">
        <span>
          <strong>
            {[!!routeId, !!category, !!rating].filter(Boolean).length} / 3
          </strong>{" "}
          essentials complete
        </span>
        <div className="progress-track">
          <div
            style={{
              width: `${([!!routeId, !!category, !!rating].filter(Boolean).length / 3) * 100}%`,
            }}
          />
        </div>
        <span>Route · Issue · Rating</span>
      </div>
      <div className="feedback-layout">
        <form className="panel feedback-form" onSubmit={submit} noValidate>
          <div id="form-errors" tabIndex={-1}>
            {Object.keys(errors).length > 0 && (
              <ErrorBox message="Please complete the highlighted fields below." />
            )}
          </div>
          {error && <ErrorBox message={error} />}
          <section className="form-section">
            <div className="form-section-title">
              <span>01</span>
              <div>
                <h2>Start with your route</h2>
                <p>Help us put your feedback in the right place.</p>
              </div>
            </div>
            <div className="field-grid">
              <label className="field">
                Bus route <span className="required">Required</span>
                <select
                  value={routeId}
                  onChange={(e) => {
                    setRouteId(e.target.value);
                    clearFieldError("route");
                  }}
                  aria-invalid={!!errors.route}
                  aria-describedby={errors.route ? "route-error" : undefined}
                  disabled={routes.loading || saving}
                >
                  <option value="">
                    {routes.loading ? "Loading routes…" : "Choose your route"}
                  </option>
                  {routes.data?.map((r) => (
                    <option key={r.id} value={r.id}>
                      {r.code} · {r.origin} / {r.destination}
                    </option>
                  ))}
                </select>
                {errors.route && (
                  <span className="field-error" id="route-error">
                    {errors.route}
                  </span>
                )}
              </label>
              <label className="field">
                Bus number <span className="optional">Optional</span>
                <input
                  placeholder="e.g. TV-1042"
                  value={bus}
                  onChange={(e) => setBus(e.target.value)}
                  maxLength={40}
                  disabled={saving}
                />
              </label>
            </div>
            {routes.error && (
              <ErrorBox
                message="Routes could not be loaded. Please try again."
                retry={routes.refresh}
              />
            )}
            <p className="field-help">
              PMPML route examples. Selected stops only; not a live timetable.
            </p>
          </section>
          <section className="form-section">
            <div className="form-section-title">
              <span>02</span>
              <div>
                <h2>What would you like to share?</h2>
                <p>Choose the main issue for this report.</p>
              </div>
            </div>
            <fieldset
              className="category-fieldset"
              aria-describedby={errors.category ? "category-error" : undefined}
            >
              <legend className="sr-only">Issue category (required)</legend>
              <div className="category-grid">
                {CATEGORIES.map((c, i) => {
                  const Icon = icons[i];
                  return (
                    <label
                      key={c}
                      className={
                        "category-option " + (category === c ? "chosen" : "")
                      }
                    >
                      <input
                        type="radio"
                        name="category"
                        value={c}
                        checked={category === c}
                        onChange={() => {
                          setCategory(c);
                          clearFieldError("category");
                        }}
                        disabled={saving}
                      />
                      <Icon size={22} />
                      <span>{c}</span>
                      {category === c && (
                        <Check className="category-check" size={13} />
                      )}
                    </label>
                  );
                })}
              </div>
            </fieldset>
            {errors.category && (
              <span id="category-error" className="field-error">
                {errors.category}
              </span>
            )}
            <fieldset className="rating-fieldset">
              <legend>
                How would you rate the overall journey?{" "}
                <span className="required">Required</span>
              </legend>
              <div className="rating-input">
                {[1, 2, 3, 4, 5].map((n) => (
                  <label key={n} className={rating >= n ? "active" : ""}>
                    <input
                      type="radio"
                      name="rating"
                      value={n}
                      checked={rating === n}
                      onChange={() => {
                        setRating(n);
                        clearFieldError("rating");
                      }}
                      disabled={saving}
                    />
                    <Star
                      size={31}
                      fill={rating >= n ? "currentColor" : "none"}
                    />
                    <span className="sr-only">
                      {n} {n === 1 ? "star" : "stars"}
                    </span>
                  </label>
                ))}
                <span>
                  {
                    [
                      "Select a rating",
                      "Very poor",
                      "Poor",
                      "Okay",
                      "Good",
                      "Excellent",
                    ][rating]
                  }
                </span>
              </div>
              {errors.rating && (
                <span className="field-error">{errors.rating}</span>
              )}
            </fieldset>
          </section>
          <section className="form-section">
            <div className="form-section-title">
              <span>03</span>
              <div>
                <h2>A little more context</h2>
                <p>Optional details can make an issue easier to understand.</p>
              </div>
            </div>
            <label className="field">
              Your experience <span className="optional">Optional</span>
              <textarea
                rows={4}
                placeholder="What happened? What would have made the journey better? Please avoid sharing names or personal contact details."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                maxLength={2000}
                disabled={saving}
              />
              <span className="character-count">
                {description.length} / 2,000
              </span>
            </label>
            <div className={"location-box " + (location ? "attached" : "")}>
              <MapPin size={22} />
              <div>
                <strong>
                  {location ? "Location attached" : "Add your current location"}
                </strong>
                <p>
                  {location
                    ? "Visible only to the project administrator."
                    : "Only add it if you're near where the issue occurred."}
                </p>
              </div>
              {location ? (
                <button
                  type="button"
                  className="icon-button"
                  aria-label="Remove attached location"
                  onClick={() => setLocation(null)}
                  disabled={saving}
                >
                  <X size={19} />
                </button>
              ) : (
                <button
                  type="button"
                  className="button secondary small"
                  onClick={locate}
                  disabled={locating || saving}
                >
                  {locating ? (
                    <>
                      <LoaderCircle size={15} className="spin" />
                      Locating…
                    </>
                  ) : (
                    "Use location"
                  )}
                </button>
              )}
            </div>
            {locationError && (
              <p className="location-error" role="status">
                {locationError}
              </p>
            )}
            <p className="field-help">
              Location is requested once, with your permission. There is no
              background tracking.
            </p>
          </section>
          <div className="form-bottom">
            <span>
              <ShieldCheck size={17} />
              Your feedback is anonymous.
            </span>
            <button
              className="button"
              disabled={saving || routes.loading || !!routes.error || locating}
            >
              {saving ? (
                <>
                  <LoaderCircle size={17} className="spin" />
                  Submitting…
                </>
              ) : (
                "Submit feedback"
              )}
            </button>
          </div>
        </form>
        <aside className="feedback-aside">
          <div className="aside-card navy">
            <BusFront size={32} />
            <h2>
              Better journeys
              <br />
              start with you.
            </h2>
            <p>
              Small details add up. Your feedback helps reveal the issues
              passengers experience every day.
            </p>
            <div className="aside-divider" />
            <div className="trust-item">
              <Check size={17} />
              <span>No passenger account</span>
            </div>
            <div className="trust-item">
              <Check size={17} />
              <span>No name or contact details</span>
            </div>
            <div className="trust-item">
              <Check size={17} />
              <span>Location is always optional</span>
            </div>
          </div>
          <div className="aside-note">
            <h3>What happens next?</h3>
            <ol>
              <li>Your report is saved securely.</li>
              <li>An administrator reviews the feedback.</li>
              <li>Aggregated insights show patterns across routes.</li>
            </ol>
            <p>
              For an immediate safety emergency, contact your local emergency
              service directly.
            </p>
          </div>
        </aside>
      </div>
    </div>
  );
}
