import { useState, type FormEvent } from "react";
import { Link, useParams, useSearchParams } from "react-router-dom";
import { ArrowRight, ShieldCheck, Check, Star } from "lucide-react";
import { api, useApi } from "../lib/api";
import { CATEGORIES } from "../types";
import { SectionLabel, ErrorBox, Badge } from "../components/ui";
import { CopyButton } from "../components/Operations";
import { timeLabel } from "../lib/ops";
import "../business.css";
type Portal = {
  organization: { name: string; kind: string; slug: string };
  routes: { id: string; code: string; origin: string; destination: string }[];
};
export default function PassengerPortal() {
  const { slug } = useParams();
  const [params] = useSearchParams();
  const portal = useApi<Portal>(
    "/api/ops/public/" + encodeURIComponent(slug || ""),
  );
  const [receipt, setReceipt] = useState<{
      id: string;
      trackingToken: string;
    } | null>(null),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false),
    [rating, setRating] = useState(0);
  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError("");
    if (!rating) {
      setError("Choose a journey rating before submitting.");
      return;
    }
    setBusy(true);
    const f = new FormData(e.currentTarget);
    try {
      setReceipt(
        await api(
          "/api/ops/public/" + encodeURIComponent(slug || "") + "/reports",
          {
            method: "POST",
            body: JSON.stringify({
              routeId: f.get("routeId"),
              category: f.get("category"),
              description: f.get("description"),
              rating,
            }),
          },
        ),
      );
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  }
  if (portal.error)
    return (
      <div className="container ops-loading">
        <ErrorBox message={portal.error} />
      </div>
    );
  if (!portal.data)
    return (
      <div className="ops-loading" role="status">
        Loading the passenger portal…
      </div>
    );
  const p = portal.data;
  const trackUrl = receipt
    ? `${location.origin}/track#${receipt.trackingToken}`
    : "";
  return (
    <div className="container passenger-portal">
      <div className="passenger-intro">
        <SectionLabel>{p.organization.name}</SectionLabel>
        <h1>
          A better journey
          <br />
          starts with <span>your voice.</span>
        </h1>
        <p>
          Your feedback goes to this organisation's transport team. Share what
          happened, then use your private receipt to follow its progress.
        </p>
        <div className="biz-proof">
          <span>
            <ShieldCheck size={17} /> No name or contact details required
          </span>
        </div>
        <Link className="text-button" to="/track">
          Already submitted? Track your report <ArrowRight size={16} />
        </Link>
        <p className="ops-footnote">
          This is a pilot feedback channel, not an emergency service. Avoid
          including personal or sensitive information in your description.
        </p>
      </div>
      {receipt ? (
        <section className="ops-auth-card passenger-receipt">
          <span className="ops-icon">
            <Check size={28} />
          </span>
          <h2>Your voice is on the record.</h2>
          <p>
            Report reference: <strong>{receipt.id}</strong>
          </p>
          <Badge status="Received" />
          <p>
            Save this private tracking code now. It cannot be recovered through
            an email in this pilot.
          </p>
          <code>{receipt.trackingToken}</code>
          <CopyButton
            value={receipt.trackingToken}
            label="Copy tracking code"
          />
          <Link className="button" to={"/track#" + receipt.trackingToken}>
            Track this report <ArrowRight size={16} />
          </Link>
          <CopyButton value={trackUrl} label="Copy private tracking link" />
          <small>
            Anyone with this code can see the report's status and route. Keep it
            private.
          </small>
        </section>
      ) : (
        <form className="ops-auth-card ops-form" onSubmit={submit}>
          <h2>Tell us about your journey.</h2>
          {!p.routes.length ? (
            <p>
              No routes are accepting feedback yet. Ask the transport team to
              add a route.
            </p>
          ) : (
            <>
              <label>
                Bus or shuttle route
                <select
                  name="routeId"
                  defaultValue={
                    p.routes.some((r) => r.id === params.get("route"))
                      ? params.get("route")!
                      : ""
                  }
                  required
                >
                  <option value="" disabled>
                    Select your route
                  </option>
                  {p.routes.map((r) => (
                    <option key={r.id} value={r.id}>
                      {r.code} · {r.origin} → {r.destination}
                    </option>
                  ))}
                </select>
              </label>
              <label>
                Issue category
                <select name="category" required defaultValue="">
                  <option value="" disabled>
                    What would you like to share?
                  </option>
                  {CATEGORIES.map((c) => (
                    <option key={c}>{c}</option>
                  ))}
                </select>
              </label>
              <fieldset className="ops-rating">
                <legend>How was your journey?</legend>
                {[1, 2, 3, 4, 5].map((n) => (
                  <button
                    key={n}
                    type="button"
                    aria-label={`Rate ${n} out of 5`}
                    aria-pressed={rating === n}
                    onClick={() => setRating(n)}
                    className={n <= rating ? "selected" : ""}
                  >
                    <Star
                      size={24}
                      fill={n <= rating ? "currentColor" : "none"}
                    />
                    <span>{n}</span>
                  </button>
                ))}
              </fieldset>
              <label>
                Your experience (optional)
                <textarea
                  name="description"
                  rows={4}
                  maxLength={2000}
                  placeholder="What happened, and what could be improved?"
                />
              </label>
              <p className="ops-footnote">
                Your report is stored for the organisation's team to review.
                This form does not collect GPS or require passenger identity.
              </p>
              {error && <ErrorBox message={error} />}
              <button className="button" disabled={busy}>
                {busy ? "Sending your report…" : "Submit anonymous report"}
                <ArrowRight size={17} />
              </button>
            </>
          )}
        </form>
      )}
    </div>
  );
}
type Tracked = {
  id: string;
  status: "Received" | "Under Review" | "Resolved";
  organization: string;
  code: string;
  origin: string;
  destination: string;
  timeline: { status: string; created_at: string }[];
};
export function TrackReport() {
  const [token, setToken] = useState(() => location.hash.slice(1)),
    [result, setResult] = useState<Tracked | null>(null),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  async function submit(e: FormEvent) {
    e.preventDefault();
    setError("");
    setResult(null);
    setBusy(true);
    try {
      setResult(
        await api<Tracked>("/api/ops/track", {
          method: "POST",
          body: JSON.stringify({ token: token.trim() }),
        }),
      );
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="container ops-track">
      <SectionLabel>Passenger follow-through</SectionLabel>
      <h1>
        Your report.
        <br />
        <span>A visible next step.</span>
      </h1>
      <p>
        Use the private tracking code from your organisation portal receipt.
      </p>
      <form className="ops-track-form" onSubmit={submit}>
        <label>
          Private tracking code
          <input
            value={token}
            onChange={(e) => setToken(e.target.value)}
            minLength={48}
            maxLength={48}
            required
            autoComplete="off"
            placeholder="Paste the 48-character code"
          />
        </label>
        <button className="button" disabled={busy}>
          {busy ? "Checking…" : "Check report status"}
          <ArrowRight size={17} />
        </button>
      </form>
      {error && <ErrorBox message={error} />}
      <p className="ops-footnote">
        This tracks workspace reports with a private code. Original Pune demo
        references beginning TV- do not have this tracking feature.
      </p>
      {result && (
        <section className="ops-panel track-result">
          <span className="eyebrow">{result.organization}</span>
          <h2>{result.id}</h2>
          <p>
            Route {result.code} · {result.origin} → {result.destination}
          </p>
          <Badge status={result.status} />
          <ol className="ops-timeline">
            {result.timeline.map((e, i) => (
              <li key={i}>
                <span />
                <div>
                  <strong>{e.status}</strong>
                  <small>{timeLabel(e.created_at)}</small>
                </div>
              </li>
            ))}
          </ol>
          <p className="ops-muted">
            Only status updates are shown here. Internal notes and the original
            description stay private.
          </p>
        </section>
      )}
    </div>
  );
}
