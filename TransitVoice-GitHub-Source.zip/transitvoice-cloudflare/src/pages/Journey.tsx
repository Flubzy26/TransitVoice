import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import {
  ArrowDownUp,
  ArrowRight,
  BusFront,
  LocateFixed,
  MapPin,
  Navigation,
  RotateCcw,
  X,
} from "lucide-react";
import JourneyMap from "../components/JourneyMap";
import { SectionLabel } from "../components/ui";
import {
  PLACES,
  distanceKm,
  matchingJourneys,
  nearestPlace,
} from "../lib/journeys";

type Road = {
  geometry: [number, number][];
  distance: number;
  duration: number;
};
export default function Journey() {
  const [fromId, setFrom] = useState("station");
  const [toId, setTo] = useState("hinjawadi");
  const [road, setRoad] = useState<Road | null>(null);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");
  const [location, setLocation] = useState<{
    lat: number;
    lng: number;
    accuracy: number;
  } | null>(null);
  const [gpsBusy, setGpsBusy] = useState(false);
  const [gpsNotice, setGpsNotice] = useState("");
  const [focus, setFocus] = useState(0);
  const request = useRef<AbortController | null>(null);
  const gpsVersion = useRef(0);
  const from = PLACES.find((p) => p.id === fromId)!;
  const to = PLACES.find((p) => p.id === toId)!;
  const matches = matchingJourneys(fromId, toId);
  useEffect(() => {
    request.current?.abort();
    request.current = null;
    setRoad(null);
    setBusy(false);
    setNotice("");
    return () => {
      request.current?.abort();
      request.current = null;
    };
  }, [fromId, toId]);
  useEffect(
    () => () => {
      gpsVersion.current++;
    },
    [],
  );
  async function plan() {
    if (fromId === toId) {
      setNotice("Choose two different places to plan a journey.");
      return;
    }
    request.current?.abort();
    const controller = new AbortController();
    request.current = controller;
    setBusy(true);
    setNotice("");
    setRoad(null);
    const timeout = window.setTimeout(() => controller.abort(), 12000);
    try {
      const response = await fetch(
        `https://router.project-osrm.org/route/v1/driving/${from.lng},${from.lat};${to.lng},${to.lat}?overview=full&geometries=geojson&steps=false`,
        { signal: controller.signal },
      );
      if (!response.ok) throw new Error("Routing unavailable");
      const data = await response.json();
      const result = data.routes?.[0];
      if (
        data.code !== "Ok" ||
        !result ||
        !Array.isArray(result.geometry?.coordinates) ||
        result.geometry.coordinates.length < 2 ||
        !Number.isFinite(result.distance) ||
        !Number.isFinite(result.duration)
      )
        throw new Error("No route");
      const coordinates = result.geometry.coordinates;
      if (
        !coordinates.every(
          (p: unknown) =>
            Array.isArray(p) &&
            p.length >= 2 &&
            Number.isFinite(p[0]) &&
            Number.isFinite(p[1]) &&
            Math.abs(p[0]) <= 180 &&
            Math.abs(p[1]) <= 90,
        )
      )
        throw new Error("Invalid route");
      if (request.current !== controller) return;
      setRoad({
        geometry: coordinates.map((p: [number, number]) => [p[1], p[0]]),
        distance: result.distance,
        duration: result.duration,
      });
      setNotice(
        "Road preview ready. This is a driving estimate, not a PMPML bus route or arrival time.",
      );
    } catch {
      if (request.current !== controller) return;
      setNotice(
        "Road routing is unavailable. The dashed line is only a straight-line preview, not directions. Try again when connected.",
      );
    } finally {
      window.clearTimeout(timeout);
      if (request.current === controller) setBusy(false);
    }
  }
  function locate() {
    if (!navigator.geolocation) {
      setGpsNotice(
        "Location is not supported. You can still choose a start manually.",
      );
      return;
    }
    const version = ++gpsVersion.current;
    setGpsBusy(true);
    setGpsNotice("");
    navigator.geolocation.getCurrentPosition(
      (position) => {
        if (gpsVersion.current !== version) return;
        const point = {
          lat: position.coords.latitude,
          lng: position.coords.longitude,
          accuracy: position.coords.accuracy,
        };
        const closest = nearestPlace(point);
        setLocation(point);
        setGpsBusy(false);
        if (distanceKm(point, closest) > 10) {
          setGpsNotice(
            "You are outside the example stop area. Choose your Pune starting point manually.",
          );
          return;
        }
        setFrom(closest.id);
        setGpsNotice(
          `Nearest example landmark: ${closest.name}. GPS accuracy: approximately ${Math.round(point.accuracy)} m. Your location is not stored.`,
        );
      },
      (error) => {
        if (gpsVersion.current !== version) return;
        setGpsBusy(false);
        setGpsNotice(
          error.code === 1
            ? "Location permission declined. Choose a start manually."
            : "Could not get your location. Choose a start manually or try again.",
        );
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 },
    );
  }
  return (
    <div className="container journey-page">
      <div className="journey-intro">
        <SectionLabel>Pune journey studio</SectionLabel>
        <h1>
          Your next stop.
          <br />
          <span>Your way there.</span>
        </h1>
        <p>
          Explore Pune, preview a road journey, and find relevant PMPML route
          examples. No sign-up. No background tracking.
        </p>
        <span className="journey-chip">
          <MapPin size={14} /> Pune & Pimpri-Chinchwad · student prototype
        </span>
      </div>
      <div className="journey-layout">
        <aside className="journey-controls">
          <div className="planner-heading">
            <Navigation size={21} />
            <h2>Plan your journey</h2>
          </div>
          <label htmlFor="journey-from">Starting point</label>
          <select
            id="journey-from"
            value={fromId}
            onChange={(e) => setFrom(e.target.value)}
          >
            {PLACES.map((p) => (
              <option value={p.id} key={p.id}>
                {p.name}
              </option>
            ))}
          </select>
          <button
            className="swap-button"
            aria-label="Swap start and destination"
            onClick={() => {
              setFrom(toId);
              setTo(fromId);
            }}
          >
            <ArrowDownUp size={16} /> Swap direction
          </button>
          <label htmlFor="journey-to">Destination</label>
          <select
            id="journey-to"
            value={toId}
            onChange={(e) => setTo(e.target.value)}
          >
            {PLACES.map((p) => (
              <option value={p.id} key={p.id}>
                {p.name}
              </option>
            ))}
          </select>
          {fromId === toId && (
            <p className="planner-notice" role="alert">
              Start and destination must be different.
            </p>
          )}
          <button
            className="button plan-button"
            disabled={busy || fromId === toId}
            onClick={plan}
          >
            <Navigation size={18} />
            {busy ? "Finding a road route…" : "Preview road route"}
            <ArrowRight size={17} />
          </button>
          <p className="planner-privacy">
            Preview sends only the two selected landmark coordinates to OSRM.
            Your GPS coordinates are not sent to the routing service.
          </p>
          <button
            className="button secondary location-button"
            disabled={gpsBusy}
            onClick={locate}
          >
            <LocateFixed size={17} />
            {gpsBusy ? "Getting location…" : "Use my location"}
          </button>
          <p className="planner-privacy">
            Optional, one-time GPS. Map tiles are fetched from OpenStreetMap,
            which can infer the map area you view. Nothing is saved to our
            database.
          </p>
          {location && (
            <button
              className="text-button"
              onClick={() => {
                gpsVersion.current++;
                setLocation(null);
                setGpsBusy(false);
                setGpsNotice("Location cleared from this session.");
              }}
            >
              <X size={14} /> Clear location
            </button>
          )}
          {gpsNotice && (
            <p className="planner-notice" role="status">
              {gpsNotice}
            </p>
          )}
        </aside>
        <section className="journey-display" aria-label="Journey preview">
          <div className="journey-map-top">
            <span>
              <span className="status-dot" /> INTERACTIVE MAP
            </span>
            <button
              className="text-button"
              onClick={() => setFocus((v) => v + 1)}
            >
              <RotateCcw size={14} /> Fit route
            </button>
          </div>
          <JourneyMap
            from={from}
            to={to}
            geometry={road?.geometry || null}
            location={location}
            focus={focus}
          />
          <div className="journey-metrics">
            <div>
              <small>{road ? "Road distance" : "Straight-line distance"}</small>
              <strong>
                {(road ? road.distance / 1000 : distanceKm(from, to)).toFixed(
                  1,
                )}{" "}
                <em>km</em>
              </strong>
            </div>
            <div>
              <small>Driving estimate · no live traffic</small>
              <strong>
                {road ? Math.max(1, Math.round(road.duration / 60)) : "—"}{" "}
                <em>{road ? "min" : "Preview to calculate"}</em>
              </strong>
            </div>
          </div>
          {notice && (
            <p className="planner-notice road-notice" role="status">
              {notice}
            </p>
          )}
        </section>
      </div>
      <section className="journey-matches">
        <div>
          <SectionLabel>Connect the journey to your voice</SectionLabel>
          <h2>Relevant bus route examples</h2>
          <p>
            Matches use selected stops in our small demo dataset, not a complete
            timetable. Confirm actual service with PMPML before travelling.
          </p>
        </div>
        <div className="journey-route-cards">
          {matches.length ? (
            matches.map((r) => (
              <article className="journey-route-card" key={r.id}>
                <span className="route-number">{r.code}</span>
                <div>
                  <h3>
                    {from.name} → {to.name}
                  </h3>
                  <p>Selected-stop match · example direction</p>
                  <Link to={`/feedback?route=${r.id}`} className="text-button">
                    Share feedback on route {r.code} <ArrowRight size={16} />
                  </Link>
                </div>
                <BusFront size={25} />
              </article>
            ))
          ) : (
            <div className="journey-empty">
              <BusFront size={28} />
              <h3>No direct example in our dataset</h3>
              <p>
                This does not mean no bus exists. Our prototype covers six
                example routes and does not calculate bus transfers.
              </p>
            </div>
          )}
        </div>
      </section>
      <div className="journey-disclaimer">
        Approximate landmark pins, not exact boarding locations. Road preview
        uses a public OSRM demo service and is not an official bus alignment,
        bus ETA, fare, or live tracking feed. Internet is required for map tiles
        and road routing.
      </div>
    </div>
  );
}
