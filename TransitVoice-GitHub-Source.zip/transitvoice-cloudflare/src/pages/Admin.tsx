import { useEffect, useRef, useState, type FormEvent } from "react";
import {
  ShieldCheck,
  LockKeyhole,
  Eye,
  EyeOff,
  LogOut,
  Search,
  SlidersHorizontal,
  RotateCcw,
  X,
  MapPin,
  LoaderCircle,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  LayoutDashboard,
} from "lucide-react";
import { api, ApiError, useApi, query, dateLabel } from "../lib/api";
import {
  CATEGORIES,
  STATUSES,
  EMPTY_FILTERS,
  type Route,
  type Stats,
  type Report,
  type Status,
} from "../types";
import {
  SectionLabel,
  ErrorBox,
  Loading,
  StatsCards,
  Badge,
  Stars,
  Empty,
} from "../components/ui";
import { Charts } from "../components/Charts";
export default function Admin() {
  const [auth, setAuth] = useState<string | null>(null);
  const [checking, setChecking] = useState(true);
  const [error, setError] = useState("");
  useEffect(() => {
    api<{ email: string }>("/api/admin/session")
      .then((r) => setAuth(r.email))
      .catch((e) => {
        if (!(e instanceof ApiError && e.status === 401)) setError(e.message);
      })
      .finally(() => setChecking(false));
  }, []);
  if (checking)
    return (
      <div className="container">
        <Loading />
      </div>
    );
  if (auth) return <Dashboard email={auth} onLogout={() => setAuth(null)} />;
  return <Login onLogin={setAuth} initialError={error} />;
}
function Login({
  onLogin,
  initialError,
}: {
  onLogin: (email: string) => void;
  initialError: string;
}) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(initialError);
  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      const data = await api<{ email: string }>("/api/admin/login", {
        method: "POST",
        body: JSON.stringify({ email, password }),
      });
      onLogin(data.email);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="container login-page">
      <div className="login-story">
        <SectionLabel>The other side of the conversation</SectionLabel>
        <h1>
          Listen better.
          <br />
          See patterns.
          <br />
          <span>Move forward.</span>
        </h1>
        <p>
          A workspace for understanding passenger feedback and keeping every
          report moving.
        </p>
        <div className="login-feature">
          <LayoutDashboard size={22} />
          <div>
            <strong>One place for every report</strong>
            <span>Search, filter, and review passenger experiences.</span>
          </div>
        </div>
        <div className="login-feature">
          <ShieldCheck size={22} />
          <div>
            <strong>Access for administrators</strong>
            <span>Passenger feedback stays behind a protected session.</span>
          </div>
        </div>
      </div>
      <form className="panel login-card" onSubmit={submit}>
        <span className="login-icon">
          <LockKeyhole size={24} />
        </span>
        <h2>Welcome back.</h2>
        <p>Sign in to the admin workspace.</p>
        {error && <ErrorBox message={error} />}
        <label className="field">
          Admin email
          <input
            type="email"
            autoComplete="username"
            placeholder="you@example.com"
            required
            maxLength={254}
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            disabled={busy}
          />
        </label>
        <label className="field">
          Password
          <div className="password-field">
            <input
              type={show ? "text" : "password"}
              autoComplete="current-password"
              required
              maxLength={256}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              disabled={busy}
            />
            <button
              type="button"
              className="icon-button"
              onClick={() => setShow(!show)}
              aria-label={show ? "Hide password" : "Show password"}
            >
              {show ? <EyeOff size={18} /> : <Eye size={18} />}
            </button>
          </div>
        </label>
        <button className="button full" disabled={busy}>
          {busy ? (
            <>
              <LoaderCircle size={17} className="spin" />
              Signing in…
            </>
          ) : (
            "Sign in to dashboard"
          )}
        </button>
        <p className="login-help">
          <ShieldCheck size={16} />
          Access is managed by the project administrator.
        </p>
      </form>
    </div>
  );
}
function Dashboard({
  email,
  onLogout,
}: {
  email: string;
  onLogout: () => void;
}) {
  const routes = useApi<Route[]>("/api/routes?archived=1");
  const [filters, setFilters] = useState({ ...EMPTY_FILTERS });
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const [selected, setSelected] = useState<Report | null>(null);
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");
  useEffect(() => {
    const timer = setTimeout(() => {
      setFilters((f) => ({ ...f, q: search }));
      setPage(1);
    }, 300);
    return () => clearTimeout(timer);
  }, [search]);
  useEffect(() => {
    if (notice) {
      const t = setTimeout(() => setNotice(""), 6000);
      return () => clearTimeout(t);
    }
  }, [notice]);
  const stats = useApi<Stats>("/api/admin/stats?" + query(filters));
  const reports = useApi<{
    reports: Report[];
    total: number;
    page: number;
    pageSize: number;
  }>("/api/admin/reports?" + query({ ...filters, page }));
  const set = (key: string, value: string) => {
    setFilters((f) => ({ ...f, [key]: value }));
    setPage(1);
  };
  async function logout() {
    try {
      await api("/api/admin/logout", { method: "POST", body: "{}" });
      onLogout();
    } catch (e) {
      if (e instanceof ApiError && e.status === 401) onLogout();
      else setError((e as Error).message);
    }
  }
  return (
    <div className="container workspace-page">
      <div className="workspace-top">
        <span className="workspace-tag">
          <ShieldCheck size={14} />
          ADMIN WORKSPACE
        </span>
        <div>
          <span className="signed-in">{email}</span>
          <button className="text-button" onClick={logout}>
            <LogOut size={15} />
            Sign out
          </button>
        </div>
      </div>
      <div className="page-intro split admin-intro">
        <div>
          <SectionLabel>Listen. Understand. Respond.</SectionLabel>
          <h1>The passenger perspective.</h1>
          <p>Turn individual reports into a clearer picture of your routes.</p>
        </div>
        <span className="small-chip">Pune · PMPML examples</span>
      </div>
      {notice && (
        <div className="toast" role="status">
          <CheckCircle2 size={19} />
          {notice}
          <button
            className="icon-button"
            aria-label="Dismiss notification"
            onClick={() => setNotice("")}
          >
            <X size={16} />
          </button>
        </div>
      )}
      {error && <ErrorBox message={error} />}
      <section className="panel filters-panel" aria-label="Filter reports">
        <div className="filter-heading">
          <SlidersHorizontal size={17} />
          <strong>Find the feedback that matters</strong>
          <button
            className="text-button"
            onClick={() => {
              setFilters({ ...EMPTY_FILTERS });
              setSearch("");
              setPage(1);
            }}
          >
            <RotateCcw size={14} />
            Reset filters
          </button>
        </div>
        <div className="filters-grid admin-filters">
          <label className="field search-field">
            Search reports
            <div className="input-with-icon">
              <Search size={17} />
              <input
                value={search}
                maxLength={100}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Reference, bus, or description"
              />
            </div>
          </label>
          <label className="field">
            Route
            <select
              value={filters.route}
              onChange={(e) => set("route", e.target.value)}
            >
              <option value="">All routes</option>
              {routes.data?.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.code} · {r.origin}
                  {!r.is_active ? " (archived example)" : ""}
                </option>
              ))}
            </select>
          </label>
          <label className="field">
            Issue category
            <select
              value={filters.category}
              onChange={(e) => set("category", e.target.value)}
            >
              <option value="">All issues</option>
              {CATEGORIES.map((c) => (
                <option key={c}>{c}</option>
              ))}
            </select>
          </label>
          <label className="field">
            Status
            <select
              value={filters.status}
              onChange={(e) => set("status", e.target.value)}
            >
              <option value="">All statuses</option>
              {STATUSES.map((s) => (
                <option key={s}>{s}</option>
              ))}
            </select>
          </label>
          <label className="field">
            Data source
            <select
              value={filters.source}
              onChange={(e) => set("source", e.target.value)}
            >
              <option value="all">All reports</option>
              <option value="community">Community only</option>
              <option value="demo">Demo only</option>
            </select>
          </label>
          <label className="field">
            From date (UTC)
            <input
              type="date"
              value={filters.from}
              max={filters.to || undefined}
              onChange={(e) => set("from", e.target.value)}
            />
          </label>
          <label className="field">
            To date (UTC)
            <input
              type="date"
              value={filters.to}
              min={filters.from || undefined}
              onChange={(e) => set("to", e.target.value)}
            />
          </label>
        </div>
      </section>
      {stats.error ? (
        <ErrorBox message={stats.error} retry={stats.refresh} />
      ) : stats.loading ? (
        <Loading />
      ) : (
        stats.data && <StatsCards stats={stats.data} />
      )}
      <section className="panel reports-panel">
        <div className="panel-heading">
          <div>
            <h3>
              Passenger reports{" "}
              <span className="count-badge">{reports.data?.total ?? 0}</span>
            </h3>
            <p>
              Read the details. Review the issue. Keep the status up to date.
            </p>
          </div>
          <span className="small-chip">Newest first</span>
        </div>
        {reports.error ? (
          <ErrorBox message={reports.error} retry={reports.refresh} />
        ) : reports.loading ? (
          <Loading />
        ) : reports.data?.reports.length ? (
          <>
            <div className="table-scroll">
              <table className="reports-table">
                <thead>
                  <tr>
                    <th>Report / issue</th>
                    <th>Bus route</th>
                    <th>Rating</th>
                    <th>Submitted</th>
                    <th>Status</th>
                    <th>
                      <span className="sr-only">Action</span>
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {reports.data.reports.map((r) => (
                    <tr key={r.id}>
                      <td>
                        <div className="report-category">
                          {r.category}
                          {!!r.is_demo && (
                            <span className="demo-small">DEMO</span>
                          )}
                        </div>
                        <span className="report-id">{r.id}</span>
                      </td>
                      <td>
                        <div className="table-route">
                          <span className="route-pill">{r.route_code}</span>
                          <div>
                            {r.origin}
                            <small>{r.destination}</small>
                          </div>
                        </div>
                      </td>
                      <td>
                        <Stars rating={r.rating} />
                      </td>
                      <td>
                        <span className="date-cell">
                          {dateLabel(r.created_at)}
                        </span>
                      </td>
                      <td>
                        <Badge status={r.status} />
                      </td>
                      <td>
                        <button
                          className="review-button"
                          onClick={() => setSelected(r)}
                          aria-label={`Review report ${r.id}`}
                        >
                          Review
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="pagination">
              <span>
                Showing {(page - 1) * 10 + 1}–
                {Math.min(page * 10, reports.data.total)} of{" "}
                {reports.data.total}
              </span>
              <div>
                <button
                  className="icon-button"
                  aria-label="Previous page"
                  disabled={page === 1}
                  onClick={() => setPage((p) => p - 1)}
                >
                  <ChevronLeft size={18} />
                </button>
                <span>
                  Page {page} of {Math.ceil(reports.data.total / 10)}
                </span>
                <button
                  className="icon-button"
                  aria-label="Next page"
                  disabled={page * 10 >= reports.data.total}
                  onClick={() => setPage((p) => p + 1)}
                >
                  <ChevronRight size={18} />
                </button>
              </div>
            </div>
          </>
        ) : (
          <Empty title="No reports match your filters">
            Try a different route, date range, or search term.
          </Empty>
        )}
      </section>
      {stats.data && !stats.loading && !stats.error && (
        <Charts stats={stats.data} />
      )}
      <p className="data-footnote">
        Demo reports are fictional and marked DEMO. Real submissions remain
        anonymous unless the description itself includes identifying details.
      </p>
      {selected && (
        <ReportDialog
          report={selected}
          onClose={() => setSelected(null)}
          onSaved={() => {
            setSelected(null);
            reports.refresh();
            stats.refresh();
            setNotice("Report status updated.");
          }}
          onExpired={onLogout}
        />
      )}
    </div>
  );
}
function ReportDialog({
  report,
  onClose,
  onSaved,
  onExpired,
}: {
  report: Report;
  onClose: () => void;
  onSaved: () => void;
  onExpired: () => void;
}) {
  const ref = useRef<HTMLDialogElement>(null);
  const [status, setStatus] = useState<Status>(report.status);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  useEffect(() => {
    ref.current?.showModal();
    return () => ref.current?.close();
  }, []);
  async function save(e: FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError("");
    try {
      await api("/api/admin/reports/" + encodeURIComponent(report.id), {
        method: "PATCH",
        body: JSON.stringify({ status }),
      });
      onSaved();
    } catch (e) {
      if (e instanceof ApiError && e.status === 401) onExpired();
      else setError((e as Error).message);
    } finally {
      setSaving(false);
    }
  }
  return (
    <dialog
      ref={ref}
      className="report-dialog"
      onCancel={(e) => {
        if (saving) e.preventDefault();
        else onClose();
      }}
      aria-labelledby="report-title"
    >
      <div className="dialog-head">
        <div>
          <span className="overline">
            PASSENGER REPORT {report.is_demo ? "· DEMO" : ""}
          </span>
          <h2 id="report-title">{report.category}</h2>
          <span className="report-id">{report.id}</span>
        </div>
        <button
          className="icon-button"
          onClick={onClose}
          disabled={saving}
          aria-label="Close report"
        >
          <X />
        </button>
      </div>
      <div className="dialog-body">
        <div className="detail-route">
          <span className="route-pill">{report.route_code}</span>
          <strong>
            {report.origin} / {report.destination}
          </strong>
        </div>
        <div className="detail-grid">
          <div>
            <span>Journey rating</span>
            <Stars rating={report.rating} />
          </div>
          <div>
            <span>Bus number</span>
            <strong>{report.bus_number || "Not supplied"}</strong>
          </div>
          <div>
            <span>Submitted</span>
            <strong>{dateLabel(report.created_at)}</strong>
          </div>
          <div>
            <span>Passenger</span>
            <strong>Anonymous</strong>
          </div>
        </div>
        <h3>The passenger's experience</h3>
        <p className="report-description">
          {report.description || "No written description was supplied."}
        </p>
        {report.latitude !== null && report.longitude !== null && (
          <div className="notice info">
            <MapPin size={19} />
            <span>
              Location shared: {report.latitude.toFixed(4)},{" "}
              {report.longitude.toFixed(4)}
              <br />
              <small>Admin only. Not included in public insights.</small>
            </span>
          </div>
        )}
        <form onSubmit={save}>
          {error && <ErrorBox message={error} />}
          <label className="field">
            Report status
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value as Status)}
              disabled={saving}
            >
              {STATUSES.map((s) => (
                <option key={s}>{s}</option>
              ))}
            </select>
          </label>
          <div className="dialog-actions">
            <button
              type="button"
              className="button secondary"
              onClick={onClose}
              disabled={saving}
            >
              Cancel
            </button>
            <button
              className="button"
              disabled={saving || status === report.status}
            >
              {saving ? "Saving…" : "Save status"}
            </button>
          </div>
        </form>
      </div>
    </dialog>
  );
}
