import { useEffect, useState, type FormEvent } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import {
  ArrowRight,
  Building2,
  LayoutDashboard,
  Inbox,
  Route,
  Users,
  Settings,
  LogOut,
  ExternalLink,
  ShieldCheck,
} from "lucide-react";
import { api, ApiError } from "../lib/api";
import type { Identity } from "../lib/ops";
import { ErrorBox, SectionLabel } from "../components/ui";
import {
  OpsOverview,
  OpsInbox,
  OpsRoutes,
  OpsTeam,
  OpsSettings,
} from "../components/Operations";
import "../business.css";

export default function Workspace({ join = false }: { join?: boolean }) {
  const [me, setMe] = useState<Identity | null>(null),
    [loading, setLoading] = useState(true),
    [error, setError] = useState("");
  const [params, setParams] = useSearchParams();
  const navigate = useNavigate();
  const load = async () => {
    setError("");
    try {
      setMe(await api<Identity>("/api/ops/me"));
    } catch (e) {
      if (!(e instanceof ApiError && e.status === 401))
        setError((e as Error).message);
      setMe(null);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    void load();
  }, []);
  if (join)
    return (
      <AuthForm
        join
        onSuccess={async () => {
          await load();
          navigate("/workspace", { replace: true });
        }}
      />
    );
  if (loading)
    return (
      <div className="ops-loading" role="status">
        Opening your workspace…
      </div>
    );
  if (error)
    return (
      <div className="container ops-loading">
        <ErrorBox message={error} retry={load} />
      </div>
    );
  if (!me) return <AuthForm onSuccess={load} />;
  const tab = params.get("tab") || "overview";
  const tabs = [
    { id: "overview", name: "Overview", icon: LayoutDashboard },
    { id: "inbox", name: "Report inbox", icon: Inbox },
    { id: "routes", name: "Routes & QR", icon: Route },
    { id: "team", name: "Team", icon: Users },
    { id: "settings", name: "Settings", icon: Settings },
  ];
  async function logout() {
    try {
      await api("/api/ops/logout", { method: "POST", body: "{}" });
      setMe(null);
      setParams({});
    } catch (e) {
      setError((e as Error).message);
    }
  }
  return (
    <div className="ops-shell">
      <aside className="ops-sidebar">
        <div className="ops-org-icon">
          <Building2 size={24} />
        </div>
        <strong>{me.org_name}</strong>
        <span className="ops-workspace-label">{me.kind} workspace · Pilot</span>
        <nav aria-label="Workspace navigation">
          {tabs.map((t) => (
            <button
              className={tab === t.id ? "active" : ""}
              key={t.id}
              onClick={() => setParams({ tab: t.id })}
            >
              <t.icon size={18} />
              {t.name}
            </button>
          ))}
        </nav>
        <Link to={`/p/${me.slug}`} className="ops-portal-link">
          <ExternalLink size={16} /> Passenger portal
        </Link>
        <div className="ops-user">
          <span className="ops-avatar">
            {me.name.slice(0, 1).toUpperCase()}
          </span>
          <div>
            <strong>{me.name}</strong>
            <small>{me.role}</small>
          </div>
        </div>
        <button className="text-button" onClick={logout}>
          <LogOut size={15} /> Sign out
        </button>
      </aside>
      <section className="ops-main">
        <div className="ops-topline">
          <span>
            <span className="status-dot" /> YOUR OPERATIONS WORKSPACE
          </span>
          <span className="ops-role">
            <ShieldCheck size={13} />
            {me.role}
          </span>
        </div>
        {tab === "overview" ? (
          <OpsOverview me={me} openInbox={() => setParams({ tab: "inbox" })} />
        ) : tab === "inbox" ? (
          <OpsInbox me={me} />
        ) : tab === "routes" ? (
          <OpsRoutes me={me} />
        ) : tab === "team" ? (
          <OpsTeam me={me} />
        ) : tab === "settings" ? (
          <OpsSettings me={me} refresh={load} />
        ) : (
          <p>Choose a workspace section.</p>
        )}
      </section>
    </div>
  );
}
function AuthForm({
  onSuccess,
  join = false,
}: {
  onSuccess: () => void;
  join?: boolean;
}) {
  const [params, setParams] = useSearchParams();
  const registering = !join && params.get("mode") === "register";
  const [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  const [invite] = useState(() => window.location.hash.slice(1));
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const f = new FormData(event.currentTarget);
    setBusy(true);
    setError("");
    const body = Object.fromEntries(f.entries());
    if (join) body.token = invite;
    try {
      await api(
        `/api/ops/${join ? "join" : registering ? "register" : "login"}`,
        { method: "POST", body: JSON.stringify(body) },
      );
      onSuccess();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="container ops-auth">
      <div className="ops-auth-story">
        <SectionLabel>Your transport team, connected</SectionLabel>
        <h1>
          Less chasing.
          <br />
          <span>More resolving.</span>
        </h1>
        <p>
          A dedicated place for routes, passenger voices and the people
          responsible for making things better.
        </p>
        <div className="auth-story-line">
          <span>01</span>
          <p>Listen without collecting passenger identities.</p>
        </div>
        <div className="auth-story-line">
          <span>02</span>
          <p>Assign responsibility and keep a clear history.</p>
        </div>
        <div className="auth-story-line">
          <span>03</span>
          <p>Use your own data to improve the next journey.</p>
        </div>
        <Link className="text-button" to="/community">
          Just exploring? Open the Pune demo <ArrowRight size={16} />
        </Link>
      </div>
      <form className="ops-auth-card" onSubmit={submit}>
        <span className="ops-icon">
          <Building2 size={24} />
        </span>
        <h2>
          {join
            ? "Join your team"
            : registering
              ? "Create your workspace"
              : "Welcome to your workspace"}
        </h2>
        <p>
          {join
            ? "Use your private invitation to create a team account."
            : registering
              ? "Start a working pilot. No card or payment required."
              : "Use your workspace account, not the Pune demo admin."}
        </p>
        {(registering || join) && (
          <label>
            Your name
            <input
              name="name"
              required
              minLength={2}
              maxLength={100}
              autoComplete="name"
            />
          </label>
        )}
        {registering && (
          <>
            <label>
              Organisation name
              <input
                name="organization"
                required
                minLength={2}
                maxLength={100}
              />
            </label>
            <label>
              Transport operation
              <select name="kind">
                <option>College</option>
                <option>Company</option>
                <option>Operator</option>
              </select>
            </label>
          </>
        )}
        <label>
          Email
          <input
            name="email"
            type="email"
            required
            maxLength={254}
            autoComplete="email"
          />
        </label>
        <label>
          Password
          <input
            name="password"
            type="password"
            required
            minLength={registering || join ? 12 : 1}
            maxLength={128}
            autoComplete={
              registering || join ? "new-password" : "current-password"
            }
          />
        </label>
        {(registering || join) && (
          <small>
            Use at least 12 characters. Email verification and email recovery
            are not configured in this pilot.
          </small>
        )}
        {error && <ErrorBox message={error} />}
        <button className="button" disabled={busy || (join && !invite)}>
          {busy
            ? "Please wait…"
            : join
              ? "Join workspace"
              : registering
                ? "Create workspace"
                : "Sign in"}
          <ArrowRight size={17} />
        </button>
        {join && !invite && (
          <p role="alert">
            This link is missing its invitation code. Ask your owner for a new
            link.
          </p>
        )}
        {!join && (
          <button
            type="button"
            className="text-button"
            onClick={() => {
              setError("");
              setParams(registering ? {} : { mode: "register" });
            }}
          >
            {registering
              ? "Already have an account? Sign in"
              : "New here? Create a workspace"}
          </button>
        )}
        <Link to="/admin" className="ops-demo-login">
          Looking for the original Pune demo admin?
        </Link>
      </form>
    </div>
  );
}
