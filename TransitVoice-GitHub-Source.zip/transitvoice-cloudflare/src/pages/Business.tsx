import { Link } from "react-router-dom";
import {
  ArrowRight,
  ArrowUpRight,
  Check,
  Building2,
  BusFront,
  QrCode,
  ShieldCheck,
  CircleCheck,
  Users,
  Route,
  MessageSquareText,
  Activity,
} from "lucide-react";
import { SectionLabel } from "../components/ui";
import "../business.css";
export default function Business() {
  return (
    <div className="business-page">
      <section className="biz-hero container">
        <div className="biz-hero-copy">
          <SectionLabel>TransitVoice for transport teams</SectionLabel>
          <h1>
            Better commutes.
            <br />
            Fewer blind spots.
            <br />
            <span>Every voice counts.</span>
          </h1>
          <p>
            Turn passenger feedback into an organised service desk. Know what
            needs attention, give your team ownership, and show passengers what
            happens next.
          </p>
          <div className="hero-actions">
            <Link to="/workspace?mode=register" className="button">
              Create your workspace <ArrowRight size={18} />
            </Link>
            <Link to="/community" className="button secondary">
              Explore the Pune demo
            </Link>
          </div>
          <div className="biz-proof">
            <span>
              <ShieldCheck size={16} /> Separate workspaces
            </span>
            <span>
              <Check size={16} /> Anonymous passenger reports
            </span>
          </div>
          <p className="biz-small">
            Working pilot software · no payment required · no live bus feed
          </p>
        </div>
        <div
          className="biz-product-preview"
          aria-label="Illustrative workflow preview"
        >
          <div className="preview-top">
            <span className="preview-logo">tv</span>
            <strong>Campus transport</strong>
            <span className="preview-pill">Illustration</span>
          </div>
          <div className="preview-title">
            <span>THE OPERATIONS PICTURE</span>
            <h2>
              A clear path
              <br />
              from issue to action.
            </h2>
          </div>
          <div className="preview-map">
            <svg viewBox="0 0 420 180" aria-hidden="true">
              <path
                className="preview-grid"
                d="M0 40H420 M0 90H420 M0 140H420 M60 0V180 M150 0V180 M240 0V180 M330 0V180"
              />
              <path
                className="preview-road"
                d="M30 130H100Q125 130 125 105V65Q125 45 150 45H245Q265 45 265 70V110Q265 130 290 130H390"
              />
              <circle cx="30" cy="130" r="9" />
              <circle cx="245" cy="45" r="9" />
              <circle cx="390" cy="130" r="9" />
            </svg>
            <span className="map-campus">CAMPUS</span>
            <span className="map-city">CITY CENTRE</span>
            <div className="preview-bus">
              <BusFront size={22} />
            </div>
          </div>
          <div className="preview-ticket">
            <span className="priority-dot" />
            <div>
              <strong>Morning shuttle overcrowding</strong>
              <small>Passenger report → assigned to transport team</small>
            </div>
            <ArrowUpRight size={19} />
          </div>
          <div className="preview-steps">
            <span>
              <MessageSquareText size={17} /> Receive
            </span>
            <i />
            <span>
              <Users size={17} /> Assign
            </span>
            <i />
            <span>
              <CircleCheck size={17} /> Resolve
            </span>
          </div>
        </div>
      </section>
      <section className="biz-audiences container">
        <span>ONE WORKSPACE FOR YOUR TRANSPORT OPERATION</span>
        <div>
          <Building2 /> Colleges & universities
        </div>
        <div>
          <Users /> Employee shuttles
        </div>
        <div>
          <BusFront /> Private operators
        </div>
      </section>
      <section className="container biz-section">
        <div className="biz-section-heading">
          <div>
            <SectionLabel>
              From scattered complaints to accountable action
            </SectionLabel>
            <h2>
              Feedback is the start.
              <br />
              Follow-through is the product.
            </h2>
          </div>
          <p>
            Give passengers a simple way to speak up—and your team a structured
            way to respond.
          </p>
        </div>
        <div className="biz-features">
          {[
            [
              QrCode,
              "One scan. One voice.",
              "Create a route, download its QR code, and give passengers an anonymous feedback form.",
            ],
            [
              Activity,
              "See what needs attention.",
              "Review recurring categories, overdue reports and route-level ratings from your own data.",
            ],
            [
              Users,
              "Put someone in charge.",
              "Invite managers and agents. Assign reports, set priorities and keep internal notes.",
            ],
            [
              ShieldCheck,
              "Keep the boundaries clear.",
              "Separate organisation data, restricted staff views and private passenger tracking codes.",
            ],
            [
              Route,
              "Close the feedback loop.",
              "Passengers can revisit their private tracking page to see status changes over time.",
            ],
            [
              ArrowUpRight,
              "Bring the evidence.",
              "Filter reports and export a spreadsheet-ready CSV for service reviews and follow-ups.",
            ],
          ].map(([Icon, title, body]) => {
            const I = Icon as typeof QrCode;
            return (
              <article key={String(title)} className="biz-feature">
                <span>
                  <I size={23} />
                </span>
                <h3>{String(title)}</h3>
                <p>{String(body)}</p>
              </article>
            );
          })}
        </div>
      </section>
      <section className="biz-process">
        <div className="container">
          <SectionLabel>Your first pilot, in three steps</SectionLabel>
          <div className="biz-process-grid">
            {[
              [
                "01",
                "Set up your operation",
                "Create a workspace and add your own shuttle routes.",
              ],
              [
                "02",
                "Make feedback visible",
                "Share a passenger link or print a route QR poster.",
              ],
              [
                "03",
                "Build a response habit",
                "Assign a report, add context, resolve it and review the trend.",
              ],
            ].map(([n, title, body]) => (
              <div key={n}>
                <span>{n}</span>
                <h3>{title}</h3>
                <p>{body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
      <section className="container biz-section" id="plans">
        <div className="biz-section-heading">
          <div>
            <SectionLabel>A practical starting point</SectionLabel>
            <h2>Start with a real pilot.</h2>
          </div>
          <p>
            Commercial packaging is a roadmap, not a checkout. There are no
            charges or automatic subscriptions in this version.
          </p>
        </div>
        <div className="biz-plans">
          <article className="biz-plan featured">
            <span className="preview-pill">AVAILABLE NOW</span>
            <h3>Pilot</h3>
            <strong>No payment required</strong>
            <p>For testing a transport feedback workflow with your team.</p>
            <ul>
              <li>Up to 10 active routes</li>
              <li>Up to 10 active team members</li>
              <li>Assignment, timelines and CSV export</li>
              <li>Passenger portal and QR posters</li>
            </ul>
            <Link className="button" to="/workspace?mode=register">
              Start your pilot <ArrowRight size={16} />
            </Link>
          </article>
          <article className="biz-plan">
            <span className="preview-pill">PLANNED PACKAGE</span>
            <h3>Team</h3>
            <strong>Commercial terms not set</strong>
            <p>A future paid package for larger operations.</p>
            <ul>
              <li>Expanded route and team limits</li>
              <li>Scheduled service reports</li>
              <li>Email notifications and support</li>
            </ul>
            <p className="biz-small">
              These additions are not enabled. Record your interest in workspace
              settings.
            </p>
          </article>
          <article className="biz-plan">
            <span className="preview-pill">FUTURE INTEGRATIONS</span>
            <h3>Enterprise</h3>
            <strong>Scope before promises</strong>
            <p>
              For requirements that need provider agreements and implementation.
            </p>
            <ul>
              <li>SSO and deployment options</li>
              <li>Approved vehicle GPS feeds</li>
              <li>Operator-system integrations</li>
            </ul>
            <p className="biz-small">
              No official transport authority connection is currently provided.
            </p>
          </article>
        </div>
      </section>
      <section className="container biz-faq">
        <h2>Clear answers, before you start.</h2>
        {[
          [
            "Is this connected to PMPML?",
            "No. The Pune passenger experience is an independent student demo. Your organisation workspace contains only your own routes and reports.",
          ],
          [
            "Do passengers need an account?",
            "No. They can report anonymously and receive a private tracking code. Staff need an invited or owner account.",
          ],
          [
            "Is this ready to charge customers?",
            "This is a working pilot foundation. Payments, email delivery, verified account recovery, production hosting and an operational support process still need setup before a paid launch.",
          ],
          [
            "Can QR codes work on passengers’ phones?",
            "Yes, when your deployment URL is reachable from those phones. A localhost QR code only points to the scanning device itself; deploy with HTTPS before distributing posters.",
          ],
        ].map(([q, a]) => (
          <details key={q}>
            <summary>{q}</summary>
            <p>{a}</p>
          </details>
        ))}
      </section>
      <section className="container biz-bottom">
        <div>
          <SectionLabel>Make the next journey better</SectionLabel>
          <h2>
            Start small. Listen closely.
            <br />
            Build a service people trust.
          </h2>
        </div>
        <Link className="button" to="/workspace?mode=register">
          Create a workspace <ArrowRight size={18} />
        </Link>
      </section>
    </div>
  );
}
