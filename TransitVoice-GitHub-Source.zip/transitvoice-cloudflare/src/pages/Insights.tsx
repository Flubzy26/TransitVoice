import { Link } from "react-router-dom";
import { useState } from "react";
import { SlidersHorizontal, RotateCcw, Info } from "lucide-react";
import { useApi, query } from "../lib/api";
import { EMPTY_FILTERS, type Route, type Stats } from "../types";
import { SectionLabel, StatsCards, Loading, ErrorBox } from "../components/ui";
import { Charts, RouteTable } from "../components/Charts";
export default function Insights() {
  const routes = useApi<Route[]>("/api/routes");
  const [filters, setFilters] = useState({ ...EMPTY_FILTERS });
  const result = useApi<Stats>("/api/insights?" + query(filters));
  const set = (key: string, value: string) =>
    setFilters((f) => ({ ...f, [key]: value }));
  return (
    <div className="container workspace-page">
      <div className="page-intro split">
        <div>
          <SectionLabel>A shared view of the journey</SectionLabel>
          <h1>Community insights</h1>
          <p>See the patterns behind the passenger experience.</p>
        </div>
        <Link to="/feedback" className="button secondary">
          Add your voice
        </Link>
      </div>
      <div className="notice info">
        <Info size={19} />
        <span>
          Pune PMPML route examples with fictional demo feedback. Demo reports
          can be excluded using the data source filter. Only aggregate feedback
          is shown here.
        </span>
      </div>
      <section
        className="panel filters-panel"
        aria-label="Filter community insights"
      >
        <div className="filter-heading">
          <SlidersHorizontal size={17} />
          <strong>Explore the data</strong>
          <button
            className="text-button"
            onClick={() => setFilters({ ...EMPTY_FILTERS })}
          >
            <RotateCcw size={14} />
            Reset
          </button>
        </div>
        <div className="filters-grid public-filters">
          <label className="field">
            Route
            <select
              value={filters.route}
              onChange={(e) => set("route", e.target.value)}
            >
              <option value="">All routes</option>
              {routes.data?.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.code} · {r.origin}
                </option>
              ))}
            </select>
          </label>
          <label className="field">
            Data source
            <select
              value={filters.source}
              onChange={(e) => set("source", e.target.value)}
            >
              <option value="all">All reports (includes demo)</option>
              <option value="community">Community submissions only</option>
              <option value="demo">Demo reports only</option>
            </select>
          </label>
          <label className="field">
            From date (UTC)
            <input
              type="date"
              value={filters.from}
              max={filters.to || undefined}
              onChange={(e) => set("from", e.target.value)}
            />
          </label>
          <label className="field">
            To date (UTC)
            <input
              type="date"
              value={filters.to}
              min={filters.from || undefined}
              onChange={(e) => set("to", e.target.value)}
            />
          </label>
        </div>
      </section>
      {result.error ? (
        <ErrorBox message={result.error} retry={result.refresh} />
      ) : result.loading ? (
        <Loading />
      ) : (
        result.data && (
          <>
            <StatsCards stats={result.data} />
            <Charts stats={result.data} />
            <RouteTable stats={result.data} />
          </>
        )
      )}
      <p className="data-footnote">
        Ratings and report statuses reflect feedback in this prototype. They are
        not official service performance ratings.
      </p>
    </div>
  );
}
