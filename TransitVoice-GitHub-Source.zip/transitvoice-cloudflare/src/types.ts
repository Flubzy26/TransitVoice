export const CATEGORIES = [
  "Delay",
  "Overcrowding",
  "Accessibility",
  "Cleanliness",
  "Safety",
  "Staff conduct",
  "Other",
] as const;
export const STATUSES = ["Received", "Under Review", "Resolved"] as const;
export type Category = (typeof CATEGORIES)[number];
export type Status = (typeof STATUSES)[number];
export interface Route {
  is_active: number;
  id: number;
  code: string;
  origin: string;
  destination: string;
  color: string;
  stops: string[];
}
export interface Report {
  id: string;
  route_id: number;
  route_code: string;
  origin: string;
  destination: string;
  bus_number: string | null;
  category: Category;
  rating: number;
  description: string;
  latitude: number | null;
  longitude: number | null;
  status: Status;
  is_demo: number;
  created_at: string;
  updated_at: string;
}
export interface Stats {
  total: number;
  average: number;
  resolved: number;
  open: number;
  demoCount: number;
  byCategory: { name: string; count: number }[];
  byRoute: {
    id: number;
    code: string;
    origin: string;
    destination: string;
    color: string;
    count: number;
    average: number;
  }[];
  trend: { date: string; count: number }[];
}
export interface Filters {
  route: string;
  category: string;
  status: string;
  from: string;
  to: string;
  source: string;
  q: string;
}
export const EMPTY_FILTERS: Filters = {
  route: "",
  category: "",
  status: "",
  from: "",
  to: "",
  source: "all",
  q: "",
};
