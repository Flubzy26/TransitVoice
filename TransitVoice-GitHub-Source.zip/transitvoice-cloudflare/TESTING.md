# Verification record

Updated verification on 3 October 2026 (UTC) with Node 24.19 and Chromium 134.

## Results

- `npm run build`: passed TypeScript checking and generated the production frontend.
- `npm test`: 10 test groups passed, 0 failed (four original API groups, two journey groups, and four workspace/security/operator-tool groups).
- `node --import tsx scripts/browser-check.ts`: passed against the compiled frontend served by Express, using a temporary SQLite database.
- Local SQLite integrity check: `ok`; temporary development test reports removed.

## Browser workflow checked

1. Landing page and sample route explorer load.
2. Empty form produces validation messages.
3. Passenger selects a route, issue and rating, adds a description, and optionally attaches coordinates.
4. Successful submission returns a report reference.
5. Admin signs in, opens that report, changes it to Resolved and saves.
6. Search narrows the table to that report; status filtering produces the expected empty state.
7. Reset filters and pagination work.
8. Reload preserves the admin session; logout returns to the login view.
9. Public insights include the submission and exclude report-level private fields.
10. All five pages, including the journey planner, were checked at 390 × 844 with no page-level horizontal overflow.
11. Denied location permission leaves the form usable; the mobile menu navigates correctly.
12. No browser runtime errors were captured.

GPS permission and coordinates were simulated for automation. Real device location accuracy was not tested. API tests additionally cover unauthorized access, invalid inputs, hostile origins, request rate limiting, date validation, and SQLite persistence after reopening.

The browser suite creates its own local server and database, then closes and removes them. Screenshots in `docs/screenshots/` show the temporary test dataset. No production hosting or live transit integration was verified.

## Journey planner checks

The browser smoke suite checks the initial map markers, no automatic routing request, road preview and response-derived distance, route 115 matching, one-time simulated GPS and nearest landmark, clearing location, equal-endpoint validation, endpoint swapping, no-match state, routing failure fallback, mobile rendering and denied GPS permission.

Routing responses in that suite are mocked deliberately, and map tile failures are simulated. This verifies app behavior without relying on external service uptime. GPS never triggered an extra OSRM request during the test.

A separate real HTTPS request to OSRM for Pune Station → Hinjawadi returned `code: Ok`, a road distance of 25,613.3 metres and a driving estimate of 1,624.1 seconds at the time of checking. These values are not hard-coded in the app and are not bus ETAs.

The optional `node --import tsx scripts/map-live-check.ts` did **not** pass in this execution environment: Chromium could not load map tiles. A separate tile request reported an access-denied response from the provider. Consequently, live basemap rendering and live OSRM rendering together under production CSP were **not verified**. The explicit tile-unavailable UI was checked instead. No access restriction was bypassed. Users can run the optional check on their own connection, but provider availability is not guaranteed.

Planner coordinates are approximate landmarks and were not surveyed or individually geocoded. Browser screenshots demonstrate UI and fallback behavior, not authoritative geography or actual live transit service.

## Version 2 organisation workspace verification

`npm run test:workspace` passed against the compiled frontend, Chromium 134 and an isolated SQLite database. It verified:

- Business landing page and owner signup.
- Route creation and local QR PNG generation.
- Anonymous organisation report submission and private receipt.
- Owner invitation creation and agent acceptance in a second browser context.
- Report assignment, restricted agent controls, internal notes and resolution.
- Private passenger tracking with status history; internal notes remain absent.
- Status filtering, reset filters and CSV download.
- Workspace metrics derived from the submitted report.
- Password change, logout and login with the new password.
- Phone (390px) and tablet (768px) layouts across landing, workspace, routes, inbox, team, settings, passenger portal and tracking, without page-level horizontal overflow.
- No captured browser runtime errors on the owner/passenger page.

An invitation navigation issue found during testing was fixed. The original Pune browser suite also passed after its landing page moved to `/community`.

API tests verify cross-organisation access denial, foreign route/assignee rejection, assignment-scoped agent access, forbidden management/export actions, single-use invites, deactivation/session revocation, password hashing, password-change session revocation, expiry, input validation, origin checks, optimistic report versions, private tracking fields, route archiving and CSV formula escaping.

Operator-tool tests run the backup and local password-reset scripts against disposable databases. They verify SQLite integrity, preservation of reports and original demo data, stored replacement-password hash and revoked sessions. The application database is not used by tests.

QR image generation/download availability is checked; physical camera scanning and printer output are not verified. Paid billing, email delivery, real GPS feeds and production hosting are not implemented or tested. This testing is not a claim of a comprehensive security audit or readiness for a paid public launch.
