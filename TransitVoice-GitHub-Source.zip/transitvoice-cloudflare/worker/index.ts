import { DurableObject } from 'cloudflare:workers';
import { handleAsNodeRequest } from 'cloudflare:node';
import { createServer } from 'node:http';
import { createApp } from './app.js';
import { DatabaseSync } from './database.js';
import { initializeDatabase, seedDatabase } from './db.js';
interface Env {
  ASSETS: Fetcher;
  TRANSIT_DB: DurableObjectNamespace<TransitDatabase>;
  ADMIN_EMAIL?: string;
  ADMIN_PASSWORD?: string;
}
/** One named object retains the application's relational database across deployments. */
export class TransitDatabase extends DurableObject<Env> {
  private database: DatabaseSync;
  constructor(ctx: DurableObjectState, env: Env) {
    super(ctx, env);
    this.database = new DatabaseSync(ctx.storage);
    this.database.transaction(() => {
      initializeDatabase(this.database);
      seedDatabase(this.database);
      this.database.exec('CREATE TABLE IF NOT EXISTS cf_limits(key TEXT PRIMARY KEY,window INTEGER NOT NULL,count INTEGER NOT NULL,expires_at INTEGER NOT NULL); CREATE INDEX IF NOT EXISTS cf_limits_expiry ON cf_limits(expires_at);');
    });
  }
  async fetch(request: Request): Promise<Response> {
    if (!this.env.ADMIN_EMAIL || !this.env.ADMIN_PASSWORD || this.env.ADMIN_PASSWORD.length < 12 || this.env.ADMIN_PASSWORD.startsWith('REPLACE_')) {
      return Response.json({error:'Deployment setup is incomplete. Set ADMIN_EMAIL and ADMIN_PASSWORD with Wrangler secrets.'}, {status:503});
    }
    // Serialize complete requests, including async password hashing, for account/invite consistency.
    return this.ctx.blockConcurrencyWhile(async () => {
      const app = createApp(this.database, {
        adminEmail:this.env.ADMIN_EMAIL!, adminPassword:this.env.ADMIN_PASSWORD!,
        origin:new URL(request.url).origin, production:new URL(request.url).protocol==='https:',
      });
      const server = createServer(app);
      server.listen(0);
      try {
        const address = server.address();
        if (!address || typeof address === 'string') throw new Error('HTTP bridge failed');
        const response = await handleAsNodeRequest(address.port, request);
        // Consume before closing the virtual Node server, preserving Set-Cookie headers.
        return new Response(await response.arrayBuffer(), {status:response.status,headers:response.headers});
      } finally { server.close(); }
    });
  }
}
export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const path = new URL(request.url).pathname;
    if (path === '/api' || path.startsWith('/api/')) {
      const headers = new Headers(request.headers);
      // Cloudflare supplies CF-Connecting-IP at its edge. Ignore caller-supplied internal headers.
      headers.set('x-transitvoice-client-ip', request.headers.get('CF-Connecting-IP') || 'local');
      headers.delete('x-forwarded-for');
      return env.TRANSIT_DB.get(env.TRANSIT_DB.idFromName('transitvoice-v1')).fetch(new Request(request,{headers}));
    }
    return env.ASSETS.fetch(request);
  },
} satisfies ExportedHandler<Env>;
