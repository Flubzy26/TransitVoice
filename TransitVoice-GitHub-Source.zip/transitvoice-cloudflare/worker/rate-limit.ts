import type { RequestHandler } from 'express';
import { createHash } from 'node:crypto';
import type { DatabaseSync } from './database.js';
/** Persistent fixed windows shared across Worker restarts. No raw IPs are stored. */
export function rateLimitFor(db: DatabaseSync) {
  return (options: {windowMs: number; limit: number; message: unknown; [key: string]: unknown}): RequestHandler =>
    (req, res, next) => {
      const now = Date.now();
      const identity = String(req.headers['x-transitvoice-client-ip'] || 'local');
      const key = createHash('sha256').update(identity + ':' + req.baseUrl + ':' + req.path).digest('hex');
      const window = Math.floor(now / options.windowMs);
      const count = db.transaction(() => {
        db.prepare('DELETE FROM cf_limits WHERE expires_at<=?').run(now);
        db.prepare(`INSERT INTO cf_limits(key,window,count,expires_at) VALUES(?,?,1,?)
          ON CONFLICT(key) DO UPDATE SET count=CASE WHEN window=excluded.window THEN count+1 ELSE 1 END,
          window=excluded.window,expires_at=excluded.expires_at`).run(key,window,(window+1)*options.windowMs);
        return Number(db.prepare('SELECT count FROM cf_limits WHERE key=?').get(key)!.count);
      });
      if (count > options.limit) {
        res.set('Retry-After', String(Math.ceil(((window+1)*options.windowMs-now)/1000)));
        res.status(429).json(options.message); return;
      }
      next();
    };
}
