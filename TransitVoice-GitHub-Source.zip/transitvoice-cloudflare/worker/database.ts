/** Synchronous SQLite adapter backed by durable Cloudflare storage. */
export type SQLInputValue = string | number | bigint | null | ArrayBuffer | ArrayBufferView;
export type Row = Record<string, string | number | null>;
export class DatabaseSync {
  constructor(private storage: DurableObjectStorage) {}
  exec(sql: string) { this.storage.sql.exec(sql).toArray(); }
  transaction<T>(fn: () => T): T { return this.storage.transactionSync(fn); }
  prepare(sql: string) {
    const execute = (args: SQLInputValue[]) => this.storage.sql.exec<Row>(sql,
      ...args.map(v => typeof v === 'bigint' ? Number(v) : v));
    return {
      get: (...args: SQLInputValue[]) => execute(args).toArray()[0] as Row | undefined,
      all: (...args: SQLInputValue[]) => execute(args).toArray(),
      run: (...args: SQLInputValue[]) => {
        execute(args).toArray();
        const result = this.storage.sql.exec<{changes: number}>('SELECT changes() AS changes').one();
        return { changes: result.changes };
      },
    };
  }
}
