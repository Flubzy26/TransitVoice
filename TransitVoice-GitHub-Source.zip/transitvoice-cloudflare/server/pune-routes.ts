// Endpoint and selected-stop examples checked against published PMPML route listings.
// These are not live schedules or complete stop lists. Sources: docs/ROUTE-SOURCES.md.
export const PUNE_ROUTES = [
  {
    id: 101,
    code: "2",
    origin: "Swargate",
    destination: "Shivajinagar",
    color: "#c7460b",
    stops: ["Swargate", "Shanipar", "Shaniwarwada", "Shivajinagar"],
  },
  {
    id: 102,
    code: "4",
    origin: "Swargate",
    destination: "Shivajinagar",
    color: "#b9232e",
    stops: ["Swargate", "SP College", "Deccan Gymkhana", "Shivajinagar"],
  },
  {
    id: 103,
    code: "5",
    origin: "Swargate",
    destination: "Pune Station (Moledina)",
    color: "#986500",
    stops: [
      "Swargate",
      "Ramoshigate",
      "Sassoon Hospital",
      "Pune Station (Moledina)",
    ],
  },
  {
    id: 104,
    code: "24",
    origin: "Katraj",
    destination: "MH Board Samtanagar",
    color: "#d95016",
    stops: [
      "Katraj",
      "Swargate",
      "Pune Station (towards Yerwada)",
      "MH Board Samtanagar",
    ],
  },
  {
    id: 105,
    code: "43",
    origin: "Katraj",
    destination: "Bhakti Shakti Terminal",
    color: "#9e3022",
    stops: ["Katraj", "Warje Pul", "Chandani Chowk", "Bhakti Shakti Terminal"],
  },
  {
    id: 106,
    code: "115",
    origin: "Pune Station (Moledina)",
    destination: "Hinjawadi Maan Phase 3",
    color: "#b76b05",
    stops: [
      "Pune Station (Moledina)",
      "Pune Vidyapeeth",
      "Dange Chowk",
      "Hinjawadi Maan Phase 3",
    ],
  },
];
