import "dotenv/config";
import { openDatabase } from "./db.js";
import { createApp } from "./app.js";
const { ADMIN_EMAIL, ADMIN_PASSWORD } = process.env;
if (
  !ADMIN_EMAIL ||
  !ADMIN_PASSWORD ||
  ADMIN_PASSWORD.length < 12 ||
  ADMIN_PASSWORD.startsWith("REPLACE_")
) {
  console.error(
    "Configure .env using npm run setup before starting the server. Admin password must be at least 12 characters.",
  );
  process.exit(1);
}
const port = Number(process.env.PORT || 3001);
const db = openDatabase(
  process.env.DATABASE_PATH || "./data/transitvoice.sqlite",
);
const app = createApp(db, {
  adminEmail: ADMIN_EMAIL,
  adminPassword: ADMIN_PASSWORD,
  origin: process.env.APP_ORIGIN || "http://localhost:5173",
  production: process.env.NODE_ENV === "production",
});
const server = app.listen(port, "0.0.0.0", () =>
  console.log(`TransitVoice API listening on http://localhost:${port}`),
);
for (const signal of ["SIGINT", "SIGTERM"])
  process.on(signal, () =>
    server.close(() => {
      db.close();
      process.exit(0);
    }),
  );
