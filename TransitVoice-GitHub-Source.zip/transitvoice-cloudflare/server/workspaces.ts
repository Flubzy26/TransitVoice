import {
  Router,
  type Request,
  type Response,
  type NextFunction,
} from "express";
import type { DatabaseSync, SQLInputValue } from "node:sqlite";
import { createHash, randomBytes, scrypt, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";
import { z } from "zod";
import rateLimit from "express-rate-limit";
import { CATEGORIES, STATUSES } from "../src/types.js";

const derive = promisify(scrypt);
const hash = (value: string) =>
  createHash("sha256").update(value).digest("hex");
const secret = () => randomBytes(24).toString("hex");
const now = () => new Date().toISOString();
const email = z
  .string()
  .trim()
  .email()
  .max(254)
  .transform((v) => v.toLowerCase());
const password = z.string().min(12).max(128);
const name = z.string().trim().min(2).max(100);
const priorities = ["High", "Normal", "Low"] as const;
type Actor = {
  id: string;
  org_id: string;
  name: string;
  email: string;
  role: "owner" | "manager" | "agent";
  org_name: string;
  slug: string;
  kind: string;
  plan_interest: string;
};
async function passwordHash(value: string) {
  const salt = randomBytes(16).toString("hex");
  const result = (await derive(value, salt, 64)) as Buffer;
  return `${salt}:${result.toString("hex")}`;
}
async function checkPassword(value: string, stored: string) {
  const [salt, expected] = stored.split(":");
  const actual = (await derive(value, salt, 64)) as Buffer;
  const bytes = Buffer.from(expected, "hex");
  return bytes.length === actual.length && timingSafeEqual(actual, bytes);
}
export function migrateWorkspaces(db: DatabaseSync) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS ops_orgs(id TEXT PRIMARY KEY,name TEXT NOT NULL,slug TEXT NOT NULL UNIQUE,kind TEXT NOT NULL,plan_interest TEXT NOT NULL DEFAULT 'Pilot',created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS ops_users(id TEXT PRIMARY KEY,org_id TEXT NOT NULL REFERENCES ops_orgs(id),name TEXT NOT NULL,email TEXT NOT NULL UNIQUE,password_hash TEXT NOT NULL,role TEXT NOT NULL CHECK(role IN ('owner','manager','agent')),active INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS ops_sessions(token_hash TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES ops_users(id),expires_at INTEGER NOT NULL);
    CREATE INDEX IF NOT EXISTS ops_session_expiry ON ops_sessions(expires_at);
    CREATE TABLE IF NOT EXISTS ops_routes(id TEXT PRIMARY KEY,org_id TEXT NOT NULL REFERENCES ops_orgs(id),code TEXT NOT NULL,origin TEXT NOT NULL,destination TEXT NOT NULL,active INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL,UNIQUE(org_id,code));
    CREATE TABLE IF NOT EXISTS ops_reports(id TEXT PRIMARY KEY,org_id TEXT NOT NULL REFERENCES ops_orgs(id),route_id TEXT NOT NULL REFERENCES ops_routes(id),category TEXT NOT NULL,rating INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5),description TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'Received',priority TEXT NOT NULL DEFAULT 'Normal',assignee_id TEXT REFERENCES ops_users(id),tracking_hash TEXT NOT NULL UNIQUE,due_at TEXT NOT NULL,created_at TEXT NOT NULL,updated_at TEXT NOT NULL,version INTEGER NOT NULL DEFAULT 1);
    CREATE INDEX IF NOT EXISTS ops_report_org_created ON ops_reports(org_id,created_at);
    CREATE TABLE IF NOT EXISTS ops_events(id INTEGER PRIMARY KEY AUTOINCREMENT,report_id TEXT NOT NULL REFERENCES ops_reports(id),org_id TEXT NOT NULL REFERENCES ops_orgs(id),actor_name TEXT NOT NULL,action TEXT NOT NULL,note TEXT NOT NULL DEFAULT '',public_status TEXT,created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS ops_invites(id TEXT PRIMARY KEY,org_id TEXT NOT NULL REFERENCES ops_orgs(id),token_hash TEXT NOT NULL UNIQUE,role TEXT NOT NULL CHECK(role IN ('manager','agent')),expires_at INTEGER NOT NULL,used_at TEXT,created_at TEXT NOT NULL);
  `);
}
export function workspaceRouter(
  db: DatabaseSync,
  config: { production: boolean; rateLimit?: number },
) {
  const router = Router();
  const cookie = {
    httpOnly: true,
    sameSite: "strict" as const,
    secure: config.production,
    path: "/api/ops",
  };
  const token = (req: Request) =>
    (req.headers.cookie || "")
      .split(";")
      .map((v) => v.trim())
      .find((v) => v.startsWith("tv_ops="))
      ?.slice(7) || "";
  const limiter = (limit: number) =>
    rateLimit({
      windowMs: 15 * 60 * 1000,
      limit: config.rateLimit ?? limit,
      standardHeaders: "draft-8",
      legacyHeaders: false,
      message: { error: "Too many attempts. Please try again in 15 minutes." },
    });
  const actor = (res: Response) => res.locals.actor as Actor;
  function authenticated(req: Request, res: Response, next: NextFunction) {
    const user = db
      .prepare(
        `SELECT u.id,u.org_id,u.name,u.email,u.role,o.name AS org_name,o.slug,o.kind,o.plan_interest FROM ops_sessions s JOIN ops_users u ON u.id=s.user_id JOIN ops_orgs o ON o.id=u.org_id WHERE s.token_hash=? AND s.expires_at>? AND u.active=1`,
      )
      .get(hash(token(req)), Date.now());
    if (!user) {
      res.status(401).json({ error: "Sign in to your workspace to continue." });
      return;
    }
    res.locals.actor = user;
    next();
  }
  const manage = (_req: Request, res: Response, next: NextFunction) => {
    if (actor(res).role === "agent") {
      res.status(403).json({ error: "Only an owner or manager can do this." });
      return;
    }
    next();
  };
  const owner = (_req: Request, res: Response, next: NextFunction) => {
    if (actor(res).role !== "owner") {
      res.status(403).json({ error: "Only the workspace owner can do this." });
      return;
    }
    next();
  };
  function session(req: Request, res: Response, userId: string) {
    db.prepare(
      "DELETE FROM ops_sessions WHERE expires_at<=? OR token_hash=?",
    ).run(Date.now(), hash(token(req)));
    const value = secret();
    db.prepare("INSERT INTO ops_sessions VALUES(?,?,?)").run(
      hash(value),
      userId,
      Date.now() + 8 * 3600000,
    );
    res.cookie("tv_ops", value, { ...cookie, maxAge: 8 * 3600000 });
  }
  router.post("/register", limiter(5), async (req, res) => {
    const data = z
      .object({
        organization: name,
        kind: z.enum(["College", "Company", "Operator"]),
        name,
        email,
        password,
      })
      .strict()
      .parse(req.body);
    const stored = await passwordHash(data.password);
    if (db.prepare("SELECT id FROM ops_users WHERE email=?").get(data.email)) {
      res
        .status(409)
        .json({
          error: "An account already uses this email. Sign in instead.",
        });
      return;
    }
    const orgId = secret(),
      userId = secret();
    const slug =
      (data.organization
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/^-|-$/g, "")
        .slice(0, 40) || "workspace") +
      "-" +
      randomBytes(3).toString("hex");
    db.exec("BEGIN");
    try {
      db.prepare(
        "INSERT INTO ops_orgs(id,name,slug,kind,created_at) VALUES(?,?,?,?,?)",
      ).run(orgId, data.organization, slug, data.kind, now());
      db.prepare(
        "INSERT INTO ops_users(id,org_id,name,email,password_hash,role,created_at) VALUES(?,?,?,?,?,'owner',?)",
      ).run(userId, orgId, data.name, data.email, stored, now());
      db.exec("COMMIT");
    } catch (error) {
      db.exec("ROLLBACK");
      throw error;
    }
    session(req, res, userId);
    res.status(201).json({ ok: true });
  });
  router.post("/login", limiter(8), async (req, res) => {
    const data = z
      .object({ email, password: z.string().min(1).max(128) })
      .strict()
      .parse(req.body);
    const user = db
      .prepare("SELECT * FROM ops_users WHERE email=? AND active=1")
      .get(data.email);
    const valid = await checkPassword(
      data.password,
      user
        ? String(user.password_hash)
        : `${"0".repeat(32)}:${"0".repeat(128)}`,
    );
    if (!user || !valid) {
      res.status(401).json({ error: "Email or password is incorrect." });
      return;
    }
    session(req, res, String(user.id));
    res.json({ ok: true });
  });
  router.post("/join", limiter(5), async (req, res) => {
    const data = z
      .object({ token: z.string().length(48), name, email, password })
      .strict()
      .parse(req.body);
    const stored = await passwordHash(data.password);
    const invite = db
      .prepare(
        "SELECT * FROM ops_invites WHERE token_hash=? AND expires_at>? AND used_at IS NULL",
      )
      .get(hash(data.token), Date.now());
    if (!invite) {
      res
        .status(400)
        .json({
          error:
            "This invitation has expired, was revoked, or has already been used.",
        });
      return;
    }
    if (db.prepare("SELECT id FROM ops_users WHERE email=?").get(data.email)) {
      res
        .status(409)
        .json({
          error:
            "This email already has an account. Use a different email for this workspace.",
        });
      return;
    }
    if (
      Number(
        db
          .prepare(
            "SELECT COUNT(*) AS n FROM ops_users WHERE org_id=? AND active=1",
          )
          .get(invite.org_id)!.n,
      ) >= 10
    ) {
      res
        .status(409)
        .json({ error: "The pilot limit is 10 active team members." });
      return;
    }
    const id = secret();
    db.exec("BEGIN");
    try {
      db.prepare(
        "INSERT INTO ops_users(id,org_id,name,email,password_hash,role,created_at) VALUES(?,?,?,?,?,?,?)",
      ).run(
        id,
        invite.org_id,
        data.name,
        data.email,
        stored,
        invite.role,
        now(),
      );
      db.prepare("UPDATE ops_invites SET used_at=? WHERE id=?").run(
        now(),
        invite.id,
      );
      db.exec("COMMIT");
    } catch (error) {
      db.exec("ROLLBACK");
      throw error;
    }
    session(req, res, id);
    res.status(201).json({ ok: true });
  });
  router.get("/public/:slug", limiter(120), (req, res) => {
    const org = db
      .prepare("SELECT id,name,slug,kind FROM ops_orgs WHERE slug=?")
      .get(String(req.params.slug));
    if (!org) {
      res.status(404).json({ error: "Workspace not found." });
      return;
    }
    const routes = db
      .prepare(
        "SELECT id,code,origin,destination FROM ops_routes WHERE org_id=? AND active=1 ORDER BY code",
      )
      .all(org.id);
    res.json({
      organization: { name: org.name, slug: org.slug, kind: org.kind },
      routes,
    });
  });
  router.post("/public/:slug/reports", limiter(12), (req, res) => {
    const data = z
      .object({
        routeId: z.string().length(48),
        category: z.enum(CATEGORIES),
        rating: z.number().int().min(1).max(5),
        description: z.string().trim().max(2000).default(""),
      })
      .strict()
      .parse(req.body);
    const route = db
      .prepare(
        "SELECT r.id,r.org_id FROM ops_routes r JOIN ops_orgs o ON o.id=r.org_id WHERE o.slug=? AND r.id=? AND r.active=1",
      )
      .get(String(req.params.slug), data.routeId);
    if (!route) {
      res
        .status(400)
        .json({ error: "Choose an active route in this workspace." });
      return;
    }
    const id = "TVP-" + randomBytes(6).toString("hex").toUpperCase(),
      tracking = secret(),
      date = now();
    const priority = data.category === "Safety" ? "High" : "Normal";
    const due = new Date(
      Date.now() + (priority === "High" ? 24 : 72) * 3600000,
    ).toISOString();
    db.exec("BEGIN");
    try {
      db.prepare(
        "INSERT INTO ops_reports(id,org_id,route_id,category,rating,description,priority,tracking_hash,due_at,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
      ).run(
        id,
        route.org_id,
        route.id,
        data.category,
        data.rating,
        data.description,
        priority,
        hash(tracking),
        due,
        date,
        date,
      );
      db.prepare(
        "INSERT INTO ops_events(report_id,org_id,actor_name,action,public_status,created_at) VALUES(?,?,'Passenger','Report received','Received',?)",
      ).run(id, route.org_id, date);
      db.exec("COMMIT");
    } catch (error) {
      db.exec("ROLLBACK");
      throw error;
    }
    res.status(201).json({ id, trackingToken: tracking, status: "Received" });
  });
  router.post("/track", limiter(60), (req, res) => {
    const { token: tracking } = z
      .object({ token: z.string().length(48) })
      .strict()
      .parse(req.body);
    const report = db
      .prepare(
        "SELECT f.id,f.status,f.created_at,f.updated_at,r.code,r.origin,r.destination,o.name AS organization FROM ops_reports f JOIN ops_routes r ON r.id=f.route_id JOIN ops_orgs o ON o.id=f.org_id WHERE f.tracking_hash=?",
      )
      .get(hash(tracking));
    if (!report) {
      res
        .status(404)
        .json({
          error:
            "Tracking code not found. Check the private code on your receipt.",
        });
      return;
    }
    const timeline = db
      .prepare(
        "SELECT public_status AS status,created_at FROM ops_events WHERE report_id=? AND public_status IS NOT NULL ORDER BY id",
      )
      .all(report.id);
    res.json({ ...report, timeline });
  });
  router.use(authenticated);
  router.get("/me", (_req, res) => res.json(actor(res)));
  router.post("/logout", (req, res) => {
    db.prepare("DELETE FROM ops_sessions WHERE token_hash=?").run(
      hash(token(req)),
    );
    res.clearCookie("tv_ops", cookie).json({ ok: true });
  });
  router.post("/password", limiter(8), async (req, res) => {
    const data = z
      .object({ current: z.string().min(1).max(128), next: password })
      .strict()
      .parse(req.body);
    const user = db
      .prepare("SELECT password_hash FROM ops_users WHERE id=?")
      .get(actor(res).id)!;
    if (!(await checkPassword(data.current, String(user.password_hash)))) {
      res.status(400).json({ error: "Current password is incorrect." });
      return;
    }
    const stored = await passwordHash(data.next);
    db.prepare("UPDATE ops_users SET password_hash=? WHERE id=?").run(
      stored,
      actor(res).id,
    );
    db.prepare("DELETE FROM ops_sessions WHERE user_id=?").run(actor(res).id);
    session(req, res, actor(res).id);
    res.json({ ok: true });
  });
  router.get("/routes", (_req, res) =>
    res.json(
      db
        .prepare(
          "SELECT r.*,COUNT(f.id) AS reports FROM ops_routes r LEFT JOIN ops_reports f ON f.route_id=r.id WHERE r.org_id=? GROUP BY r.id ORDER BY r.created_at DESC",
        )
        .all(actor(res).org_id),
    ),
  );
  const routeSchema = z
    .object({
      code: z.string().trim().min(1).max(20),
      origin: name,
      destination: name,
    })
    .strict();
  router.post("/routes", manage, (req, res) => {
    const data = routeSchema.parse(req.body),
      org = actor(res).org_id;
    if (
      Number(
        db
          .prepare(
            "SELECT COUNT(*) AS n FROM ops_routes WHERE org_id=? AND active=1",
          )
          .get(org)!.n,
      ) >= 10
    ) {
      res
        .status(409)
        .json({
          error:
            "The pilot limit is 10 active routes. Archive an unused route first.",
        });
      return;
    }
    if (
      db
        .prepare("SELECT id FROM ops_routes WHERE org_id=? AND code=?")
        .get(org, data.code)
    ) {
      res.status(409).json({ error: "A route with this code already exists." });
      return;
    }
    const id = secret();
    db.prepare(
      "INSERT INTO ops_routes(id,org_id,code,origin,destination,created_at) VALUES(?,?,?,?,?,?)",
    ).run(id, org, data.code, data.origin, data.destination, now());
    res.status(201).json({ id });
  });
  router.patch("/routes/:id", manage, (req, res) => {
    const data = z.object({ active: z.boolean() }).strict().parse(req.body),
      org = actor(res).org_id;
    const route = db
      .prepare("SELECT * FROM ops_routes WHERE id=? AND org_id=?")
      .get(String(req.params.id), org);
    if (!route) {
      res.status(404).json({ error: "Route not found." });
      return;
    }
    if (
      data.active &&
      !route.active &&
      Number(
        db
          .prepare(
            "SELECT COUNT(*) AS n FROM ops_routes WHERE org_id=? AND active=1",
          )
          .get(org)!.n,
      ) >= 10
    ) {
      res.status(409).json({ error: "The pilot limit is 10 active routes." });
      return;
    }
    db.prepare("UPDATE ops_routes SET active=? WHERE id=? AND org_id=?").run(
      data.active ? 1 : 0,
      route.id,
      org,
    );
    res.json({ ok: true });
  });
  router.get("/team", (_req, res) =>
    res.json(
      db
        .prepare(
          "SELECT id,name,email,role,active FROM ops_users WHERE org_id=? ORDER BY created_at",
        )
        .all(actor(res).org_id),
    ),
  );
  router.post("/invites", owner, limiter(20), (req, res) => {
    const { role } = z
      .object({ role: z.enum(["manager", "agent"]) })
      .strict()
      .parse(req.body);
    const value = secret(),
      id = secret(),
      expires = Date.now() + 7 * 86400000;
    db.prepare(
      "INSERT INTO ops_invites(id,org_id,token_hash,role,expires_at,created_at) VALUES(?,?,?,?,?,?)",
    ).run(id, actor(res).org_id, hash(value), role, expires, now());
    res
      .status(201)
      .json({ token: value, expiresAt: new Date(expires).toISOString() });
  });
  router.get("/invites", owner, (_req, res) =>
    res.json(
      db
        .prepare(
          "SELECT id,role,expires_at,used_at FROM ops_invites WHERE org_id=? AND used_at IS NULL AND expires_at>? ORDER BY created_at DESC",
        )
        .all(actor(res).org_id, Date.now()),
    ),
  );
  router.delete("/invites/:id", owner, (req, res) => {
    db.prepare("DELETE FROM ops_invites WHERE id=? AND org_id=?").run(
      String(req.params.id),
      actor(res).org_id,
    );
    res.json({ ok: true });
  });
  router.patch("/team/:id", owner, (req, res) => {
    const data = z.object({ active: z.boolean() }).strict().parse(req.body),
      org = actor(res).org_id;
    const member = db
      .prepare("SELECT id,role FROM ops_users WHERE id=? AND org_id=?")
      .get(String(req.params.id), org);
    if (!member) {
      res.status(404).json({ error: "Team member not found." });
      return;
    }
    if (member.role === "owner") {
      res.status(400).json({ error: "The owner cannot be deactivated." });
      return;
    }
    if (
      data.active &&
      Number(
        db
          .prepare(
            "SELECT COUNT(*) AS n FROM ops_users WHERE org_id=? AND active=1",
          )
          .get(org)!.n,
      ) >= 10
    ) {
      res.status(409).json({ error: "The pilot limit is 10 active members." });
      return;
    }
    db.exec("BEGIN");
    try {
      db.prepare("UPDATE ops_users SET active=? WHERE id=? AND org_id=?").run(
        data.active ? 1 : 0,
        member.id,
        org,
      );
      if (!data.active) {
        db.prepare("DELETE FROM ops_sessions WHERE user_id=?").run(member.id);
      }
      db.exec("COMMIT");
    } catch (error) {
      db.exec("ROLLBACK");
      throw error;
    }
    res.json({ ok: true });
  });
  router.patch("/organization", owner, (req, res) => {
    const data = z
      .object({ name, planInterest: z.enum(["Pilot", "Team", "Enterprise"]) })
      .strict()
      .parse(req.body);
    db.prepare("UPDATE ops_orgs SET name=?,plan_interest=? WHERE id=?").run(
      data.name,
      data.planInterest,
      actor(res).org_id,
    );
    res.json({ ok: true });
  });
  const isoDate = z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/)
    .refine(
      (v) =>
        !isNaN(Date.parse(v)) && new Date(v).toISOString().slice(0, 10) === v,
    );
  const filters = z
    .object({
      q: z.string().max(100).default(""),
      status: z.enum(STATUSES).optional(),
      priority: z.enum(priorities).optional(),
      category: z.enum(CATEGORIES).optional(),
      route: z.string().max(48).optional(),
      from: isoDate.optional(),
      to: isoDate.optional(),
      page: z.coerce.number().int().min(1).max(100000).default(1),
      overdue: z.enum(["1"]).optional(),
    })
    .refine((v) => !v.from || !v.to || v.from <= v.to, {
      message: "Start date must precede end date.",
    });
  function scope(req: Request, res: Response) {
    const data = filters.parse(
        Object.fromEntries(
          Object.entries(req.query).filter(([, v]) => v !== ""),
        ),
      ),
      user = actor(res);
    const clauses = ["f.org_id=?"],
      args: SQLInputValue[] = [user.org_id];
    if (user.role === "agent") {
      clauses.push("f.assignee_id=?");
      args.push(user.id);
    }
    for (const [key, col] of [
      ["status", "status"],
      ["priority", "priority"],
      ["category", "category"],
      ["route", "route_id"],
    ] as const)
      if (data[key]) {
        clauses.push(`f.${col}=?`);
        args.push(data[key]);
      }
    if (data.q) {
      clauses.push(
        "(f.id LIKE ? ESCAPE '\\' OR f.description LIKE ? ESCAPE '\\')",
      );
      const q = "%" + data.q.replace(/[\\%_]/g, "\\$&") + "%";
      args.push(q, q);
    }
    if (data.from) {
      clauses.push("f.created_at>=?");
      args.push(data.from + "T00:00:00.000Z");
    }
    if (data.to) {
      clauses.push("f.created_at<=?");
      args.push(data.to + "T23:59:59.999Z");
    }
    if (data.overdue) {
      clauses.push("f.status!='Resolved' AND f.due_at<?");
      args.push(now());
    }
    return { where: clauses.join(" AND "), args, page: data.page };
  }
  const reportSelect =
    "SELECT f.id,f.route_id,f.category,f.rating,f.description,f.status,f.priority,f.assignee_id,f.due_at,f.created_at,f.updated_at,f.version,r.code,r.origin,r.destination,u.name AS assignee FROM ops_reports f JOIN ops_routes r ON r.id=f.route_id LEFT JOIN ops_users u ON u.id=f.assignee_id";
  router.get("/reports", (req, res) => {
    const { where, args, page } = scope(req, res),
      limit = 20;
    const total = Number(
      db
        .prepare(`SELECT COUNT(*) AS n FROM ops_reports f WHERE ${where}`)
        .get(...args)!.n,
    );
    res.json({
      reports: db
        .prepare(
          `${reportSelect} WHERE ${where} ORDER BY f.created_at DESC,f.id LIMIT ? OFFSET ?`,
        )
        .all(...args, limit, (page - 1) * limit),
      total,
      page,
      pageSize: limit,
    });
  });
  router.get("/stats", (req, res) => {
    const { where, args } = scope(req, res);
    const totals = db
      .prepare(
        `SELECT COUNT(*) AS total,COALESCE(ROUND(AVG(f.rating),1),0) AS average,COALESCE(SUM(f.status='Resolved'),0) AS resolved,COALESCE(SUM(f.status!='Resolved'),0) AS open,COALESCE(SUM(f.status!='Resolved' AND f.due_at<?),0) AS overdue,COALESCE(SUM(f.assignee_id IS NULL AND f.status!='Resolved'),0) AS unassigned FROM ops_reports f WHERE ${where}`,
      )
      .get(now(), ...args);
    const categories = db
      .prepare(
        `SELECT category AS name,COUNT(*) AS count FROM ops_reports f WHERE ${where} GROUP BY category ORDER BY count DESC`,
      )
      .all(...args);
    const routeStats = db
      .prepare(
        `SELECT r.code,COUNT(*) AS count,ROUND(AVG(f.rating),1) AS average FROM ops_reports f JOIN ops_routes r ON r.id=f.route_id WHERE ${where} GROUP BY r.id ORDER BY count DESC LIMIT 10`,
      )
      .all(...args);
    const trendRows = db
      .prepare(
        `SELECT substr(f.created_at,1,10) AS date,COUNT(*) AS count FROM ops_reports f WHERE ${where} GROUP BY substr(f.created_at,1,10)`,
      )
      .all(...args);
    const trend = Array.from({ length: 14 }, (_, i) => {
      const date = new Date(Date.now() - (13 - i) * 86400000)
        .toISOString()
        .slice(0, 10);
      return {
        date,
        count: Number(trendRows.find((r) => r.date === date)?.count || 0),
      };
    });
    res.json({ ...totals, categories, routes: routeStats, trend });
  });
  router.get("/export", manage, (req, res) => {
    const { where, args } = scope(req, res);
    const rows = db
      .prepare(
        `${reportSelect} WHERE ${where} ORDER BY f.created_at DESC LIMIT 10000`,
      )
      .all(...args);
    const fields = [
      "id",
      "code",
      "category",
      "rating",
      "status",
      "priority",
      "assignee",
      "description",
      "due_at",
      "created_at",
    ];
    const escape = (v: unknown) => {
      let s = String(v ?? "");
      if (/^[=+@\-\t\r\n]/.test(s)) s = "'" + s;
      return '"' + s.replace(/"/g, '""') + '"';
    };
    res
      .set({
        "Content-Type": "text/csv; charset=utf-8",
        "Content-Disposition": "attachment; filename=transitvoice-reports.csv",
        "X-Export-Limit": "10000",
      })
      .send(
        "\uFEFF" +
          [
            fields.join(","),
            ...rows.map((r) => fields.map((f) => escape(r[f])).join(",")),
          ].join("\r\n"),
      );
  });
  function findReport(req: Request, res: Response) {
    const user = actor(res);
    return db
      .prepare(
        `${reportSelect} WHERE f.id=? AND f.org_id=? ${user.role === "agent" ? "AND f.assignee_id=?" : ""}`,
      )
      .get(
        String(req.params.id),
        user.org_id,
        ...(user.role === "agent" ? [user.id] : []),
      );
  }
  router.get("/reports/:id", (req, res) => {
    const report = findReport(req, res);
    if (!report) {
      res
        .status(404)
        .json({ error: "Report not found or not assigned to you." });
      return;
    }
    res.json({
      ...report,
      events: db
        .prepare(
          "SELECT id,actor_name,action,note,created_at FROM ops_events WHERE report_id=? AND org_id=? ORDER BY id",
        )
        .all(report.id, actor(res).org_id),
    });
  });
  router.patch("/reports/:id", (req, res) => {
    const data = z
      .object({
        status: z.enum(STATUSES),
        priority: z.enum(priorities),
        assigneeId: z.string().length(48).nullable(),
        note: z.string().trim().max(2000).default(""),
        version: z.number().int().positive(),
      })
      .strict()
      .parse(req.body);
    const report = findReport(req, res),
      user = actor(res);
    if (!report) {
      res
        .status(404)
        .json({ error: "Report not found or not assigned to you." });
      return;
    }
    if (Number(report.version) !== data.version) {
      res
        .status(409)
        .json({
          error:
            "Someone updated this report. Close and reopen it before saving.",
        });
      return;
    }
    if (
      user.role === "agent" &&
      (data.assigneeId !== report.assignee_id ||
        data.priority !== report.priority)
    ) {
      res
        .status(403)
        .json({ error: "Agents can update status and notes only." });
      return;
    }
    if (
      data.assigneeId &&
      !db
        .prepare(
          "SELECT id FROM ops_users WHERE id=? AND org_id=? AND active=1",
        )
        .get(data.assigneeId, user.org_id)
    ) {
      res
        .status(400)
        .json({ error: "Choose an active member of this workspace." });
      return;
    }
    const date = now(),
      changed = data.status !== report.status;
    const due =
      data.priority === report.priority
        ? report.due_at
        : new Date(
            Date.parse(String(report.created_at)) +
              { High: 24, Normal: 72, Low: 168 }[data.priority] * 3600000,
          ).toISOString();
    db.exec("BEGIN");
    try {
      db.prepare(
        "UPDATE ops_reports SET status=?,priority=?,assignee_id=?,due_at=?,updated_at=?,version=version+1 WHERE id=? AND org_id=?",
      ).run(
        data.status,
        data.priority,
        data.assigneeId,
        due,
        date,
        report.id,
        user.org_id,
      );
      const actions = [
        changed ? `Status changed to ${data.status}` : "",
        data.priority !== report.priority
          ? `Priority changed to ${data.priority}`
          : "",
        data.assigneeId !== report.assignee_id ? "Assignment updated" : "",
        data.note ? "Internal note added" : "",
      ].filter(Boolean);
      db.prepare(
        "INSERT INTO ops_events(report_id,org_id,actor_name,action,note,public_status,created_at) VALUES(?,?,?,?,?,?,?)",
      ).run(
        report.id,
        user.org_id,
        user.name,
        actions.join(" · ") || "Report reviewed",
        data.note,
        changed ? data.status : null,
        date,
      );
      db.exec("COMMIT");
    } catch (error) {
      db.exec("ROLLBACK");
      throw error;
    }
    res.json({ ok: true });
  });
  return router;
}
