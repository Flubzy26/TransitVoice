import express, {
  type Request,
  type Response,
  type NextFunction,
} from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import { z } from "zod";
import {
  randomBytes,
  createHash,
  scryptSync,
  timingSafeEqual,
} from "node:crypto";
import type { DatabaseSync, SQLInputValue } from "node:sqlite";
import { resolve } from "node:path";
import { existsSync } from "node:fs";
import { CATEGORIES, STATUSES } from "../src/types.js";
import { workspaceRouter } from "./workspaces.js";
export interface Config {
  adminEmail: string;
  adminPassword: string;
  origin: string;
  production: boolean;
  rateLimit?: number;
}
const feedbackSchema = z
  .object({
    routeId: z.number().int().positive(),
    busNumber: z.string().trim().max(40).optional().default(""),
    category: z.enum(CATEGORIES),
    rating: z.number().int().min(1).max(5),
    description: z.string().trim().max(2000).optional().default(""),
    location: z
      .object({
        latitude: z.number().min(-90).max(90),
        longitude: z.number().min(-180).max(180),
      })
      .optional(),
  })
  .strict();
const date = z
  .string()
  .regex(/^\d{4}-\d{2}-\d{2}$/)
  .refine(
    (v) =>
      !isNaN(Date.parse(v)) && new Date(v).toISOString().slice(0, 10) === v,
  );
const filterSchema = z
  .object({
    route: z.coerce.number().int().positive().optional(),
    category: z.enum(CATEGORIES).optional(),
    status: z.enum(STATUSES).optional(),
    from: date.optional(),
    to: date.optional(),
    source: z.enum(["all", "demo", "community"]).default("all"),
    q: z.string().max(100).optional(),
    page: z.coerce.number().int().min(1).max(100000).default(1),
  })
  .refine((v) => !v.from || !v.to || v.from <= v.to, {
    message: "Start date must be before the end date.",
  });
function parseFilters(req: Request, publicOnly = false) {
  const query = Object.fromEntries(
    Object.entries(req.query).filter(([, v]) => v !== ""),
  );
  if (publicOnly) {
    delete query.q;
    delete query.status;
    delete query.category;
  }
  const f = filterSchema.parse(query);
  const where: string[] = [];
  const args: SQLInputValue[] = [];
  if (f.route) {
    where.push("f.route_id = ?");
    args.push(f.route);
  }
  if (f.category) {
    where.push("f.category = ?");
    args.push(f.category);
  }
  if (f.status) {
    where.push("f.status = ?");
    args.push(f.status);
  }
  if (f.from) {
    where.push("f.created_at >= ?");
    args.push(f.from + "T00:00:00.000Z");
  }
  if (f.to) {
    where.push("f.created_at <= ?");
    args.push(f.to + "T23:59:59.999Z");
  }
  if (f.source !== "all") {
    where.push("f.is_demo = ?");
    args.push(f.source === "demo" ? 1 : 0);
  }
  if (f.q) {
    where.push(
      "(f.id LIKE ? ESCAPE '\\' OR f.description LIKE ? ESCAPE '\\' OR f.bus_number LIKE ? ESCAPE '\\')",
    );
    const q = "%" + f.q.replace(/[\\%_]/g, "\\$&") + "%";
    args.push(q, q, q);
  }
  return {
    f,
    where: where.length ? " WHERE " + where.join(" AND ") : "",
    args,
  };
}
function tokenHash(token: string) {
  return createHash("sha256").update(token).digest("hex");
}
export function createApp(db: DatabaseSync, config: Config) {
  const app = express();
  app.disable("x-powered-by");
  const salt = randomBytes(16);
  const expectedPassword = scryptSync(config.adminPassword, salt, 64);
  app.use(
    helmet({
      referrerPolicy: { policy: "strict-origin-when-cross-origin" },
      contentSecurityPolicy: config.production
        ? {
            directives: {
              "img-src": ["'self'", "data:", "https://tile.openstreetmap.org"],
              "style-src": ["'self'", "'unsafe-inline'"],
              "script-src": ["'self'"],
              "connect-src": ["'self'", "https://router.project-osrm.org"],
              "upgrade-insecure-requests": null,
            },
          }
        : false,
    }),
  );
  app.use(express.json({ limit: "16kb" }));
  app.use("/api", (_req, res, next) => {
    res.set("Cache-Control", "no-store");
    next();
  });
  app.use("/api", (req, res, next) => {
    if (
      !["GET", "HEAD", "OPTIONS"].includes(req.method) &&
      req.headers.origin &&
      req.headers.origin !== config.origin
    ) {
      res
        .status(403)
        .json({ error: "This request came from an untrusted origin." });
      return;
    }
    if (["POST", "PATCH"].includes(req.method) && !req.is("application/json")) {
      res.status(415).json({ error: "Send application/json content." });
      return;
    }
    next();
  });
  const cookieOptions = {
    httpOnly: true,
    sameSite: "strict" as const,
    secure: config.production,
    path: "/api/admin",
  };
  function sessionToken(req: Request) {
    return (
      (req.headers.cookie ?? "")
        .split(";")
        .map((s) => s.trim())
        .find((s) => s.startsWith("tv_session="))
        ?.slice("tv_session=".length) ?? ""
    );
  }
  function requireAdmin(req: Request, res: Response, next: NextFunction) {
    const token = sessionToken(req);
    const session =
      token &&
      db
        .prepare(
          "SELECT expires_at FROM sessions WHERE token_hash = ? AND expires_at > ?",
        )
        .get(tokenHash(token), Date.now());
    if (!session) {
      res
        .status(401)
        .json({ error: "Please sign in to access the admin dashboard." });
      return;
    }
    next();
  }
  app.get("/api/health", (_req, res) => res.json({ status: "ok" }));
  app.get("/api/routes", (req, res) =>
    res.json(
      db
        .prepare(
          req.query.archived === "1"
            ? "SELECT * FROM routes ORDER BY is_active DESC, CAST(code AS INTEGER)"
            : "SELECT * FROM routes WHERE is_active=1 ORDER BY CAST(code AS INTEGER)",
        )
        .all()
        .map((r) => ({ ...r, stops: JSON.parse(String(r.stops)) })),
    ),
  );
  app.post(
    "/api/feedback",
    rateLimit({
      windowMs: 15 * 60 * 1000,
      limit: config.rateLimit ?? 12,
      standardHeaders: "draft-8",
      legacyHeaders: false,
      message: {
        error:
          "You have submitted several reports. Please wait 15 minutes before submitting another.",
      },
    }),
    (req, res) => {
      const data = feedbackSchema.parse(req.body);
      if (
        !db
          .prepare("SELECT id FROM routes WHERE id = ? AND is_active=1")
          .get(data.routeId)
      ) {
        res.status(400).json({ error: "Please select a valid route." });
        return;
      }
      const id = "TV-" + randomBytes(6).toString("hex").toUpperCase();
      const now = new Date().toISOString();
      db.prepare(
        "INSERT INTO feedback(id,route_id,bus_number,category,rating,description,latitude,longitude,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
      ).run(
        id,
        data.routeId,
        data.busNumber || null,
        data.category,
        data.rating,
        data.description,
        data.location?.latitude ?? null,
        data.location?.longitude ?? null,
        now,
        now,
      );
      res.status(201).json({ id, status: "Received", createdAt: now });
    },
  );
  function stats(req: Request, res: Response, publicOnly: boolean) {
    const { where, args, f } = parseFilters(req, publicOnly);
    const row = db
      .prepare(
        `SELECT COUNT(*) AS total, COALESCE(ROUND(AVG(rating),1),0) AS average, COALESCE(SUM(status = 'Resolved'),0) AS resolved, COALESCE(SUM(status != 'Resolved'),0) AS open, COALESCE(SUM(is_demo),0) AS demoCount FROM feedback f${where}`,
      )
      .get(...args)!;
    const categories = db
      .prepare(
        `SELECT category AS name,COUNT(*) AS count FROM feedback f${where} GROUP BY category`,
      )
      .all(...args);
    const byCategory = CATEGORIES.map((name) => ({
      name,
      count: Number(categories.find((r) => r.name === name)?.count ?? 0),
    }));
    const byRoute = db
      .prepare(
        `SELECT r.id,r.code,r.origin,r.destination,r.color,COUNT(*) AS count,ROUND(AVG(f.rating),1) AS average FROM feedback f JOIN routes r ON r.id=f.route_id${where} GROUP BY r.id ORDER BY count DESC`,
      )
      .all(...args);
    // Chart is always the 14 days ending on the chosen end date, or today (UTC).
    const end = f.to
      ? new Date(f.to + "T00:00:00Z")
      : new Date(new Date().toISOString().slice(0, 10) + "T00:00:00Z");
    const trendRows = db
      .prepare(
        `SELECT substr(created_at,1,10) AS date,COUNT(*) AS count FROM feedback f${where} GROUP BY substr(created_at,1,10)`,
      )
      .all(...args);
    const trend = Array.from({ length: 14 }, (_, i) => {
      const d = new Date(end.getTime() - (13 - i) * 86400000)
        .toISOString()
        .slice(0, 10);
      return {
        date: d,
        count: Number(trendRows.find((t) => t.date === d)?.count ?? 0),
      };
    });
    res.json({ ...row, byCategory, byRoute, trend });
  }
  app.get("/api/insights", (req, res) => stats(req, res, true));
  app.post(
    "/api/admin/login",
    rateLimit({
      windowMs: 15 * 60 * 1000,
      limit: 8,
      skipSuccessfulRequests: true,
      standardHeaders: "draft-8",
      legacyHeaders: false,
      message: {
        error: "Too many sign-in attempts. Please try again in 15 minutes.",
      },
    }),
    (req, res) => {
      const data = z
        .object({
          email: z.string().email().max(254),
          password: z.string().min(1).max(256),
        })
        .parse(req.body);
      const candidate = scryptSync(data.password, salt, 64);
      if (
        !timingSafeEqual(expectedPassword, candidate) ||
        data.email.toLowerCase() !== config.adminEmail.toLowerCase()
      ) {
        res.status(401).json({ error: "The email or password is incorrect." });
        return;
      }
      db.prepare("DELETE FROM sessions WHERE expires_at <= ?").run(Date.now());
      const existing = sessionToken(req);
      if (existing)
        db.prepare("DELETE FROM sessions WHERE token_hash=?").run(
          tokenHash(existing),
        );
      const token = randomBytes(32).toString("hex");
      db.prepare("INSERT INTO sessions(token_hash,expires_at) VALUES(?,?)").run(
        tokenHash(token),
        Date.now() + 8 * 3600000,
      );
      res
        .cookie("tv_session", token, { ...cookieOptions, maxAge: 8 * 3600000 })
        .json({ email: config.adminEmail });
    },
  );
  app.get("/api/admin/session", requireAdmin, (_req, res) =>
    res.json({ email: config.adminEmail }),
  );
  app.post("/api/admin/logout", requireAdmin, (req, res) => {
    db.prepare("DELETE FROM sessions WHERE token_hash = ?").run(
      tokenHash(sessionToken(req)),
    );
    res.clearCookie("tv_session", cookieOptions).json({ ok: true });
  });
  app.get("/api/admin/stats", requireAdmin, (req, res) =>
    stats(req, res, false),
  );
  app.get("/api/admin/reports", requireAdmin, (req, res) => {
    const { where, args, f } = parseFilters(req);
    const pageSize = 10;
    const total = Number(
      db
        .prepare(`SELECT COUNT(*) AS total FROM feedback f${where}`)
        .get(...args)!.total,
    );
    const reports = db
      .prepare(
        `SELECT f.*,r.code AS route_code,r.origin,r.destination FROM feedback f JOIN routes r ON r.id=f.route_id${where} ORDER BY f.created_at DESC,f.id LIMIT ? OFFSET ?`,
      )
      .all(...args, pageSize, (f.page - 1) * pageSize);
    res.json({ reports, total, page: f.page, pageSize });
  });
  app.patch("/api/admin/reports/:id", requireAdmin, (req, res) => {
    const { status } = z
      .object({ status: z.enum(STATUSES) })
      .strict()
      .parse(req.body);
    const result = db
      .prepare("UPDATE feedback SET status=?,updated_at=? WHERE id=?")
      .run(status, new Date().toISOString(), String(req.params.id));
    if (!result.changes) {
      res.status(404).json({ error: "This report could not be found." });
      return;
    }
    res.json({ ok: true, status });
  });
  app.use("/api/ops", workspaceRouter(db, config));
  app.use("/api", (_req, res) =>
    res.status(404).json({ error: "API endpoint not found." }),
  );
  const dist = resolve("dist");
  if (existsSync(dist)) {
    app.use(express.static(dist));
    app.get("/{*path}", (_req, res) =>
      res.sendFile(resolve(dist, "index.html")),
    );
  }
  app.use(
    (error: unknown, _req: Request, res: Response, _next: NextFunction) => {
      if (error instanceof z.ZodError) {
        res.status(400).json({
          error: "Please check the supplied fields.",
          details: error.flatten(),
        });
        return;
      }
      if (error instanceof SyntaxError && "body" in error) {
        res.status(400).json({ error: "Invalid JSON request." });
        return;
      }
      if (
        error &&
        typeof error === "object" &&
        "status" in error &&
        error.status === 413
      ) {
        res.status(413).json({ error: "The submitted report is too large." });
        return;
      }
      console.error(
        "Request failed:",
        error instanceof Error ? error.message : "Unknown error",
      );
      res
        .status(500)
        .json({ error: "Something went wrong. Please try again." });
    },
  );
  return app;
}
