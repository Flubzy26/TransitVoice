import { DatabaseSync } from "node:sqlite";
import { mkdirSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { PUNE_ROUTES } from "./pune-routes.js";
import { CATEGORIES } from "../src/types.js";
import { migrateWorkspaces } from "./workspaces.js";
export function openDatabase(filename: string) {
  if (filename !== ":memory:")
    mkdirSync(dirname(resolve(filename)), { recursive: true });
  const db = new DatabaseSync(filename);
  db.exec(`PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;
    CREATE TABLE IF NOT EXISTS routes (id INTEGER PRIMARY KEY, code TEXT UNIQUE NOT NULL, origin TEXT NOT NULL, destination TEXT NOT NULL, color TEXT NOT NULL, stops TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS feedback (
      id TEXT PRIMARY KEY, route_id INTEGER NOT NULL REFERENCES routes(id), bus_number TEXT,
      category TEXT NOT NULL CHECK(category IN ('Delay','Overcrowding','Accessibility','Cleanliness','Safety','Staff conduct','Other')),
      rating INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5), description TEXT NOT NULL DEFAULT '',
      latitude REAL CHECK(latitude BETWEEN -90 AND 90), longitude REAL CHECK(longitude BETWEEN -180 AND 180),
      status TEXT NOT NULL DEFAULT 'Received' CHECK(status IN ('Received','Under Review','Resolved')),
      is_demo INTEGER NOT NULL DEFAULT 0 CHECK(is_demo IN (0,1)), created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
      CHECK((latitude IS NULL) = (longitude IS NULL))
    );
    CREATE INDEX IF NOT EXISTS idx_feedback_route_created ON feedback(route_id, created_at);
    CREATE INDEX IF NOT EXISTS idx_feedback_created ON feedback(created_at);
    CREATE INDEX IF NOT EXISTS idx_feedback_status ON feedback(status);
    CREATE TABLE IF NOT EXISTS sessions (token_hash TEXT PRIMARY KEY, expires_at INTEGER NOT NULL);
    CREATE INDEX IF NOT EXISTS idx_sessions_expiry ON sessions(expires_at);
    CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL);
  `);
  migratePuneRoutes(db);
  migrateWorkspaces(db);
  return db;
}
export function seedDatabase(db: DatabaseSync) {
  if (db.prepare("SELECT value FROM metadata WHERE key = 'demo_seed_v1'").get())
    return false;
  const descriptions: Record<string, string[]> = {
    Delay: [
      "The evening service arrived around 20 minutes after the posted time.",
      "There was a long gap between buses during the morning commute.",
    ],
    Overcrowding: [
      "Very little standing space during the evening journey.",
      "An additional bus during college hours would help.",
    ],
    Accessibility: [
      "The step into the bus was difficult to use with a mobility aid.",
      "Please keep the priority seating area accessible.",
    ],
    Cleanliness: [
      "The seats and floor could use more regular cleaning.",
      "The stop needs a covered bin and routine cleaning.",
    ],
    Safety: [
      "The driver braked sharply several times during the trip.",
      "Better lighting is needed at the evening boarding stop.",
    ],
    "Staff conduct": [
      "The conductor helped an older passenger find a seat.",
      "Clearer announcements would make stops easier to identify.",
    ],
    Other: [
      "A route sign at the stop would help new passengers.",
      "Thank you for the comfortable journey today.",
    ],
  };
  db.exec("BEGIN");
  try {
    const insert = db.prepare(
      "INSERT INTO feedback(id,route_id,bus_number,category,rating,description,status,is_demo,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
    );
    for (let i = 0; i < 84; i++) {
      const category = CATEGORIES[(i * 3 + Math.floor(i / 7)) % 7];
      const date = new Date(
        Date.now() - (i % 14) * 86400000 - (i % 9) * 3600000,
      ).toISOString();
      const status =
        i % 5 < 2 ? "Resolved" : i % 5 === 2 ? "Under Review" : "Received";
      insert.run(
        `DEMO-${String(i + 1).padStart(4, "0")}`,
        PUNE_ROUTES[(i * 5 + Math.floor(i / 5)) % PUNE_ROUTES.length].id,
        `TV-${1000 + (i % 18)}`,
        category,
        1 + ((i * 7 + Math.floor(i / 5)) % 5),
        descriptions[category][i % 2],
        status,
        1,
        date,
        date,
      );
    }
    db.prepare("INSERT INTO metadata(key,value) VALUES ('demo_seed_v1',?)").run(
      new Date().toISOString(),
    );
    db.exec("COMMIT");
    return true;
  } catch (error) {
    db.exec("ROLLBACK");
    throw error;
  }
}

// Add Pune examples without relabeling any passenger's historical submission.
export function migratePuneRoutes(db: DatabaseSync) {
  const columns = db.prepare("PRAGMA table_info(routes)").all();
  if (!columns.some((c) => c.name === "is_active"))
    db.exec(
      "ALTER TABLE routes ADD COLUMN is_active INTEGER NOT NULL DEFAULT 1",
    );
  if (db.prepare("SELECT value FROM metadata WHERE key='pune_routes_v2'").get())
    return;
  db.exec("BEGIN");
  try {
    const insert = db.prepare(
      "INSERT INTO routes(id,code,origin,destination,color,stops,is_active) VALUES(?,?,?,?,?,?,1)",
    );
    for (const route of PUNE_ROUTES)
      insert.run(
        route.id,
        route.code,
        route.origin,
        route.destination,
        route.color,
        JSON.stringify(route.stops),
      );
    const oldCodes = ["101", "204", "308", "412", "507", "620"];
    oldCodes.forEach((code, index) => {
      const old = db
        .prepare("SELECT id FROM routes WHERE id=? AND code=?")
        .get(index + 1, code);
      if (old) {
        // Only synthetic reports are moved. Real submissions retain their original route.
        db.prepare(
          "UPDATE feedback SET route_id=? WHERE route_id=? AND is_demo=1",
        ).run(PUNE_ROUTES[index].id, index + 1);
        db.prepare("UPDATE routes SET is_active=0 WHERE id=?").run(index + 1);
      }
    });
    db.prepare(
      "INSERT INTO metadata(key,value) VALUES('pune_routes_v2',?)",
    ).run(new Date().toISOString());
    db.exec("COMMIT");
  } catch (error) {
    db.exec("ROLLBACK");
    throw error;
  }
}
