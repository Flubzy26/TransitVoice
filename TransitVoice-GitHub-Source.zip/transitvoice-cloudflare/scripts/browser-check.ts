import { chromium, expect } from "@playwright/test";
import { mkdirSync, mkdtempSync, rmSync, existsSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { randomBytes } from "node:crypto";
import { once } from "node:events";
import type { AddressInfo } from "node:net";
import { createApp } from "../server/app.js";
import { openDatabase, seedDatabase } from "../server/db.js";
if (!existsSync("dist/index.html"))
  throw new Error("Run npm run build before the browser smoke test.");
const browser = await chromium.launch({
  headless: true,
  args: ["--no-sandbox"],
});
const temp = mkdtempSync(join(tmpdir(), "transitvoice-browser-"));
const db = openDatabase(join(temp, "test.sqlite"));
seedDatabase(db);
const adminEmail = "test-admin@transitvoice.local";
const adminPassword = randomBytes(18).toString("base64url");
const config = { adminEmail, adminPassword, origin: "", production: false };
const server = createApp(db, config).listen(0, "127.0.0.1");
await once(server, "listening");
const base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
config.origin = base;
const context = await browser.newContext({
  viewport: { width: 1440, height: 1000 },
  permissions: ["geolocation"],
  geolocation: { latitude: 18.5204, longitude: 73.8567 },
});
const page = await context.newPage();
page.setDefaultTimeout(10000);
const errors: string[] = [];
page.on("pageerror", (e) => errors.push(e.message));
mkdirSync("test-results", { recursive: true });
let reportId = "";
try {
  await page.goto(base + "/community");
  await expect(
    page.getByRole("heading", { name: /Your journey/ }),
  ).toBeVisible();
  await expect(
    page.getByRole("button", { name: "115", exact: true }),
  ).toBeVisible();
  await page.screenshot({
    path: "test-results/home-desktop.png",
    fullPage: true,
  });
  // Exercise external routing deterministically without relying on demo-service uptime.
  await page.route("https://tile.openstreetmap.org/**", (route) =>
    route.abort(),
  );
  let routingCalls = 0;
  await page.route("https://router.project-osrm.org/**", async (route) => {
    routingCalls++;
    expect(route.request().url()).toContain("73.8743,18.5285;73.6885,18.5846");
    await route.fulfill({
      json: {
        code: "Ok",
        routes: [
          {
            distance: 24500,
            duration: 2700,
            geometry: {
              type: "LineString",
              coordinates: [
                [73.8743, 18.5285],
                [73.8246, 18.5523],
                [73.6885, 18.5846],
              ],
            },
          },
        ],
      },
    });
  });
  await page.goto(base + "/journey");
  await expect(
    page.getByRole("region", { name: "Interactive Pune journey map" }),
  ).toBeVisible();
  expect(routingCalls).toBe(0);
  await page.getByRole("button", { name: "Preview road route" }).click();
  await expect(
    page.getByText("Road preview ready.", { exact: false }),
  ).toBeVisible();
  await expect(page.locator(".journey-metrics")).toContainText("24.5");
  await expect(page.locator(".journey-route-card")).toContainText("115");
  await page.getByRole("button", { name: "Use my location" }).click();
  await expect(
    page.getByText("Nearest example landmark:", { exact: false }),
  ).toBeVisible();
  expect(routingCalls).toBe(1);
  await page.getByRole("button", { name: "Clear location" }).click();
  await expect(
    page.getByText("Location cleared from this session."),
  ).toBeVisible();
  await page
    .getByLabel("Starting point", { exact: true })
    .selectOption("station");
  await page.getByLabel("Destination", { exact: true }).selectOption("station");
  await expect(
    page.getByRole("button", { name: "Preview road route" }),
  ).toBeDisabled();
  await page
    .getByLabel("Destination", { exact: true })
    .selectOption("hinjawadi");
  await page.unroute("https://router.project-osrm.org/**");
  await page.route("https://router.project-osrm.org/**", (route) =>
    route.abort(),
  );
  await page.getByRole("button", { name: "Preview road route" }).click();
  await expect(
    page.getByText("Road routing is unavailable.", { exact: false }),
  ).toBeVisible();
  await page
    .getByRole("button", { name: "Swap start and destination" })
    .click();
  await expect(
    page.getByText("No direct example in our dataset"),
  ).toBeVisible();
  await page.screenshot({
    path: "test-results/journey-desktop.png",
    fullPage: true,
  });
  await page.goto(base + "/community");
  await page
    .getByRole("link", { name: "Share your journey", exact: true })
    .click();
  await page
    .getByRole("button", { name: "Submit feedback", exact: true })
    .click();
  await expect(page.getByRole("alert")).toContainText("highlighted");
  await page.getByLabel(/Bus route/).selectOption("101");
  await page.locator(".category-option").filter({ hasText: "Delay" }).click();
  await page.locator(".rating-input label").nth(1).click();
  await page
    .getByLabel(/Your experience/)
    .fill("Browser smoke test: morning bus arrived late.");
  await page.getByRole("button", { name: "Use location", exact: true }).click();
  await expect(
    page.getByText("Location attached", { exact: true }),
  ).toBeVisible();
  await page.screenshot({
    path: "test-results/feedback-desktop.png",
    fullPage: true,
  });
  const saved = page.waitForResponse(
    (r) => r.url().endsWith("/api/feedback") && r.request().method() === "POST",
  );
  await page
    .getByRole("button", { name: "Submit feedback", exact: true })
    .click();
  reportId = (await (await saved).json()).id;
  await expect(
    page.getByRole("heading", { name: /Your voice is/ }),
  ).toBeVisible();
  await expect(page.getByText(reportId, { exact: true })).toBeVisible();
  await page.goto(base + "/admin");
  await page.getByLabel("Admin email").fill(adminEmail);
  await page.getByLabel("Password", { exact: true }).fill(adminPassword);
  await page.getByRole("button", { name: "Sign in to dashboard" }).click();
  await expect(
    page.getByRole("heading", { name: "The passenger perspective." }),
  ).toBeVisible();
  await page
    .getByRole("button", { name: "Review report " + reportId, exact: true })
    .click();
  await expect(page.getByRole("dialog")).toBeVisible();
  await page.getByLabel("Report status").selectOption("Resolved");
  await page.getByRole("button", { name: "Save status" }).click();
  await expect(page.getByRole("dialog")).not.toBeVisible();
  await expect(page.locator(".toast")).toContainText("Report status updated");
  await page.getByLabel("Search reports").fill(reportId);
  await expect(page.locator(".reports-table tbody tr")).toHaveCount(1);
  await expect(page.locator(".reports-table tbody tr")).toContainText(
    "Resolved",
  );
  await page.getByLabel("Status").selectOption("Received");
  await expect(page.getByText("No reports match your filters")).toBeVisible();
  await page.getByRole("button", { name: "Reset filters" }).click();
  await expect(page.locator(".reports-table tbody tr")).toHaveCount(10);
  await page.getByRole("button", { name: "Dismiss notification" }).click();
  await page.screenshot({
    path: "test-results/admin-desktop.png",
    fullPage: true,
  });
  await page.getByRole("button", { name: "Next page" }).click();
  await expect(page.getByText(/Page 2 of/)).toBeVisible();
  await page.reload();
  await expect(
    page.getByRole("heading", { name: "The passenger perspective." }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Sign out" }).click();
  await expect(
    page.getByRole("heading", { name: "Welcome back." }),
  ).toBeVisible();
  await page.goto(base + "/insights");
  await page.getByLabel("Data source").selectOption("community");
  await expect(
    page.locator(".stat-card").first().locator("strong"),
  ).not.toHaveText("0");
  await page.screenshot({
    path: "test-results/insights-desktop.png",
    fullPage: true,
  });
  await page.setViewportSize({ width: 390, height: 844 });
  for (const path of ["/", "/feedback", "/insights", "/admin", "/journey"]) {
    await page.goto(base + path);
    await page.waitForLoadState("networkidle");
    const overflow = await page.evaluate(
      () => document.documentElement.scrollWidth > window.innerWidth,
    );
    expect(overflow, "No page overflow on " + path).toBe(false);
    await page.screenshot({
      path:
        "test-results/" +
        (path === "/" ? "home" : path.slice(1)) +
        "-mobile.png",
      fullPage: true,
    });
  }
  await page.goto(base + "/feedback");
  await context.clearPermissions();
  await context.grantPermissions([]);
  await page.evaluate(
    "Object.defineProperty(navigator, 'geolocation', { configurable: true, value: { getCurrentPosition: function(success, error) { error({code: 1}); } } })",
  );
  await page.getByRole("button", { name: "Use location", exact: true }).click();
  await expect(page.getByRole("status")).toContainText("declined");
  await expect(
    page.getByRole("button", { name: "Submit feedback" }),
  ).toBeEnabled();
  await page.getByRole("button", { name: "Open navigation" }).click();
  await page
    .getByRole("navigation")
    .getByRole("link", { name: "Community insights" })
    .click();
  await expect(
    page.getByRole("heading", { name: "Community insights" }),
  ).toBeVisible();
  await page.goto(base + "/journey");
  await page.evaluate(
    "Object.defineProperty(navigator, 'geolocation', { configurable: true, value: { getCurrentPosition: function(success, error) { error({code: 1}); } } })",
  );
  await page.getByRole("button", { name: "Use my location" }).click();
  await expect(
    page.getByText("Location permission declined.", { exact: false }),
  ).toBeVisible();
  expect(errors, "No browser runtime errors").toEqual([]);
  console.log(
    "PASS: desktop/mobile, journey planner with mocked routing and tile-failure handling, GPS allow/deny, validation, anonymous submit, admin login, status update, filters, pagination, session reload, logout, and public insights.",
  );
} finally {
  await browser.close();
  await new Promise<void>((resolve) => server.close(() => resolve()));
  db.close();
  rmSync(temp, { recursive: true, force: true });
}
