// Optional live-provider check. This intentionally requires internet access.
import { chromium, expect } from "@playwright/test";
import { mkdtempSync, mkdirSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { once } from "node:events";
import type { AddressInfo } from "node:net";
import { randomBytes } from "node:crypto";
import { createApp } from "../server/app.js";
import { openDatabase, seedDatabase } from "../server/db.js";
const temp = mkdtempSync(join(tmpdir(), "transitvoice-live-map-"));
const db = openDatabase(join(temp, "test.sqlite"));
seedDatabase(db);
const config = {
  adminEmail: "test@example.local",
  adminPassword: randomBytes(24).toString("hex"),
  production: true,
  origin: "",
};
const server = createApp(db, config).listen(0, "127.0.0.1");
await once(server, "listening");
const base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
config.origin = base;
const browser = await chromium.launch({
  headless: true,
  args: ["--no-sandbox"],
});
try {
  const page = await browser.newPage({
    viewport: { width: 1440, height: 1100 },
  });
  const errors: string[] = [];
  page.on("pageerror", (error) => errors.push(error.message));
  await page.goto(base + "/journey");
  await expect(page.locator(".leaflet-tile-loaded").first()).toBeVisible({
    timeout: 20000,
  });
  await page.getByRole("button", { name: "Preview road route" }).click();
  await expect(
    page.getByText("Road preview ready.", { exact: false }),
  ).toBeVisible({ timeout: 16000 });
  await expect(page.locator(".route-road")).toBeVisible();
  mkdirSync("test-results", { recursive: true });
  await page.screenshot({
    path: "test-results/journey-live-desktop.png",
    fullPage: true,
  });
  await page.setViewportSize({ width: 390, height: 844 });
  await expect(page.locator(".leaflet-tile-loaded").first()).toBeVisible();
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth > window.innerWidth,
    ),
  ).toBe(false);
  await page.screenshot({
    path: "test-results/journey-live-mobile.png",
    fullPage: true,
  });
  expect(errors).toEqual([]);
  console.log(
    "PASS: actual OSM tiles and OSRM geometry in Chromium under production CSP; desktop/mobile without overflow or page errors.",
  );
} finally {
  await browser.close();
  await new Promise<void>((resolve) => server.close(() => resolve()));
  db.close();
  rmSync(temp, { recursive: true, force: true });
}
