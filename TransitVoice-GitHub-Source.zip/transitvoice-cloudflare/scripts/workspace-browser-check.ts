import { chromium, expect } from "@playwright/test";
import { mkdtempSync, mkdirSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { once } from "node:events";
import { randomBytes } from "node:crypto";
import type { AddressInfo } from "node:net";
import { createApp } from "../server/app.js";
import { openDatabase, seedDatabase } from "../server/db.js";
const dir = mkdtempSync(join(tmpdir(), "tv-workspace-browser-"));
const db = openDatabase(join(dir, "test.sqlite"));
seedDatabase(db);
const config = {
  adminEmail: "demo@example.test",
  adminPassword: randomBytes(20).toString("hex"),
  origin: "",
  production: false,
  rateLimit: 200,
};
const server = createApp(db, config).listen(0, "127.0.0.1");
await once(server, "listening");
const base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
config.origin = base;
const browser = await chromium.launch({
  headless: true,
  args: ["--no-sandbox"],
});
const context = await browser.newContext({
  viewport: { width: 1440, height: 1000 },
});
const page = await context.newPage();
await page.emulateMedia({ reducedMotion: "reduce" });
page.setDefaultTimeout(12000);
const errors: string[] = [];
page.on("pageerror", (e) => errors.push(e.message));
mkdirSync("test-results", { recursive: true });
try {
  await page.goto(base);
  await expect(
    page.getByRole("heading", { name: /Better commutes/ }),
  ).toBeVisible();
  await page.screenshot({
    path: "test-results/business-desktop.png",
    fullPage: true,
  });
  await page
    .getByRole("link", { name: "Create your workspace", exact: true })
    .click();
  await page.getByLabel("Your name", { exact: true }).fill("Lokesh Demo");
  await page.getByLabel("Organisation name").fill("Campus Transport Pilot");
  await page.getByLabel("Email", { exact: true }).fill("owner@campus.test");
  await page
    .getByLabel("Password", { exact: true })
    .fill("workspace-browser-password-123");
  await page
    .getByRole("button", { name: "Create workspace", exact: true })
    .click();
  await expect(
    page.getByRole("heading", { name: /A clearer picture/ }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Routes & QR", exact: true }).click();
  await page.getByRole("button", { name: "Add route", exact: true }).click();
  await page.getByLabel("Route code").fill("CAMPUS-01");
  await page.getByLabel("Starting point", { exact: true }).fill("Main campus");
  await page.getByLabel("Destination", { exact: true }).fill("City centre");
  await page.getByRole("button", { name: "Create route", exact: true }).click();
  await expect(
    page.getByRole("heading", { name: /Main campus/ }),
  ).toBeVisible();
  await page.getByRole("button", { name: "QR poster" }).click();
  await expect(
    page.getByAltText("Feedback QR code for route CAMPUS-01"),
  ).toBeVisible();
  expect(
    await page
      .getByAltText("Feedback QR code for route CAMPUS-01")
      .getAttribute("src"),
  ).toMatch(/^data:image\/png;base64,/);
  await page.screenshot({
    path: "test-results/qr-poster-desktop.png",
    fullPage: true,
  });
  await page.getByRole("button", { name: "Close dialog" }).click();
  await page
    .getByRole("link", { name: "Passenger portal", exact: true })
    .click();
  const portalUrl = page.url();
  await page
    .getByLabel("Bus or shuttle route")
    .selectOption({ label: "CAMPUS-01 · Main campus → City centre" });
  await page.getByLabel("Issue category").selectOption("Overcrowding");
  await page.getByRole("button", { name: "Rate 2 out of 5" }).click();
  await page
    .getByLabel("Your experience (optional)")
    .fill("The campus shuttle was crowded during the morning commute.");
  const submitted = page.waitForResponse(
    (r) => r.url().endsWith("/reports") && r.request().method() === "POST",
  );
  await page.getByRole("button", { name: "Submit anonymous report" }).click();
  const receipt = await (await submitted).json();
  await expect(
    page.getByRole("heading", { name: "Your voice is on the record." }),
  ).toBeVisible();
  await page.screenshot({
    path: "test-results/passenger-receipt.png",
    fullPage: true,
  });
  await page.goto(base + "/workspace?tab=team");
  await page.getByRole("button", { name: "Create invitation" }).click();
  const invitation = await page.locator(".ops-share-panel code").textContent();
  expect(invitation).toContain("/join#");
  const agentContext = await browser.newContext();
  const agent = await agentContext.newPage();
  await agent.goto(invitation!);
  await agent.getByLabel("Your name", { exact: true }).fill("Transport Agent");
  await agent.getByLabel("Email", { exact: true }).fill("agent@campus.test");
  await agent
    .getByLabel("Password", { exact: true })
    .fill("agent-browser-password-123");
  await agent
    .getByRole("button", { name: "Join workspace", exact: true })
    .click();
  await expect(
    agent.getByRole("heading", { name: /A clearer picture/ }),
  ).toBeVisible();
  await page.goto(base + "/workspace?tab=inbox");
  await page.getByRole("button", { name: "Open report " + receipt.id }).click();
  await page
    .getByLabel("Assigned to")
    .selectOption({ label: "Transport Agent" });
  await page.getByLabel("Report status").selectOption("Under Review");
  await page
    .getByLabel("Internal note")
    .fill("Check morning shuttle capacity.");
  await page.getByRole("button", { name: "Save report update" }).click();
  await expect(page.getByRole("dialog")).not.toBeVisible();
  await agent
    .getByRole("button", { name: "Report inbox", exact: true })
    .click();
  await agent
    .getByRole("button", { name: "Open report " + receipt.id })
    .click();
  await expect(agent.getByLabel("Assigned to")).toBeDisabled();
  await expect(
    agent.getByLabel("Report priority", { exact: true }),
  ).toBeDisabled();
  await agent.getByLabel("Report status").selectOption("Resolved");
  await agent
    .getByLabel("Internal note")
    .fill("Reviewed shuttle capacity with operations.");
  await agent.getByRole("button", { name: "Save report update" }).click();
  await expect(agent.getByRole("dialog")).not.toBeVisible();
  await page.goto(base + "/track#" + receipt.trackingToken);
  await page.getByRole("button", { name: "Check report status" }).click();
  await expect(page.locator(".track-result .badge")).toContainText("Resolved");
  await expect(page.locator(".track-result")).not.toContainText(
    "Reviewed shuttle capacity",
  );
  await page.screenshot({
    path: "test-results/tracking-desktop.png",
    fullPage: true,
  });
  await page.goto(base + "/workspace?tab=inbox");
  await page.getByLabel("Status", { exact: true }).selectOption("Received");
  await expect(
    page.getByText("No reports match", { exact: true }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Reset filters" }).click();
  await expect(page.locator(".ops-report-row")).toHaveCount(1);
  const download = page.waitForEvent("download");
  await page.getByRole("button", { name: "Export CSV" }).click();
  expect((await download).suggestedFilename()).toBe("transitvoice-reports.csv");
  await page.screenshot({
    path: "test-results/workspace-inbox-desktop.png",
    fullPage: true,
  });
  await page.getByRole("button", { name: "Overview", exact: true }).click();
  await expect(
    page.locator(".ops-kpis article").first().locator("strong"),
  ).toHaveText("1");
  await page.screenshot({
    path: "test-results/workspace-overview-desktop.png",
    fullPage: true,
  });
  for (const width of [390, 768]) {
    await page.setViewportSize({ width, height: 900 });
    for (const [name, path] of [
      ["business", "/"],
      ["workspace", "/workspace"],
      ["routes", "/workspace?tab=routes"],
      ["inbox", "/workspace?tab=inbox"],
      ["team", "/workspace?tab=team"],
      ["settings", "/workspace?tab=settings"],
      ["passenger", portalUrl.replace(base, "")],
      ["tracking", "/track"],
    ]) {
      await page.goto(base + path);
      await page.waitForLoadState("networkidle");
      expect(
        await page.evaluate(
          () => document.documentElement.scrollWidth > innerWidth,
        ),
        `No overflow ${name} at ${width}`,
      ).toBe(false);
      if (width === 390)
        await page.screenshot({
          path: `test-results/${name}-mobile.png`,
          fullPage: true,
        });
    }
  }
  await page.setViewportSize({ width: 1440, height: 1000 });
  await page.goto(base + "/workspace?tab=settings");
  await page
    .getByLabel("Current password")
    .fill("workspace-browser-password-123");
  await page.getByLabel("New password").fill("changed-browser-password-123");
  await page.getByRole("button", { name: "Update password" }).click();
  await expect(page.getByRole("status")).toContainText("Password changed");
  await page.getByRole("button", { name: "Sign out", exact: true }).click();
  await expect(
    page.getByRole("heading", { name: "Welcome to your workspace" }),
  ).toBeVisible();
  await page.getByLabel("Email", { exact: true }).fill("owner@campus.test");
  await page
    .getByLabel("Password", { exact: true })
    .fill("changed-browser-password-123");
  await page.getByRole("button", { name: "Sign in", exact: true }).click();
  await expect(
    page.getByRole("heading", { name: /A clearer picture/ }),
  ).toBeVisible();
  await agentContext.close();
  expect(errors).toEqual([]);
  console.log(
    "PASS: business landing, owner signup, route creation, QR image, anonymous report, private tracking, invitation acceptance, agent assignment and resolution, filters, CSV download, password change/login, and phone/tablet layouts.",
  );
} finally {
  await browser.close();
  await new Promise<void>((resolve) => server.close(() => resolve()));
  db.close();
  rmSync(dir, { recursive: true, force: true });
}
