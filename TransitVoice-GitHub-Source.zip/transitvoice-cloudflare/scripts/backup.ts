import "dotenv/config";
import { DatabaseSync, backup } from "node:sqlite";
import { existsSync, mkdirSync } from "node:fs";
import { resolve } from "node:path";
import { randomBytes } from "node:crypto";
const source = resolve(
  process.env.DATABASE_PATH || "./data/transitvoice.sqlite",
);
if (!existsSync(source))
  throw new Error("Database does not exist. Run npm run setup first.");
const backupDirectory = process.env.BACKUP_DIR || "backups";
mkdirSync(backupDirectory, { recursive: true });
const destination = resolve(
  backupDirectory,
  `transitvoice-${new Date().toISOString().replace(/[:.]/g, "-")}-${randomBytes(3).toString("hex")}.sqlite`,
);
const db = new DatabaseSync(source, { readOnly: true });
try {
  await backup(db, destination);
  console.log(`Backup created: ${destination}`);
  console.log(
    "This contains private reports and account hashes. Store securely; do not commit or share it.",
  );
} finally {
  db.close();
}
