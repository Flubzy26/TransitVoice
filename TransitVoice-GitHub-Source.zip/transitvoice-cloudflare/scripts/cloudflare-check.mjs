// Exercises the actual local Cloudflare runtime with isolated temporary storage.
import { spawn } from 'node:child_process';
import { mkdtemp, rm, readFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import assert from 'node:assert/strict';
import { randomBytes } from 'node:crypto';
const folder = await mkdtemp(join(tmpdir(),'transitvoice-cf-'));
const origin='http://127.0.0.1:8798';
const vars=Object.fromEntries((await readFile('.dev.vars','utf8')).trim().split('\n').map(l=>{const i=l.indexOf('=');return[l.slice(0,i),l.slice(i+1).replace(/^"|"$/g,'')]}));
let child; let output='';
async function start(){
 output='';
 child=spawn(process.execPath,['node_modules/wrangler/bin/wrangler.js','dev','--ip','127.0.0.1','--port','8798','--inspector-port','0','--persist-to',folder],{env:{...process.env,WRANGLER_SEND_METRICS:'false'},stdio:['ignore','pipe','pipe']});
 child.stdout.on('data',d=>{output+=d});child.stderr.on('data',d=>{output+=d});
 for(let i=0;i<120;i++){try{const r=await fetch(origin+'/api/health'); if(r.ok)return;}catch{} await new Promise(r=>setTimeout(r,500));}
 throw new Error('Worker did not start: '+output.slice(-6000));
}
async function stop(){if(!child)return;child.kill('SIGTERM');await new Promise(r=>{child.once('exit',r);setTimeout(r,2000)});}
let ip=1;
async function request(path,method='GET',body,cookie,extra={}){
 const r=await fetch(origin+path,{method,headers:{Origin:origin,'CF-Connecting-IP':`192.0.2.${ip}`, ...(body?{'Content-Type':'application/json'}:{}),...(cookie?{Cookie:cookie}:{}),...extra},body:body?JSON.stringify(body):undefined});
 const txt=await r.text();let data;try{data=JSON.parse(txt)}catch{data=txt}
 return {status:r.status,data,cookie:r.headers.get('set-cookie')?.split(';')[0],headers:r.headers};
}
function ok(r,status=200){assert.equal(r.status,status,JSON.stringify(r.data));return r.data;}
const pass=randomBytes(20).toString('hex');
try{
 await start();
 console.log('PASS Worker startup, durable SQLite initialization');
 assert.match(await (await fetch(origin+'/journey')).text(), /<div id="root"><\/div>/);
 const routes=ok(await request('/api/routes'));assert.equal(routes.length,6);
 const data={routeId:routes[0].id,category:'Delay',rating:2,description:'Cloudflare persistence test'};
 const report=ok(await request('/api/feedback','POST',data),201);
 assert.equal((await request('/api/admin/reports')).status,401);
 assert.equal((await request('/api/feedback','POST',{...data,rating:9})).status,400);
 assert.equal((await request('/api/feedback','POST',data,undefined,{Origin:'https://evil.example'})).status,403);
 const login=await request('/api/admin/login','POST',{email:vars.ADMIN_EMAIL,password:vars.ADMIN_PASSWORD});ok(login);const cookie=login.cookie;assert.ok(cookie);
 const list=ok(await request('/api/admin/reports?q='+report.id,'GET',undefined,cookie));assert.equal(list.total,1);
 ok(await request('/api/admin/reports/'+report.id,'PATCH',{status:'Resolved'},cookie));
 assert.equal(ok(await request('/api/admin/reports?status=Resolved&q='+report.id,'GET',undefined,cookie)).reports[0].status,'Resolved');
 const insights=ok(await request('/api/insights?source=community'));assert.equal(insights.total,1);assert.ok(!JSON.stringify(insights).includes(data.description));
 console.log('PASS Feedback, admin login, filtering, status updates, public privacy, validation and origin protection');
 const reg=await request('/api/ops/register','POST',{organization:'Cloudflare Test',kind:'College',name:'Test Owner',email:'owner@example.com',password:pass});ok(reg,201);
 const c=reg.cookie,me=ok(await request('/api/ops/me','GET',undefined,c));
 const route=ok(await request('/api/ops/routes','POST',{code:'C1',origin:'Pune Station',destination:'Swargate'},c),201);
 const receipt=ok(await request('/api/ops/public/'+me.slug+'/reports','POST',{routeId:route.id,category:'Safety',rating:2,description:'Private test report'}),201);
 const ticket=ok(await request('/api/ops/reports/'+receipt.id,'GET',undefined,c));assert.equal(ticket.priority,'High');
 const update={status:'Under Review',priority:'High',assigneeId:null,note:'Private staff note',version:ticket.version};
 ok(await request('/api/ops/reports/'+receipt.id,'PATCH',update,c));
 assert.equal((await request('/api/ops/reports/'+receipt.id,'PATCH',update,c)).status,409);
 const track=ok(await request('/api/ops/track','POST',{token:receipt.trackingToken}));assert.equal(track.status,'Under Review');assert.ok(!JSON.stringify(track).includes('Private'));
 ok(await request('/api/ops/stats','GET',undefined,c));assert.match(String(ok(await request('/api/ops/export','GET',undefined,c))), /TVP-/);
 const invite=ok(await request('/api/ops/invites','POST',{role:'agent'},c),201);
 const joined=await request('/api/ops/join','POST',{token:invite.token,name:'Test Agent',email:'agent@example.com',password:pass});ok(joined,201);
 assert.equal((await request('/api/ops/reports/'+receipt.id,'GET',undefined,joined.cookie)).status,404);
 assert.equal((await request('/api/ops/join','POST',{token:invite.token,name:'Another Agent',email:'another@example.com',password:pass})).status,400);
 const member=ok(await request('/api/ops/me','GET',undefined,joined.cookie));
 ok(await request('/api/ops/reports/'+receipt.id,'PATCH',{...update,assigneeId:member.id,version:ticket.version+1},c));
 const agentTicket=ok(await request('/api/ops/reports/'+receipt.id,'GET',undefined,joined.cookie));
 ok(await request('/api/ops/reports/'+receipt.id,'PATCH',{...update,status:'Resolved',assigneeId:member.id,version:agentTicket.version},joined.cookie));
 const reg2=await request('/api/ops/register','POST',{organization:'Other College',kind:'College',name:'Other Owner',email:'other@example.com',password:pass});ok(reg2,201);
 assert.equal((await request('/api/ops/reports/'+receipt.id,'GET',undefined,reg2.cookie)).status,404);
 console.log('PASS Workspace registration, roles, invitations, private tracking, CSV, version conflicts and tenant isolation');
 ip=2;
 for(let i=0;i<12;i++)ok(await request('/api/feedback','POST',data),201);
 assert.equal((await request('/api/feedback','POST',data)).status,429);
 await stop(); await start();
 assert.equal((await request('/api/feedback','POST',data)).status,429);
 ip=3;
 assert.equal(ok(await request('/api/ops/track','POST',{token:receipt.trackingToken})).status,'Resolved');
 assert.equal(ok(await request('/api/admin/reports?q='+report.id,'GET',undefined,cookie)).total,1);
 assert.equal(ok(await request('/api/ops/me','GET',undefined,c)).id,me.id);
 console.log('PASS Report/account/session persistence and rate limits across runtime restart');
 console.log('ALL CLOUDFLARE CHECKS PASSED');
}catch(e){console.error(output.slice(-5000));throw e}
finally{await stop();await rm(folder,{recursive:true,force:true});}
