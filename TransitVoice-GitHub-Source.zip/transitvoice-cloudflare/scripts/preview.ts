import "dotenv/config";
process.env.NODE_ENV = "development";
process.env.APP_ORIGIN = `http://localhost:${process.env.PORT || 3001}`;
await import("../server/index.js");
