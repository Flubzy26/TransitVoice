import "dotenv/config";
import { openDatabase, seedDatabase } from "../server/db.js";
const db = openDatabase(
  process.env.DATABASE_PATH || "./data/transitvoice.sqlite",
);
console.log(
  seedDatabase(db)
    ? "Seeded 6 Pune route examples and 84 demo reports."
    : "Seed already applied. Existing data preserved.",
);
db.close();
