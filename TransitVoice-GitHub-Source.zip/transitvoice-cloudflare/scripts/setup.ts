import { existsSync, writeFileSync } from "node:fs";
import { randomBytes } from "node:crypto";
import dotenv from "dotenv";
import { openDatabase, seedDatabase } from "../server/db.js";
if (!existsSync(".env")) {
  const password = randomBytes(18).toString("base64url");
  writeFileSync(
    ".env",
    `ADMIN_EMAIL=admin@transitvoice.local\nADMIN_PASSWORD=${password}\nPORT=3001\nDATABASE_PATH=./data/transitvoice.sqlite\nAPP_ORIGIN=http://localhost:5173\n`,
    { mode: 0o600 },
  );
  console.log(
    "Created .env. Your admin email is admin@transitvoice.local. Your randomly generated password is in .env (ADMIN_PASSWORD).",
  );
} else console.log("Preserved existing .env.");
dotenv.config();
const db = openDatabase(
  process.env.DATABASE_PATH || "./data/transitvoice.sqlite",
);
console.log(
  seedDatabase(db)
    ? "Created 6 Pune PMPML route examples and 84 clearly labeled demo reports."
    : "Database already initialized; existing reports preserved.",
);
db.close();
console.log("Ready. Start with npm run dev");
