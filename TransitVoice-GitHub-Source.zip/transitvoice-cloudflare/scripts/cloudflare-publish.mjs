import { spawn } from 'node:child_process';
import { createInterface } from 'node:readline/promises';
import { resolve } from 'node:path';
const wrangler=resolve('node_modules/wrangler/bin/wrangler.js');
async function run(args,input){
 await new Promise((resolve,reject)=>{
  const child=spawn(process.execPath,args,{stdio:[input===undefined?'inherit':'pipe','inherit','inherit'],env:{...process.env,WRANGLER_SEND_METRICS:'false'}});
  if(input!==undefined)child.stdin.end(input);
  child.once('error',reject);
  child.once('exit',code=>code===0?resolve():reject(new Error('Command stopped. Review the message above and retry.')));
 });
}
async function ask(question){const rl=createInterface({input:process.stdin,output:process.stdout});try{return (await rl.question(question)).trim()}finally{rl.close()}}
async function password(){
 if(!process.stdin.isTTY)throw new Error('Run this command in an interactive terminal.');
 process.stdout.write('Choose an admin password (12+ characters; input hidden): ');
 process.stdin.setRawMode(true);process.stdin.resume();process.stdin.setEncoding('utf8');
 return new Promise((resolve,reject)=>{
  let value='';
  const done=(error)=>{process.stdin.off('data',onData);process.stdin.setRawMode(false);process.stdin.pause();process.stdout.write('\n');error?reject(error):resolve(value)};
  const onData=chunk=>{for(const c of chunk){if(c==='\u0003'){done(new Error('Cancelled.'));return}if(c==='\r'||c==='\n'){done();return}if(c==='\u007f'||c==='\b'){value=value.slice(0,-1)}else if(c>=' ')value+=c;}};
  process.stdin.on('data',onData);
 });
}
try{
 console.log('\nTransitVoice Cloudflare publishing\nUse your Cloudflare Workers Free plan. This publishes a public website.\nYour local .env and SQLite database are not uploaded.\n');
 await run([process.env.npm_execpath,'run','build']);
 console.log('\nSign in to Cloudflare in the browser window and approve Wrangler.');
 await run([wrangler,'login']);
 const email=await ask('Email to use for the Pune demo admin login: ');
 if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))throw new Error('Enter a valid email address.');
 const secret=await password();
 if(secret.length<12||secret.startsWith('REPLACE_'))throw new Error('Use a password of at least 12 characters.');
 await run([wrangler,'deploy']);
 // Secrets travel through stdin, never command arguments or plaintext files.
 await run([wrangler,'secret','bulk'],JSON.stringify({ADMIN_EMAIL:email,ADMIN_PASSWORD:secret}));
 console.log('\nPublishing finished. Open the https://...workers.dev URL shown above.\nAdmin: add /admin to that URL and use the credentials you just entered.\nTest feedback submission and status updates before sharing the link.\n');
}catch(error){console.error('\n'+error.message);process.exitCode=1;}
