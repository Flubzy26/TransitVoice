import "dotenv/config";
import { DatabaseSync } from "node:sqlite";
import { existsSync } from "node:fs";
import { randomBytes, scryptSync } from "node:crypto";
const email = process.argv[2]?.trim().toLowerCase();
if (!email) {
  console.error("Usage: npm run account:reset -- owner@example.com");
  process.exit(1);
}
const file = process.env.DATABASE_PATH || "./data/transitvoice.sqlite";
if (!existsSync(file))
  throw new Error("Database does not exist. Check DATABASE_PATH.");
const db = new DatabaseSync(file);
try {
  const user = db
    .prepare("SELECT id FROM ops_users WHERE email=? AND active=1")
    .get(email);
  if (!user)
    throw new Error(
      "No active workspace account found for that email. This command does not change the legacy .env admin.",
    );
  const value = randomBytes(20).toString("base64url"),
    salt = randomBytes(16).toString("hex"),
    stored = salt + ":" + scryptSync(value, salt, 64).toString("hex");
  db.exec("BEGIN");
  try {
    db.prepare("UPDATE ops_users SET password_hash=? WHERE id=?").run(
      stored,
      user.id,
    );
    db.prepare("DELETE FROM ops_sessions WHERE user_id=?").run(user.id);
    db.exec("COMMIT");
  } catch (error) {
    db.exec("ROLLBACK");
    throw error;
  }
  console.log(
    "Workspace password reset. All existing sessions for this user were revoked.",
  );
  console.log("New password (keep private): " + value);
  console.log("Sign in and change this password in workspace Settings.");
} finally {
  db.close();
}
