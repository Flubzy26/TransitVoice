# Deploy TransitVoice on Cloudflare's Free plan

## Start here on Windows

1. Keep your existing working project folder as a backup. Extract this new ZIP into a separate folder.
2. Open the new `transitvoice-cloudflare` folder containing `package.json`.
3. Click File Explorer's address bar, type `cmd`, and press Enter.
4. Run `npm ci` and wait until it finishes.
5. Run `npm run cf:publish`.
6. A browser opens for Cloudflare login. Sign in to your own account and approve Wrangler's requested deployment access.
7. Return to CMD. Enter your chosen admin email and a password of at least 12 characters. The password is hidden while you type; press Enter when finished.
8. Select your account if Wrangler asks. Remain on the Workers Free plan; no paid upgrade or domain purchase is required for the included workers.dev URL.
9. Wait for both deployment and secret upload to finish. Open the `https://transitvoice.<your-subdomain>.workers.dev` URL printed in the terminal. If prompted to create your workers.dev subdomain, complete that account step and rerun the command.

The first deployment briefly returns a setup error for API requests until secret upload completes. If interrupted, rerun `npm run cf:publish` to complete setup. Do not distribute the URL before checking it.

The script keeps passwords out of command arguments and files. It does not upload your existing local `.env`, accounts, or SQLite database. Cloud hosting starts a new persistent database with six Pune sample routes and 84 clearly labelled demo reports. Create fresh workspace accounts online. Your original local reports remain in your old project folder.

## After deployment

- Visit `/feedback`, submit a test report without GPS, and keep its reference.
- Visit `/admin` and sign in using the email/password entered during publishing.
- Search for the reference and set its status to Under Review or Resolved.
- Reload `/insights` and confirm that Community submissions reflect your report.
- Visit `/workspace?mode=register` to create an organisation account; these accounts are separate from the demo admin.
- Test `/journey` on a phone. Location sharing remains optional. Map routing depends on external OpenStreetMap/OSRM availability, and is not live bus tracking.
- Close CMD after publishing: the hosted website continues running without your laptop.

## Architecture and free-tier limits

The frontend is React/Vite static assets. Cloudflare's Node HTTP bridge runs the Express API inside a single SQLite-backed Durable Object named `transitvoice-v1`. SQLite tables survive Worker restarts and redeployments. Transactions use Cloudflare's transactionSync API. Existing role checks, scrypt password hashing and private tracking remain in place. Request rate limits are now persisted in SQLite rather than process memory; login limits count all attempts, including successful logins. Search patterns are limited to 48 escaped UTF-8 bytes to match the storage engine's LIKE limit.

Workers and SQLite-backed Durable Objects have free quotas. Exceeding them can interrupt service on the Free plan. This is a college pilot architecture using one database object, not an unlimited hosting promise. Do not switch to a paid plan unless you intentionally want its billing. Do not change the Durable Object class, binding, migration or fixed object name casually: doing so can disconnect the app from its existing data.

## Commands

- `npm run cf:publish`: guided build, browser login, deploy and secret setup.
- `npm run cf:login`: Cloudflare browser login only.
- `npm run cf:check`: Worker TypeScript check, frontend build and deployment dry run.
- `npm run cf:deploy`: deploy updated code after initial secret configuration.
- `npx wrangler secret put ADMIN_PASSWORD`: replace the hosted demo admin password interactively.
- `npx wrangler secret put ADMIN_EMAIL`: replace the hosted demo admin email interactively.
- `npm run cf:dev`: preview Cloudflare locally after copying `.dev.vars.example` to `.dev.vars` and filling valid local credentials.
- `npm run cf:test`: API integration checks with a separate temporary Cloudflare database. Requires valid credentials in `.dev.vars`; does not use or modify your hosted database.
- `npm test`: original Node backend regression tests.

The original `npm run dev`, `npm run setup`, `.env` and local SQLite database still work independently. Editing `.env` does not change hosted credentials. The Node-only backup/reset scripts do not manage the Cloudflare database. Cloudflare storage provides platform recovery features; automated exports and cloud account recovery tooling are not included. Existing sessions expire after eight hours; changing the environment-configured admin password alone does not revoke already issued sessions.

## What was verified

The actual local Cloudflare runtime passed: schema/seed initialization, SPA deep links, feedback validation, unauthenticated access rejection, origin rejection, admin login, report filtering/status updates, aggregate privacy, workspace signup, team invitations and assignment permissions, single-use invitations, organisation isolation, optimistic version conflict rejection, private passenger tracking, CSV export, and persistence of reports/accounts/sessions/rate limits across a runtime restart. The frontend production build and Worker deployment dry run passed. Original Node tests are also run before packaging.

Live publishing requires your account login and has not been performed by the assistant. Live browser/device GPS, physical QR scanning and hosted load/CPU limits have not been tested. This release does not claim official PMPML integration, live vehicle tracking, billing or a completed community field survey.

## References

- https://developers.cloudflare.com/workers/tutorials/deploy-an-express-app/
- https://developers.cloudflare.com/workers/runtime-apis/nodejs/http/
- https://developers.cloudflare.com/durable-objects/api/sqlite-storage-api/
- https://developers.cloudflare.com/durable-objects/platform/pricing/
- https://developers.cloudflare.com/durable-objects/platform/limits/
- https://developers.cloudflare.com/workers/configuration/secrets/
