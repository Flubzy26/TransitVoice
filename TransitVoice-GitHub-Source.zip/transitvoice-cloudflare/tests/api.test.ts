import { test, type TestContext } from "node:test";
import assert from "node:assert/strict";
import { once } from "node:events";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { randomBytes } from "node:crypto";
import type { AddressInfo } from "node:net";
import { openDatabase, seedDatabase } from "../server/db.js";
import { createApp } from "../server/app.js";
const origin = "http://localhost:5173";
async function fixture(t: TestContext, limit = 50) {
  const dir = mkdtempSync(join(tmpdir(), "transitvoice-test-"));
  const db = openDatabase(join(dir, "test.sqlite"));
  seedDatabase(db);
  const password = randomBytes(18).toString("hex");
  const app = createApp(db, {
    adminEmail: "test@example.com",
    adminPassword: password,
    origin,
    production: false,
    rateLimit: limit,
  });
  const server = app.listen(0, "127.0.0.1");
  await once(server, "listening");
  const base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
  t.after(async () => {
    server.close();
    await once(server, "close");
    db.close();
    rmSync(dir, { recursive: true, force: true });
  });
  async function request(
    path: string,
    method = "GET",
    body?: unknown,
    cookie?: string,
    requestOrigin = origin,
  ) {
    return fetch(base + path, {
      method,
      headers: {
        ...(body ? { "Content-Type": "application/json" } : {}),
        Origin: requestOrigin,
        ...(cookie ? { Cookie: cookie } : {}),
      },
      body: body ? JSON.stringify(body) : undefined,
    });
  }
  async function login() {
    const res = await request("/api/admin/login", "POST", {
      email: "test@example.com",
      password,
    });
    assert.equal(res.status, 200);
    const raw = res.headers.get("set-cookie")!;
    assert.match(raw, /HttpOnly/i);
    assert.match(raw, /SameSite=Strict/i);
    return raw.split(";")[0];
  }
  return { db, request, login };
}
const feedback = {
  routeId: 101,
  category: "Delay",
  rating: 2,
  description: "Bus arrived late during the morning commute.",
  location: { latitude: 18.52, longitude: 73.85 },
};
test("submission → aggregate insights → protected review → resolution → logout", async (t) => {
  const { request, login } = await fixture(t);
  assert.equal((await request("/api/admin/reports")).status, 401);
  assert.equal(
    (
      await request("/api/admin/login", "POST", {
        email: "test@example.com",
        password: "incorrect-password",
      })
    ).status,
    401,
  );
  const submitted = await request("/api/feedback", "POST", feedback);
  assert.equal(submitted.status, 201);
  const receipt = await submitted.json();
  assert.match(receipt.id, /^TV-/);
  const publicRes = await request("/api/insights?source=community");
  const stats = await publicRes.json();
  assert.equal(stats.total, 1);
  assert.equal(stats.average, 2);
  assert.equal(stats.demoCount, 0);
  const publicText = JSON.stringify(stats);
  for (const field of ["latitude", "longitude", "description", "bus_number"])
    assert.ok(!publicText.includes(field));
  assert.ok(!publicText.includes(receipt.id));
  const cookie = await login();
  const reportRes = await request(
    "/api/admin/reports?source=community&route=101&category=Delay&q=" +
      receipt.id,
    "GET",
    undefined,
    cookie,
  );
  const reports = await reportRes.json();
  assert.equal(reports.total, 1);
  assert.equal(reports.reports[0].latitude, 18.52);
  assert.equal(
    (
      await request(
        "/api/admin/reports/" + receipt.id,
        "PATCH",
        { status: "Resolved" },
        cookie,
      )
    ).status,
    200,
  );
  const filtered = await (
    await request(
      "/api/admin/reports?status=Resolved&source=community",
      "GET",
      undefined,
      cookie,
    )
  ).json();
  assert.equal(filtered.reports[0].status, "Resolved");
  const after = await (await request("/api/insights?source=community")).json();
  assert.equal(after.resolved, 1);
  assert.equal(
    (await request("/api/admin/logout", "POST", {}, cookie)).status,
    200,
  );
  assert.equal(
    (await request("/api/admin/reports", "GET", undefined, cookie)).status,
    401,
  );
});
test("server validation, origin protection, date filters, and status authorization", async (t) => {
  const { request, login } = await fixture(t);
  for (const bad of [
    { ...feedback, rating: 0 },
    { ...feedback, routeId: 999 },
    { ...feedback, category: "Injected" },
    { ...feedback, location: { latitude: 91, longitude: 0 } },
    { ...feedback, description: "x".repeat(2001) },
  ])
    assert.equal((await request("/api/feedback", "POST", bad)).status, 400);
  assert.equal(
    (
      await request(
        "/api/feedback",
        "POST",
        feedback,
        undefined,
        "https://untrusted.example",
      )
    ).status,
    403,
  );
  assert.equal(
    (
      await request("/api/admin/reports/DEMO-0001", "PATCH", {
        status: "Resolved",
      })
    ).status,
    401,
  );
  const cookie = await login();
  assert.equal(
    (
      await request(
        "/api/admin/reports/DEMO-0001",
        "PATCH",
        { status: "Bogus" },
        cookie,
      )
    ).status,
    400,
  );
  assert.equal((await request("/api/insights?from=2026-02-31")).status, 400);
  assert.equal(
    (await request("/api/insights?from=2030-01-01&to=2020-01-01")).status,
    400,
  );
  assert.equal(
    (
      await (
        await request(
          "/api/admin/reports?q=%27%20OR%201%3D1--",
          "GET",
          undefined,
          cookie,
        )
      ).json()
    ).total,
    0,
  );
  const zero = await (await request("/api/insights?to=2000-01-01")).json();
  assert.equal(zero.total, 0);
  assert.equal(zero.trend.length, 14);
});
test("feedback requests are rate limited", async (t) => {
  const { request } = await fixture(t, 2);
  assert.equal((await request("/api/feedback", "POST", feedback)).status, 201);
  assert.equal((await request("/api/feedback", "POST", feedback)).status, 201);
  assert.equal((await request("/api/feedback", "POST", feedback)).status, 429);
});
test("SQLite persists records across reopening and seeds only once", () => {
  const dir = mkdtempSync(join(tmpdir(), "transitvoice-persist-"));
  const path = join(dir, "test.sqlite");
  let db = openDatabase(path);
  try {
    assert.equal(seedDatabase(db), true);
    assert.equal(db.prepare("SELECT count(*) n FROM feedback").get()!.n, 84);
    db.prepare(
      "UPDATE feedback SET status='Resolved' WHERE id='DEMO-0001'",
    ).run();
    db.close();
    db = openDatabase(path);
    assert.equal(seedDatabase(db), false);
    assert.equal(
      db.prepare("SELECT status FROM feedback WHERE id='DEMO-0001'").get()!
        .status,
      "Resolved",
    );
    assert.equal(db.prepare("SELECT count(*) n FROM feedback").get()!.n, 84);
  } finally {
    db.close();
    rmSync(dir, { recursive: true, force: true });
  }
});
