import test, { type TestContext } from "node:test";
import assert from "node:assert/strict";
import { once } from "node:events";
import type { AddressInfo } from "node:net";
import { randomBytes, scryptSync } from "node:crypto";
import { backup, DatabaseSync } from "node:sqlite";
import { mkdtempSync, readdirSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { openDatabase, seedDatabase } from "../server/db.js";
import { createApp } from "../server/app.js";
const origin = "http://localhost:5173";
const run = promisify(execFile);
test("backup and local account recovery preserve data and revoke sessions", async (t) => {
  const { db, register, addRoute, report, credentials } = await fixture(t);
  const { c, me } = await register();
  const route = await addRoute(c);
  await report(me.slug, route);
  const dir = mkdtempSync(join(tmpdir(), "tv-operator-tools-"));
  t.after(() => rmSync(dir, { recursive: true, force: true }));
  const file = join(dir, "source.sqlite"),
    backups = join(dir, "backups");
  await backup(db, file);
  await run(process.execPath, ["--import", "tsx", "scripts/backup.ts"], {
    env: { ...process.env, DATABASE_PATH: file, BACKUP_DIR: backups },
  });
  const files = readdirSync(backups);
  assert.equal(files.length, 1);
  const copy = new DatabaseSync(join(backups, files[0]), { readOnly: true });
  assert.equal(
    copy.prepare("SELECT COUNT(*) AS n FROM ops_reports").get()!.n,
    1,
  );
  assert.equal(
    copy.prepare("PRAGMA integrity_check").get()!.integrity_check,
    "ok",
  );
  copy.close();
  const { stdout } = await run(
    process.execPath,
    ["--import", "tsx", "scripts/reset-account.ts", credentials.email],
    { env: { ...process.env, DATABASE_PATH: file } },
  );
  const value = stdout.match(/New password \(keep private\): (\S+)/)?.[1];
  assert.ok(value);
  const reopened = openDatabase(file);
  try {
    assert.equal(
      reopened.prepare("SELECT COUNT(*) AS n FROM ops_sessions").get()!.n,
      0,
    );
    assert.equal(
      reopened.prepare("SELECT COUNT(*) AS n FROM ops_reports").get()!.n,
      1,
    );
    assert.equal(
      reopened.prepare("SELECT COUNT(*) AS n FROM feedback").get()!.n,
      84,
    );
    const stored = String(
      reopened
        .prepare("SELECT password_hash FROM ops_users WHERE id=?")
        .get(me.id)!.password_hash,
    );
    const [salt, expected] = stored.split(":");
    assert.equal(scryptSync(value, salt, 64).toString("hex"), expected);
  } finally {
    reopened.close();
  }
});
async function fixture(t: TestContext) {
  const db = openDatabase(":memory:");
  seedDatabase(db);
  const app = createApp(db, {
    adminEmail: "demo@example.test",
    adminPassword: randomBytes(20).toString("hex"),
    origin,
    production: false,
    rateLimit: 200,
  });
  const server = app.listen(0, "127.0.0.1");
  await once(server, "listening");
  const base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
  t.after(async () => {
    await new Promise<void>((resolve) => server.close(() => resolve()));
    db.close();
  });
  const request = (
    path: string,
    method = "GET",
    body?: unknown,
    cookie = "",
    reqOrigin = origin,
  ) =>
    fetch(base + "/api/ops" + path, {
      method,
      headers: {
        Origin: reqOrigin,
        ...(body ? { "Content-Type": "application/json" } : {}),
        ...(cookie ? { Cookie: cookie } : {}),
      },
      body: body ? JSON.stringify(body) : undefined,
    });
  const cookie = (r: Response) => r.headers.get("set-cookie")!.split(";")[0];
  const credentials = {
    name: "Owner One",
    organization: "Campus Transit",
    kind: "College",
    email: "owner1@example.test",
    password: "test-owner-password-123",
  };
  async function register(email = credentials.email) {
    const r = await request("/register", "POST", { ...credentials, email });
    assert.equal(r.status, 201);
    assert.match(r.headers.get("set-cookie")!, /HttpOnly/);
    const c = cookie(r);
    const me = await (await request("/me", "GET", undefined, c)).json();
    return { c, me };
  }
  async function addRoute(c: string, code = "CAMPUS-01") {
    const r = await request(
      "/routes",
      "POST",
      { code, origin: "Main campus", destination: "City centre" },
      c,
    );
    assert.equal(r.status, 201);
    return (await r.json()).id as string;
  }
  async function report(slug: string, routeId: string) {
    const r = await request(`/public/${slug}/reports`, "POST", {
      routeId,
      category: "Safety",
      rating: 2,
      description: "=SUM(1,1)",
    });
    assert.equal(r.status, 201);
    return r.json();
  }
  return { db, request, cookie, register, addRoute, report, credentials };
}
test("workspace onboarding, private receipt, audit, version conflicts, export and archive", async (t) => {
  const { request, register, addRoute, report } = await fixture(t);
  const { c, me } = await register();
  assert.equal((await request("/reports")).status, 401);
  const routeId = await addRoute(c),
    receipt = await report(me.slug, routeId);
  assert.equal(receipt.trackingToken.length, 48);
  let tracked = await (
    await request("/track", "POST", { token: receipt.trackingToken })
  ).json();
  assert.equal(tracked.status, "Received");
  assert.equal(tracked.timeline.length, 1);
  const ticket = await (
    await request("/reports/" + receipt.id, "GET", undefined, c)
  ).json();
  assert.equal(ticket.priority, "High");
  assert.equal(ticket.version, 1);
  assert.ok(!("tracking_hash" in ticket));
  const update = {
    status: "Resolved",
    priority: "High",
    assigneeId: me.id,
    note: "Internal investigation completed",
    version: 1,
  };
  assert.equal(
    (await request("/reports/" + receipt.id, "PATCH", update, c)).status,
    200,
  );
  assert.equal(
    (await request("/reports/" + receipt.id, "PATCH", update, c)).status,
    409,
  );
  tracked = await (
    await request("/track", "POST", { token: receipt.trackingToken })
  ).json();
  assert.equal(tracked.status, "Resolved");
  assert.equal(tracked.timeline.length, 2);
  const text = JSON.stringify(tracked);
  for (const field of [
    "Internal investigation",
    "description",
    "assignee",
    "owner1",
  ])
    assert.ok(!text.includes(field));
  const detail = await (
    await request("/reports/" + receipt.id, "GET", undefined, c)
  ).json();
  assert.equal(detail.events[1].note, "Internal investigation completed");
  const stats = await (await request("/stats", "GET", undefined, c)).json();
  assert.equal(stats.total, 1);
  assert.equal(stats.resolved, 1);
  assert.equal(stats.average, 2);
  const filtered = await (
    await request("/reports?status=Received", "GET", undefined, c)
  ).json();
  assert.equal(filtered.total, 0);
  const csv = await (await request("/export", "GET", undefined, c)).text();
  assert.ok(csv.includes("'=SUM(1,1)"));
  assert.ok(!csv.includes("Internal investigation"));
  assert.ok(!csv.includes(receipt.trackingToken));
  assert.equal(
    (await request("/routes/" + routeId, "PATCH", { active: false }, c)).status,
    200,
  );
  assert.equal(
    (
      await request(`/public/${me.slug}/reports`, "POST", {
        routeId,
        category: "Delay",
        rating: 2,
      })
    ).status,
    400,
  );
  assert.equal(
    (await request("/reports?from=2026-02-30", "GET", undefined, c)).status,
    400,
  );
});
test("tenant boundaries, invitation replay, agent scope, role restrictions and revocation", async (t) => {
  const { request, register, addRoute, report, cookie } = await fixture(t);
  const one = await register(),
    two = await register("owner2@example.test");
  const r1 = await addRoute(one.c),
    r2 = await addRoute(two.c),
    receipt = await report(one.me.slug, r1);
  assert.equal(
    (
      await request(`/public/${one.me.slug}/reports`, "POST", {
        routeId: r2,
        category: "Delay",
        rating: 3,
      })
    ).status,
    400,
  );
  assert.equal(
    (await request("/reports/" + receipt.id, "GET", undefined, two.c)).status,
    404,
  );
  assert.equal(
    (await (await request("/reports", "GET", undefined, two.c)).json()).total,
    0,
  );
  assert.equal(
    (await (await request("/stats", "GET", undefined, two.c)).json()).total,
    0,
  );
  assert.equal(
    (
      await request(
        "/reports/" + receipt.id,
        "PATCH",
        {
          status: "Received",
          priority: "High",
          assigneeId: two.me.id,
          version: 1,
        },
        one.c,
      )
    ).status,
    400,
  );
  const invitation = await (
    await request("/invites", "POST", { role: "agent" }, one.c)
  ).json();
  const member = {
    token: invitation.token,
    name: "Team Agent",
    email: "agent@example.test",
    password: "agent-test-password-123",
  };
  const joined = await request("/join", "POST", member);
  assert.equal(joined.status, 201);
  const agentCookie = cookie(joined);
  const agent = await (
    await request("/me", "GET", undefined, agentCookie)
  ).json();
  assert.equal(
    (await request("/join", "POST", { ...member, email: "again@example.test" }))
      .status,
    400,
  );
  assert.equal(
    (await request("/reports/" + receipt.id, "GET", undefined, agentCookie))
      .status,
    404,
  );
  assert.equal(
    (
      await request(
        "/routes",
        "POST",
        { code: "X", origin: "Main campus", destination: "City" },
        agentCookie,
      )
    ).status,
    403,
  );
  assert.equal(
    (await request("/invites", "POST", { role: "manager" }, agentCookie))
      .status,
    403,
  );
  assert.equal(
    (await request("/export", "GET", undefined, agentCookie)).status,
    403,
  );
  const update = {
    status: "Under Review",
    priority: "High",
    assigneeId: agent.id,
    version: 1,
  };
  assert.equal(
    (await request("/reports/" + receipt.id, "PATCH", update, one.c)).status,
    200,
  );
  assert.equal(
    (await (await request("/reports", "GET", undefined, agentCookie)).json())
      .total,
    1,
  );
  assert.equal(
    (
      await request(
        "/reports/" + receipt.id,
        "PATCH",
        { ...update, priority: "Low", version: 2 },
        agentCookie,
      )
    ).status,
    403,
  );
  assert.equal(
    (
      await request(
        "/reports/" + receipt.id,
        "PATCH",
        { ...update, status: "Resolved", version: 2 },
        agentCookie,
      )
    ).status,
    200,
  );
  assert.equal(
    (await request("/team/" + agent.id, "PATCH", { active: false }, two.c))
      .status,
    404,
  );
  assert.equal(
    (await request("/team/" + agent.id, "PATCH", { active: false }, one.c))
      .status,
    200,
  );
  assert.equal(
    (await request("/me", "GET", undefined, agentCookie)).status,
    401,
  );
  assert.equal(
    (
      await request(
        "/routes/" + r1,
        "PATCH",
        { active: false },
        one.c,
        "https://evil.example",
      )
    ).status,
    403,
  );
});
test("password change revokes old sessions; validation and hashed secret storage", async (t) => {
  const { db, request, register, cookie, credentials } = await fixture(t);
  const { c, me } = await register();
  assert.equal((await request("/register", "POST", credentials)).status, 409);
  assert.equal(
    (
      await request("/register", "POST", {
        ...credentials,
        email: "short@example.test",
        password: "short",
      })
    ).status,
    400,
  );
  const newPassword = "new-account-password-123";
  assert.equal(
    (
      await request(
        "/password",
        "POST",
        { current: "wrong-password", next: newPassword },
        c,
      )
    ).status,
    400,
  );
  const changed = await request(
    "/password",
    "POST",
    { current: credentials.password, next: newPassword },
    c,
  );
  assert.equal(changed.status, 200);
  assert.equal((await request("/me", "GET", undefined, c)).status, 401);
  assert.equal(
    (await request("/me", "GET", undefined, cookie(changed))).status,
    200,
  );
  assert.equal(
    (
      await request("/login", "POST", {
        email: credentials.email,
        password: credentials.password,
      })
    ).status,
    401,
  );
  assert.equal(
    (
      await request("/login", "POST", {
        email: credentials.email,
        password: newPassword,
      })
    ).status,
    200,
  );
  const user = db
    .prepare("SELECT password_hash FROM ops_users WHERE id=?")
    .get(me.id)!;
  assert.ok(!String(user.password_hash).includes(newPassword));
  db.prepare("UPDATE ops_sessions SET expires_at=0").run();
  assert.equal(
    (await request("/me", "GET", undefined, cookie(changed))).status,
    401,
  );
});
