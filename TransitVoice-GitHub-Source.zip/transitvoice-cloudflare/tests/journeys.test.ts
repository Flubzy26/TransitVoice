import test from "node:test";
import assert from "node:assert/strict";
import {
  PLACES,
  matchingJourneys,
  distanceKm,
  nearestPlace,
} from "../src/lib/journeys.js";
test("matches example routes only in their represented direction", () => {
  assert.deepEqual(
    matchingJourneys("station", "hinjawadi").map((r) => r.code),
    ["115"],
  );
  assert.deepEqual(
    matchingJourneys("swargate", "shivajinagar").map((r) => r.code),
    ["2", "4"],
  );
  assert.equal(matchingJourneys("hinjawadi", "station").length, 0);
  assert.equal(matchingJourneys("station", "station").length, 0);
  assert.equal(matchingJourneys("unknown", "station").length, 0);
});
test("GPS nearest-landmark calculation and distance are consistent", () => {
  const station = PLACES.find((p) => p.id === "station")!;
  const katraj = PLACES.find((p) => p.id === "katraj")!;
  assert.equal(nearestPlace(station).id, "station");
  assert.equal(distanceKm(station, station), 0);
  assert.ok(distanceKm(station, katraj) > 8);
  assert.ok(
    Math.abs(distanceKm(station, katraj) - distanceKm(katraj, station)) <
      0.000001,
  );
});
